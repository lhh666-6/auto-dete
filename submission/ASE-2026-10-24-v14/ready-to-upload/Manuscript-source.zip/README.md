# Manuscript LaTeX source

Article: The Review-Execution Gap in Agentic Software: Approval Scope and Recovery
Journal: Automated Software Engineering
Authors: Liang Hanghao; Xuan Wentao; Chen Qile; Peng Peng
Affiliation (all authors and corresponding author): College of Computer Science and Electronic Engineering, Hunan University, Changsha 410082, China
Corresponding author: Peng Peng (hnu16pp@hnu.edu.cn)

This v14 source applies the author's English revision to the abstract, introduction, related work,
Table 2, the Section 6.3 worked example, the opening of Section 7.1 and the conclusion; it orders
the contributions as C1 comparison model, C2 validation and C3 the empirical recovery account,
places Figure 1 below the introduction opening, and removes one defensive sentence from Section 7.1.
It retains the v13 layout revision, the v12 reference revision (Cordon and ACG removed, six arXiv
preprints), the v11 AI-assisted preparation statement, the v10 introduction revision and the v9
future-work subsection. No observation, statistic or experimental archive changed; page count is 29.

Extract all members together. `main.tex` is the only TeX document entrypoint.
The `sn-jnl` class, `sn-basic` bibliography style, `references.bib`, current
`main.bbl` and four figure PDFs are supplied. Use pdfLaTeX/BibTeX with the
packages requested by the source and class. From the extracted root run:

```text
latexmk -pdf -interaction=nonstopmode main.tex
```

The supplied `.latexmkrc` writes auxiliaries under `out/` and copies the PDF to
`main.pdf`. The equivalent explicit sequence is:

```text
mkdir out
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out main.tex
bibtex out/main
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out main.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out main.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=out main.tex
```

Skip `mkdir out` if it already exists. The explicit sequence produces
`out/main.pdf`; rerun pdfLaTeX if references still require a rerun. The current
root `main.bbl` assists source handling; BibTeX can regenerate it from the supplied
bibliography and style. The verified article has 29 pages. PDF metadata may make
binary hashes differ across builds; compare text and pagination.

This portal-facing ZIP contains only the main-manuscript source. The editable
three-document sources, figure-generation code/assets, tables and analysis
scripts are separately supplied as `Manuscript-sources.zip` inside `ESM_3.zip`
(Online Resource 3). `ESM_1.pdf` and `ESM_2.pdf` are separate supplementary PDFs.
