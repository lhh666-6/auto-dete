# Main manuscript source

One main.tex at archive root. Python 3, pdfLaTeX and BibTeX are required. Run `python build.py --main-only` from this directory. Build output goes under out/. Figure regeneration is unnecessary. Complete three-document sources and study archives are in ESM_3.zip.
