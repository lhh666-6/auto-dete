# v15 manuscript source

Compile main.tex with pdfLaTeX and BibTeX. There is one main.tex at archive root. Full three-document sources, QA and analysis scripts are in ESM_3.zip / Manuscript-sources.zip.
