# Online Resource 3 — v15 local revision

Manuscript-sources.zip contains all three document sources, figures, analysis scripts, corrected observation checker and tests, and current v15 audit reports. Extract it and read Manuscript-sources/README.txt.

The seven named study archives are byte-identical members of v14 ESM_3.zip; no experimental data were recollected or rewritten. Each retains its own guide. For the SDK studies begin with START-HERE.md and verify_offline.py. The v15 checker correction is separate from historical experiment freezes.

MANIFEST.json inventories every other member; it deliberately excludes itself.
