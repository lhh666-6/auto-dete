Requires Python and Matplotlib 3.10.8.
Run python scripts/build_story_figures.py from this directory.
All inputs are archived tables and CSV summaries; no experiments or model calls run.
Outputs: figures/refined and editorial/story-figure-source-hashes.json.
