Top-level document: supplement.tex
Engine: pdfLaTeX. Class: elsarticle (standard Elsevier TeX package).
All compilation dependencies in this archive use flat filenames.
Compile with pdflatex, run bibtex main for the main document, then
run pdflatex three more times to settle citations and references.
Select only this archive for this document in Editorial Manager.
Do not combine main and supplement as one review PDF.
Figure-generation scripts and CSVs retain their original layout in
the separate figure-reproduction.zip; they are not TeX dependencies.
