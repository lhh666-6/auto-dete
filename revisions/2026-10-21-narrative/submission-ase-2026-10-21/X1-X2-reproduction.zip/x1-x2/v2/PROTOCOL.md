# X1/X2 corrected execution protocol, version 2

Fixed before version-2 execution on 2026-10-21. This is an amendment after inspecting version-1 results and code, not a preregistration made before the original observations. Version-1 scripts and runs remain intact. No hosted model calls or credentials are needed. Paper sources and submitted ledgers are outside the modification scope.

## X1. Objects and lifetime in released approval paths

Use the installed, pinned LangChain 1.2.10, langchain-core 1.2.13, LangGraph 1.0.8 and langgraph-checkpoint 4.0.0. Official middleware/interrupt implementation remains unmodified. The graph, scripted messages, tool executor and SQLite effect recorder are author adapters. InMemorySaver/thread configuration is official configuration. Report these layers for each observation.

Run the following bounded conditions, storing input decisions, interrupt payloads, checkpoint-history evidence and actual SQLite effects.

1. One call approved. Two same-argument calls in one pending batch, with separate positional decisions. Include a mixed approve/reject control to check which call actually executes, and wrong-count/disallowed-decision controls. Do not infer indistinguishability from equal entry contents when positions remain distinct.
2. Explicit edit 100 to 999. Inspect both final messages and get_state_history, including original proposal and original review payload. This is authorized editing, not unauthorized mutation.
3. Two consecutive turns in the SAME compiled graph, SAME saver and SAME thread. Approve the first call, then supply a new-id/same-argument call. Measure whether the second turn interrupts before any new write. Submit a resume keyed to the OLD interrupt id, then, if still pending, resume with the CURRENT id. Also use a separate same-thread two-turn branch that resubmits the same unkeyed approval payload. Report the difference between a routing key and an authenticated business grant; an unkeyed affirmative input is a newly supplied input, not proof of a stolen approval.
4. Additional resume after a completed graph, with no new pending action. Check actual effects. Keep this completed-run condition separate from condition 3.
5. LangGraph primitive with author-defined payload and node behavior. Exercise approval/edit and same-thread keyed-id handling; attribute payload schema and interpretation to the adapter, transport and interrupt ids to the primitive.

No outcome is required to favor the manuscript. Checks enforce the scenario being exercised and agreement between reported observations and artifacts. They must not omit or relabel unexpected runtime behavior to obtain a desired conclusion. The original planned post-approval mutation condition is not relabeled as the authorized-edit condition. If no additional mutation injector is implemented, mark it explicitly untested.

## X2. Binding projection and actual referenced-content consumption

This is a small binding comparator experiment, NOT an implementation of the manuscript's complete guard G. Three principal arms share a value guard and differ in binding object. Context compares declared K, content compares declared R, instance compares K plus candidate id. A raw-content variant diagnoses representation sensitivity and is not a fourth principal method.

Preserve the original eight case intentions, correct C3 to actually read and consume a local document, and add one unchanged-document control. K includes target record, operation, unit, stored source digest and proposal. R additionally includes effective date and cost center; the authorized value is checked separately in every arm. The note enters both projections only in its declared-semantic case. Representation-only edits and display-only notes remain distinct from semantic changes. Candidate ids are immutable within each scenario except when the case explicitly creates a new candidate.

For C3, create a real local reviewed document, calculate its SHA-256 from bytes, retain an immutable review copy, then change the live document before execution while keeping candidate fields and id fixed. The tool reads the live bytes and its persisted business effect must depend on the consumed document. The unchanged-document case uses the same path and tool without mutation.

Cross the SAME case/binding routes with two shared executor modes, applied equally to all arms.

- `unchecked_live`: the executor reads and consumes the live document without validating it against the reviewed digest.
- `verified_read`: the executor reads bytes once, validates their actual digest against the reviewed digest, and uses exactly those verified bytes for its effect. A mismatch stops before the SQLite write. This avoids a check/use reread gap within the tested single-process path. It does not assert a distributed transaction guarantee.

The reference-content check is a shared adapter mechanism, not a special power of instance binding. Candidate binding verdict, executor verification verdict and actual durable effect must be reported separately. Do not call an executor stop a binding rejection.

Declare typed normalization locally. Monetary values use Decimal to two decimal places; dictionary key order and rendering metadata are nonsemantic. State explicitly that this domain-specific equality is not the paper's original canonical JSON equality. Do not round or normalize hidden business fields to make an arm win.

## Independent readback and expected outcomes

Before invoking gates, save the case definitions and approved business semantics. A separate read-only scorer must read these and the SQLite database, without importing gate/projection/normalization implementations. Derive actual state violations from stored effects, not gate-return labels. Also report a discrepancy if the gate/executor log says no write but one exists, or claims a write that is absent. Include evidence that deleting/changing/adding an effect in a COPY of the sink is detected. Do not modify real run sinks for this check.

Expected qualitative results are fixed as tests of the declared mechanisms, not evidence of natural prevalence. Narrow K can miss changes in R; content and instance can reject those different-candidate cases. Instance can reject semantically identical new candidates under the selected responsibility rule. Same-id/unchanged-field binding alone does not observe a changed external referent. The shared verified-read check should stop the changed document for every binding arm and permit the unchanged-document control. If results differ, preserve and explain the difference.

Report semantic violations, attribution-policy differences and execution stops separately, with case-specific denominators. Do not pool repeated configurations as independent real-world tasks. An instance-policy rejection is not automatically a false positive.

## Reproduction and stopping rule

Each runner accepts an explicit fresh output directory and refuses to overwrite existing artifacts. Record dependency versions, protocol and source hashes. Run each final implementation twice in independent output directories. Compare semantic observations, case verdicts and normalized SQL effect rows; randomized framework checkpoint/interrupt ids may differ, but their measured relationships must agree. Preserve raw ids for audit.

Regenerate the summary from validated run artifacts. Stop when these deterministic checks and independent readback pass or disclose the unresolved error. X3/X4, new hosted-agent behavior, human-review cost and manuscript integration are not part of this execution.
