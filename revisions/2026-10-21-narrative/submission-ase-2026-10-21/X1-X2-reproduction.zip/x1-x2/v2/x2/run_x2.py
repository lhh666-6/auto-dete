"""Deterministic X2 binding comparator with actual local-document consumption.

This is an author adapter, not the paper's complete guard G. Domain equality is
local moneyDecimal2dp equality, not the paper's original canonical JSON equality.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import shutil
import sqlite3
import stat
import sys
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path

HERE = Path(__file__).resolve().parent
BINDINGS = ("context", "content", "instance", "content_raw")
MODES = ("unchecked_live", "verified_read")
K_FIELDS = ("target_record", "operation", "unit", "source_doc_digest", "proposal")
R_FIELDS = K_FIELDS + ("effective_date", "cost_center")
MONEY_FIELDS = {"proposal", "value"}


def save_json(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, sort_keys=True)
        handle.write("\n")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def money(value: object) -> str:
    """Local schema: finite decimal money, ROUND_HALF_EVEN, two decimal places."""
    if isinstance(value, bool):
        raise ValueError("Boolean is not a money value")
    parsed = Decimal(str(value))
    if not parsed.is_finite():
        raise ValueError("Non-finite money")
    return format(parsed.quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), ".2f")


def projection(record: dict, fields: tuple[str, ...], note_semantic: bool, *, raw: bool = False) -> str:
    projected = {field: record[field] for field in fields}
    if note_semantic:
        projected["note"] = record["note"]
    if not raw:
        for field in MONEY_FIELDS.intersection(projected):
            projected[field] = money(projected[field])
    return json.dumps(projected, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def bind(case: dict, binding: str) -> tuple[bool, str]:
    reviewed, submitted = case["reviewed_candidate"], case["submitted_candidate"]
    # The SAME value guard is applied before all three arms and the diagnostic.
    if money(reviewed["value"]) != money(submitted["value"]):
        return False, "authorized_value_mismatch"
    note_semantic = case["note_declared_semantic"]
    fields = R_FIELDS if binding in {"content", "content_raw"} else K_FIELDS
    if binding == "content_raw":
        fields += ("value",)
    reviewed_projection = projection(reviewed, fields, note_semantic, raw=binding == "content_raw")
    submitted_projection = projection(submitted, fields, note_semantic, raw=binding == "content_raw")
    if binding in {"content", "content_raw"}:
        reviewed_projection = sha256(reviewed_projection.encode("utf-8"))
        submitted_projection = sha256(submitted_projection.encode("utf-8"))
    if reviewed_projection != submitted_projection:
        return False, "projection_mismatch"
    if binding == "instance" and reviewed["candidate_id"] != submitted["candidate_id"]:
        return False, "candidate_id_mismatch"
    return True, "binding_equal"


def build_cases(run_dir: Path) -> dict:
    """Create review bytes, reviewed effects and submitted candidates before gates."""
    definitions = [
        ("C1-identical-new-instance", "C1", "new candidate; identical business meaning", {}, True, False, False),
        ("C2-effective-date", "C2", "new candidate; effective date outside K changed", {"effective_date": "2026-04-30"}, True, False, False),
        ("C2-cost-center", "C2", "new candidate; cost center outside K changed", {"cost_center": "CC-99"}, True, False, False),
        ("C2-effective-date-render-noise", "C2", "effective date change plus display noise", {"effective_date": "2026-04-30", "render_format": "amount.4dp"}, True, False, False),
        ("C3-referent-mutated", "C3", "same candidate and fields; consumed document changed after review", {}, False, False, True),
        ("C4-representation", "C4", "new candidate; 101 to string 101.00 and display/key-order change", {"value": "101.00", "render_format": "amount.4dp", "key_order": "amount,target"}, True, False, False),
        ("C4-note-display", "C4", "new candidate; note changed and declared display-only", {"note": "reviewed against April invoice"}, True, False, False),
        ("C4-note-semantic", "C4", "new candidate; note changed and declared semantic in K and R", {"note": "reviewed against April invoice"}, True, True, False),
        ("C3-referent-unchanged-control", "C3-control", "same document-reading operation and path; live bytes unchanged", {}, False, False, False),
    ]
    cases = []
    for case_id, cls, description, changes, new_id, note_semantic, mutated in definitions:
        doc_dir = run_dir / "rawdocs" / case_id
        doc_dir.mkdir(parents=True)
        reviewed_bytes = b'{"document_id":"invoice-source-0001","amount":"101.00","unit":"USD"}\n'
        live_bytes = reviewed_bytes.replace(b'101.00', b'999.00') if mutated else reviewed_bytes
        (doc_dir / "reviewed.json").write_bytes(reviewed_bytes)
        (doc_dir / "reviewed.json").chmod(stat.S_IREAD)
        (doc_dir / "live.json").write_bytes(reviewed_bytes)
        document_operation = case_id in {"C3-referent-mutated", "C3-referent-unchanged-control"}
        reviewed = {
            "candidate_id": "cand-0001", "target_record": "INV-1000",
            "operation": "set_amount_from_document" if document_operation else "set_amount",
            "unit": "USD", "source_doc_digest": sha256(reviewed_bytes), "proposal": 100,
            "value": 101, "effective_date": "2026-03-31", "cost_center": "CC-42",
            "render_format": "amount.2dp", "note": "reviewed against March invoice",
            "ui_hint": "amount field, invoice table", "key_order": "target,amount",
        }
        submitted = deepcopy(reviewed)
        submitted.update(changes)
        if new_id:
            submitted["candidate_id"] = "cand-0002"
        # Actual insertion order also changes in the representation-only fixture.
        if case_id == "C4-representation":
            submitted = dict(reversed(list(submitted.items())))
        cases.append({
            "case_id": case_id, "class": cls, "description": description,
            "note_declared_semantic": note_semantic,
            "reviewed_candidate": reviewed, "submitted_candidate": submitted,
            "approved_candidate_id": reviewed["candidate_id"],
            "submitted_candidate_id": submitted["candidate_id"],
            "approved_effect": {
                "record_id": "INV-1000", "operation": reviewed["operation"], "unit": "USD",
                "amount_decimal2dp": "101.00", "effective_date": "2026-03-31",
                "cost_center": "CC-42", "semantic_note": reviewed["note"] if note_semantic else None,
                "stored_source_doc_digest": sha256(reviewed_bytes), "consumed_doc_digest": sha256(reviewed_bytes),
            },
            "source": {"reviewed_path": f"rawdocs/{case_id}/reviewed.json", "live_path": f"rawdocs/{case_id}/live.json",
                       "reviewed_sha256": sha256(reviewed_bytes), "live_sha256": sha256(live_bytes),
                       "review_copy_policy": "retained read-only file; scorer verifies unchanged SHA256"},
            "external_change_planned": mutated,
            "execution_contract": {"amount_source": "consumed_document.amount" if document_operation else "submitted_candidate.value",
                                   "source_read_policy": "one live-file read; same captured bytes hashed and parsed"},
        })
    return {
        "schema_version": "x2-v2", "case_count": len(cases), "bindings": list(BINDINGS),
        "principal_bindings": list(BINDINGS[:3]), "diagnostic_binding": "content_raw", "executor_modes": list(MODES),
        "normalization": {"name": "local moneyDecimal2dp", "money_fields": sorted(MONEY_FIELDS),
                          "rounding": "ROUND_HALF_EVEN", "dictionary_order_semantic": False,
                          "render_metadata_semantic": False, "paper_original_canonical_json_equality": False},
        "raw_diagnostic": "SHA256 over sorted-key R plus raw value; no money normalization; C4 representation rejection tests number/string representation, not key order alone",
        "projections": {"K": list(K_FIELDS), "R": list(R_FIELDS),
                        "note": "included in both K and R only when note_declared_semantic",
                        "authorized_value": "separate shared money guard in every binding, including content_raw"},
        "operation_contracts": {"set_amount": "read source bytes, then persist submitted candidate value",
                                "set_amount_from_document": "read source bytes, then persist amount parsed from those bytes"},
        "cases": cases,
        "routes": [{"route_id": f"{case['case_id']}::{binding}::{mode}", "case_id": case["case_id"],
                    "binding": binding, "executor_mode": mode}
                   for case in cases for binding in BINDINGS for mode in MODES],
    }


def create_sink(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.execute("""CREATE TABLE effects (
        effect_id INTEGER PRIMARY KEY, route_id TEXT NOT NULL UNIQUE,
        case_id TEXT NOT NULL, binding TEXT NOT NULL, executor_mode TEXT NOT NULL,
        record_id TEXT NOT NULL, operation TEXT NOT NULL, unit TEXT NOT NULL,
        amount_decimal2dp TEXT NOT NULL, effective_date TEXT NOT NULL, cost_center TEXT NOT NULL,
        semantic_note TEXT, stored_source_doc_digest TEXT NOT NULL, consumed_doc_digest TEXT NOT NULL,
        candidate_id TEXT NOT NULL, consumed_doc_amount_decimal2dp TEXT NOT NULL
    )""")
    conn.commit()
    return conn


def execute(conn: sqlite3.Connection, run_dir: Path, case: dict, route: dict) -> dict:
    """Shared executor: exactly one read, then hash/parse/write from those bytes."""
    submitted = case["submitted_candidate"]
    consumed = (run_dir / case["source"]["live_path"]).read_bytes()
    consumed_digest = sha256(consumed)
    evidence = {"consumed_doc_digest": consumed_digest, "source_read_count": 1}
    if route["executor_mode"] == "verified_read":
        if consumed_digest != case["source"]["reviewed_sha256"]:
            return {**evidence, "executor_verdict": "source_digest_mismatch", "executor_verification": "mismatch", "effect_written": False}
        verification = "verified"
    else:
        verification = "not_checked"
    document = json.loads(consumed)
    doc_amount = money(document["amount"])
    if submitted["operation"] == "set_amount_from_document":
        amount = doc_amount
    elif submitted["operation"] == "set_amount":
        amount = money(submitted["value"])
    else:
        raise ValueError(f"Undefined operation: {submitted['operation']}")
    row = {**route, "record_id": submitted["target_record"], "operation": submitted["operation"],
           "unit": submitted["unit"], "amount_decimal2dp": amount, "effective_date": submitted["effective_date"],
           "cost_center": submitted["cost_center"], "semantic_note": submitted["note"] if case["note_declared_semantic"] else None,
           "stored_source_doc_digest": submitted["source_doc_digest"], "consumed_doc_digest": consumed_digest,
           "candidate_id": submitted["candidate_id"], "consumed_doc_amount_decimal2dp": doc_amount}
    columns = list(row)
    conn.execute(f"INSERT INTO effects ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})", [row[k] for k in columns])
    conn.commit()
    return {**evidence, "executor_verdict": "written", "executor_verification": verification, "effect_written": True}


def write_score(run_dir: Path, result: dict) -> None:
    for filename, key in (("SCORE.json", "score"), ("EFFECTS.json", "effects"), ("CHECKS.json", "checks")):
        save_json(run_dir / filename, result[key])
    with (run_dir / "grid.csv").open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result["grid"][0]))
        writer.writeheader()
        writer.writerows(result["grid"])


def mutation_checks(run_dir: Path) -> list[dict]:
    """Change only COPY sinks. The same independent readback must reject each."""
    from score_x2 import score_run
    out = []
    folder = run_dir / "oracle-mutations"
    folder.mkdir()
    for name in ("deleted_effect", "extra_effect", "changed_amount"):
        copy_path = folder / f"{name}.sqlite"
        shutil.copy2(run_dir / "effects.sqlite", copy_path)
        with sqlite3.connect(copy_path) as conn:
            if name == "deleted_effect":
                conn.execute("DELETE FROM effects WHERE effect_id=(SELECT MIN(effect_id) FROM effects)")
            elif name == "changed_amount":
                conn.execute("UPDATE effects SET amount_decimal2dp='777.00' WHERE effect_id=(SELECT MIN(effect_id) FROM effects)")
            else:
                columns = [r[1] for r in conn.execute("PRAGMA table_info(effects)") if r[1] != "effect_id"]
                values = list(conn.execute(f"SELECT {','.join(columns)} FROM effects ORDER BY effect_id LIMIT 1").fetchone())
                values[columns.index("route_id")] = "ORACLE-EXTRA-ROUTE"
                conn.execute(f"INSERT INTO effects ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})", values)
        result = score_run(run_dir, copy_path)
        record = {"mutation": name, "detected": not result["checks"]["passed"], "issues": result["checks"]["issues"]}
        save_json(folder / f"{name}-CHECKS.json", record)
        out.append(record)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    run_dir = args.output_dir.resolve()
    if run_dir.exists():
        parser.error(f"Refusing existing output directory: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=False)
    fixtures = build_cases(run_dir)
    save_json(run_dir / "CASES.json", fixtures)  # Approved business semantics frozen before any gate.
    frozen_cases_hash = sha256((run_dir / "CASES.json").read_bytes())
    # Real source mutation is after review evidence is saved and before execution.
    for case in fixtures["cases"]:
        if case["external_change_planned"]:
            path = run_dir / case["source"]["live_path"]
            path.write_bytes(path.read_bytes().replace(b'101.00', b'999.00'))
    case_map = {case["case_id"]: case for case in fixtures["cases"]}
    conn = create_sink(run_dir / "effects.sqlite")
    records = []
    try:
        for route in fixtures["routes"]:
            case = case_map[route["case_id"]]
            accepted, reason = bind(case, route["binding"])
            execution = execute(conn, run_dir, case, route) if accepted else {
                "executor_verdict": "not_invoked", "executor_verification": "not_invoked", "effect_written": False,
                "consumed_doc_digest": None, "source_read_count": 0,
            }
            records.append({**route, "binding_accepted": accepted, "binding_reason": reason, **execution})
    finally:
        conn.close()
    save_json(run_dir / "ROUTES.json", {"schema_version": "x2-v2", "routes": records})
    from score_x2 import score_run
    result = score_run(run_dir)
    mutations = mutation_checks(run_dir)
    guard_case = deepcopy(fixtures["cases"][0])
    guard_case["submitted_candidate"]["value"] = 102
    value_guard_checks = {binding: not bind(guard_case, binding)[0] for binding in BINDINGS}
    fixture_unchanged = sha256((run_dir / "CASES.json").read_bytes()) == frozen_cases_hash
    c3 = case_map["C3-referent-mutated"]
    checks = result["checks"]
    checks["mutation_tests"] = mutations
    checks["shared_value_guard_negative_controls"] = value_guard_checks
    checks["fixtures_unchanged_after_execution"] = fixture_unchanged
    checks["c3_candidate_fields_and_id_unchanged"] = c3["reviewed_candidate"] == c3["submitted_candidate"]
    checks["passed"] = (checks["passed"] and all(x["detected"] for x in mutations) and all(value_guard_checks.values())
                        and fixture_unchanged and checks["c3_candidate_fields_and_id_unchanged"])
    write_score(run_dir, result)
    save_json(run_dir / "ENVIRONMENT.json", {"python_version": platform.python_version(), "python_implementation": platform.python_implementation(),
              "sqlite_version": sqlite3.sqlite_version, "dependencies": "Python standard library only; no network/model calls",
              "protocol_sha256": sha256((HERE.parent / "PROTOCOL.md").read_bytes()),
              "source_sha256": {name: sha256((HERE / name).read_bytes()) for name in ("run_x2.py", "score_x2.py")},
              "cases_sha256": frozen_cases_hash, "adapter_layer": "author-defined bindings, executor, fixtures and SQLite recorder"})
    print(json.dumps({"case_count": 9, "route_count": len(records), "checks_passed": checks["passed"], "score": result["score"]}, indent=2))
    return 0 if checks["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
