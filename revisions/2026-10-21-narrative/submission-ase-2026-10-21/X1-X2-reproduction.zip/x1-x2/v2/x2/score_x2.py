"""Independent X2 readback: approved fixtures + read-only SQLite business rows.

No gate/projection/runner/normalizer imports. Approved amounts are explicit
canonical strings, compared directly to SQL. A separate execution-consistency
check parses the submitted money/source file to distinguish legitimate measured
violations from corrupted or missing recorder output. Logs never define truth.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path


def read_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def score_run(run_dir: Path, database_path: Path | None = None) -> dict:
    run_dir = Path(run_dir)
    fixtures = read_json(run_dir / "CASES.json")
    records = read_json(run_dir / "ROUTES.json")["routes"]
    issues = []
    cases = {case["case_id"]: case for case in fixtures["cases"]}
    routes = {route["route_id"]: route for route in fixtures["routes"]}
    logs = {record["route_id"]: record for record in records}
    if len(cases) != len(fixtures["cases"]):
        issues.append("duplicate_case_fixture")
    if len(routes) != len(fixtures["routes"]):
        issues.append("duplicate_route_fixture")
    if len(logs) != len(records):
        issues.append("duplicate_route_log")
    if set(logs) != set(routes):
        issues.append("route_log_inventory_mismatch")
    intended_routes = {(case_id, binding, mode) for case_id in cases for binding in fixtures["bindings"] for mode in fixtures["executor_modes"]}
    actual_routes = {(r["case_id"], r["binding"], r["executor_mode"]) for r in routes.values()}
    if intended_routes != actual_routes or len(actual_routes) != len(routes):
        issues.append("fixture_cross_product_mismatch")

    # SQL opened read-only; query_only adds another guard. No writes or DDL here.
    database = Path(database_path) if database_path else run_dir / "effects.sqlite"
    conn = sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)
    conn.execute("PRAGMA query_only = ON")
    conn.row_factory = sqlite3.Row
    try:
        if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            issues.append("sqlite_integrity_failure")
        effects = [dict(row) for row in conn.execute("SELECT * FROM effects ORDER BY route_id, effect_id")]
    finally:
        conn.close()
    effects_by_route = {}
    for effect in effects:
        effects_by_route.setdefault(effect["route_id"], []).append(effect)
        if effect["route_id"] not in routes:
            issues.append(f"unknown_effect_route:{effect['route_id']}")

    # Validate fixture review semantics against preserved review bytes. Reconstruct
    # execution input independently to detect database mutations. This does not
    # infer an effect from the log or use the binding implementation.
    reconstructed = {}
    source_digests = {}
    for case_id, case in cases.items():
        reviewed_bytes = (run_dir / case["source"]["reviewed_path"]).read_bytes()
        live_bytes = (run_dir / case["source"]["live_path"]).read_bytes()
        reviewed_digest = hashlib.sha256(reviewed_bytes).hexdigest()
        live_digest = hashlib.sha256(live_bytes).hexdigest()
        source_digests[case_id] = (reviewed_digest, live_digest)
        if reviewed_digest != case["source"]["reviewed_sha256"] or live_digest != case["source"]["live_sha256"]:
            issues.append(f"source_file_digest_disagrees_with_fixture:{case_id}")
        approved = case["approved_effect"]
        if approved["consumed_doc_digest"] != reviewed_digest or approved["stored_source_doc_digest"] != reviewed_digest:
            issues.append(f"approved_source_disagrees_with_review_bytes:{case_id}")
        reviewed = case["reviewed_candidate"]
        reviewed_doc = json.loads(reviewed_bytes)
        approved_input = reviewed_doc["amount"] if reviewed["operation"] == "set_amount_from_document" else reviewed["value"]
        approved_amount = format(Decimal(str(approved_input)).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), ".2f")
        reviewed_expectation = {"record_id": reviewed["target_record"], "operation": reviewed["operation"], "unit": reviewed["unit"],
                               "amount_decimal2dp": approved_amount, "effective_date": reviewed["effective_date"],
                               "cost_center": reviewed["cost_center"], "semantic_note": reviewed["note"] if case["note_declared_semantic"] else None,
                               "stored_source_doc_digest": reviewed["source_doc_digest"], "consumed_doc_digest": reviewed_digest}
        if approved != reviewed_expectation:
            issues.append(f"approved_semantics_disagree_with_reviewed_input:{case_id}")
        candidate = case["submitted_candidate"]
        doc = json.loads(live_bytes)
        doc_amount = format(Decimal(str(doc["amount"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), ".2f")
        if candidate["operation"] == "set_amount_from_document":
            expected_amount = doc_amount
        elif candidate["operation"] == "set_amount":
            expected_amount = format(Decimal(str(candidate["value"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN), ".2f")
        else:
            raise ValueError("Unknown explicit operation in fixture")
        reconstructed[case_id] = {"record_id": candidate["target_record"], "operation": candidate["operation"],
                                 "unit": candidate["unit"], "amount_decimal2dp": expected_amount,
                                 "effective_date": candidate["effective_date"], "cost_center": candidate["cost_center"],
                                 "semantic_note": candidate["note"] if case["note_declared_semantic"] else None,
                                 "stored_source_doc_digest": candidate["source_doc_digest"], "consumed_doc_digest": live_digest,
                                 "candidate_id": candidate["candidate_id"], "consumed_doc_amount_decimal2dp": doc_amount}

    grid = []
    for route_id, route in routes.items():
        case = cases[route["case_id"]]
        log = logs.get(route_id, {})
        rows = effects_by_route.get(route_id, [])
        for field, value in route.items():
            if log.get(field) != value:
                issues.append(f"log_route_metadata_mismatch:{route_id}:{field}")
        if len(rows) != int(log.get("effect_written", False)):
            issues.append(f"log_effect_count_mismatch:{route_id}:claimed={int(log.get('effect_written', False))}:actual={len(rows)}")
        if len(rows) > 1:
            issues.append(f"multiple_effects_for_route:{route_id}")
        accepted = log.get("binding_accepted", False)
        verdict = log.get("executor_verdict", "missing")
        verification = log.get("executor_verification", "missing")
        if not accepted and (verdict != "not_invoked" or rows or log.get("source_read_count") != 0 or verification != "not_invoked"):
            issues.append(f"rejected_binding_execution_inconsistency:{route_id}")
        if accepted:
            reviewed_digest, live_digest = source_digests[route["case_id"]]
            should_stop = route["executor_mode"] == "verified_read" and reviewed_digest != live_digest
            expected_verdict = "source_digest_mismatch" if should_stop else "written"
            expected_verification = "not_checked" if route["executor_mode"] == "unchecked_live" else ("mismatch" if should_stop else "verified")
            if verdict != expected_verdict or verification != expected_verification:
                issues.append(f"executor_source_check_inconsistency:{route_id}")
            if bool(rows) == should_stop:
                issues.append(f"executor_write_presence_inconsistency:{route_id}")
            if log.get("consumed_doc_digest") != live_digest or log.get("source_read_count") != 1:
                issues.append(f"executor_read_evidence_inconsistency:{route_id}")
        elif log.get("consumed_doc_digest") is not None:
            issues.append(f"rejected_binding_claims_read_digest:{route_id}")
        mismatches = set()
        attribution = False
        for row in rows:
            for field, value in route.items():
                if row[field] != value:
                    issues.append(f"effect_route_metadata_mismatch:{route_id}:{field}")
            for field, value in reconstructed[route["case_id"]].items():
                if row[field] != value:
                    issues.append(f"effect_vs_execution_input_mismatch:{route_id}:{field}")
            # Actual semantic violation is ONLY this SQL-versus-approval comparison.
            mismatches.update(field for field, approved in case["approved_effect"].items() if row[field] != approved)
            attribution = attribution or row["candidate_id"] != case["approved_candidate_id"]
        input_semantics_same = all(reconstructed[route["case_id"]][field] == value for field, value in case["approved_effect"].items())
        grid.append({
            **route, "class": case["class"], "principal_binding": route["binding"] != "content_raw",
            "binding_accepted": accepted, "binding_reason": log.get("binding_reason", "missing"),
            "executor_verdict": verdict, "executor_verification": verification,
            "actual_effect_count": len(rows), "semantic_violation": bool(mismatches),
            "mismatched_fields": ";".join(sorted(mismatches)), "attribution_policy_difference": attribution,
            "executor_stop": verdict == "source_digest_mismatch" and not rows,
            "same_semantics_binding_rejection": not accepted and input_semantics_same,
            "instance_policy_rejection": not accepted and route["binding"] == "instance" and log.get("binding_reason") == "candidate_id_mismatch",
            "approved_amount_decimal2dp": case["approved_effect"]["amount_decimal2dp"],
            "actual_amount_decimal2dp": rows[0]["amount_decimal2dp"] if len(rows) == 1 else "",
            "approved_candidate_id": case["approved_candidate_id"],
            "actual_candidate_id": rows[0]["candidate_id"] if len(rows) == 1 else "",
        })

    def count(rows: list[dict]) -> dict:
        return {"route_count": len(rows), "written_effects": sum(r["actual_effect_count"] for r in rows),
                "semantic_violation_routes": sum(r["semantic_violation"] for r in rows),
                "attribution_policy_difference_routes": sum(r["attribution_policy_difference"] for r in rows),
                "binding_rejections": sum(not r["binding_accepted"] for r in rows),
                "executor_stops": sum(r["executor_stop"] for r in rows),
                "same_semantics_binding_rejections": sum(r["same_semantics_binding_rejection"] for r in rows),
                "instance_policy_rejections": sum(r["instance_policy_rejection"] for r in rows)}

    score = {
        "schema_version": "x2-v2", "case_count": len(cases), "route_count": len(routes),
        "unit_of_analysis": "9 defined fixtures crossed with 4 bindings (including 1 diagnostic) and 2 executor modes; 72 routes, not independent tasks",
        "semantic_truth_source": "persisted SQL effects compared directly to pre-execution approved_effect fixtures",
        "totals": count(grid),
        "by_binding": {binding: {mode: count([r for r in grid if r["binding"] == binding and r["executor_mode"] == mode]) for mode in fixtures["executor_modes"]} for binding in fixtures["bindings"]},
        "by_case": {case_id: count([r for r in grid if r["case_id"] == case_id]) for case_id in cases},
        "denominators": {"principal_binding_routes": sum(r["principal_binding"] for r in grid),
                         "diagnostic_routes": sum(not r["principal_binding"] for r in grid),
                         "per_binding_per_executor": len(cases), "per_case": len(fixtures["bindings"]) * len(fixtures["executor_modes"])},
        "interpretation_limits": ["This implements selected binding comparators, not the full paper guard G.",
                                  "Attribution-policy differences are separate from semantic violations; instance-policy rejections are not automatically false positives.",
                                  "Typed local moneyDecimal2dp equality is not the paper's original canonical JSON equality.",
                                  "Verified read hashes and consumes the same bytes in a single-process adapter; distributed transactions are untested.",
                                  "Defined fixture frequencies do not estimate natural prevalence or independent task success."],
    }
    checks = {"passed": not issues, "issues": issues, "sql_read_only": True,
              "fixture_route_count": len(routes), "sql_effect_count": len(effects),
              "scorer_imports_runner_gate_or_normalizer": False,
              "business_truth_from": "SQL-versus-approved_effect; logs used only for consistency",
              "execution_consistency_from": "submitted fixture fields plus independently parsed preserved live bytes"}
    return {"score": score, "grid": grid, "effects": effects, "checks": checks}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--database", type=Path)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    if args.output_dir and args.output_dir.exists():
        parser.error("Refusing existing scorer output directory")
    result = score_run(args.run_dir, args.database)
    if args.output_dir:
        args.output_dir.mkdir(parents=True, exist_ok=False)
        for filename, key in (("SCORE.json", "score"), ("EFFECTS.json", "effects"), ("CHECKS.json", "checks")):
            (args.output_dir / filename).write_text(json.dumps(result[key], indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
        with (args.output_dir / "grid.csv").open("x", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(result["grid"][0]))
            writer.writeheader()
            writer.writerows(result["grid"])
    print(json.dumps({"score": result["score"], "checks": result["checks"]}, indent=2))
    return 0 if result["checks"]["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
