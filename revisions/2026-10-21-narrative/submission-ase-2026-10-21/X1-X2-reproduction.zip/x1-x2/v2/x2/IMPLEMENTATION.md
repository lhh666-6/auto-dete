# X2 v2 implementation and independent readback

Run from the repository root with Python 3.11 or later:

```text
python research/ase-x1-x2-2026-10-21/v2/x2/run_x2.py --output-dir FRESH_RUN_DIRECTORY
python research/ase-x1-x2-2026-10-21/v2/x2/score_x2.py --run-dir RUN_DIRECTORY
python research/ase-x1-x2-2026-10-21/v2/x2/score_x2.py --run-dir RUN_DIRECTORY --database COPY_DATABASE
```

The scorer prints its score and checks and exits nonzero on validation failures.
Its optional `--output-dir FRESH_DIRECTORY` saves readback artifacts without changing
the original run. Both programs refuse an existing output directory.
Only Python standard-library modules are used. No network or model is called.

There are nine fixtures, four bindings (three principal and one raw diagnostic),
and two executor modes: 72 routes, not 72 independent tasks. The original eight
case intentions are retained, with actual C3 source consumption and one unchanged
source control added. Each route is an isolated write observation in one SQLite
effect table; the database records the durable payload, not a claimed gate label.

## Explicit local schema and execution

`K` includes target record, operation, unit, stored source digest and proposal.
`R` adds effective date and cost center. Note text enters both only in the
declared-semantic note fixture. All bindings first apply the same authorized-value
guard. The instance binding additionally requires the same candidate id.
Candidate records and ids stay fixed during every route; only fixtures explicitly
marked as new candidates use a different submitted id.

Money fields use Decimal quantization to two places with ROUND_HALF_EVEN.
This local moneyDecimal2dp relation differs from the paper's original canonical
JSON equality. Other business fields are compared without coercion. Dictionary
order and rendering metadata are nonsemantic. Content binding hashes the
normalized R projection with SHA256. The raw diagnostic hashes sorted-key R plus
the unnormalized value, so C4's numeric/string representation causes its rejection;
this is not a test of dictionary order alone.

Every fixture has real reviewed and live source files. Review copies are marked
read-only and checked against saved SHA256 values during independent readback.
Approved effect fields are saved in CASES.json before any binding gate executes.
Only then is C3's live amount changed from 101.00 to 999.00. C3's candidate id and
all candidate fields remain identical to their reviewed versions.

Operations are explicit in each candidate and in the fixture's execution contract:

- `set_amount` reads the live source and persists the submitted value.
- `set_amount_from_document` reads the live source and persists its parsed amount.
  Both C3 and its unchanged control use this operation.

Every accepted route goes through the same executor. `unchecked_live` consumes
the live bytes without verification. `verified_read` performs one file read,
checks those bytes against the approved digest, and parses those same bytes.
A mismatch returns before the SQLite insert. There is no second file read after
verification. This single-process adapter does not establish a distributed
transaction or concurrent authorization guarantee. These comparators do not
implement the paper's full guard G.

## Artifacts and scorer independence

- `CASES.json`: reviewed/submitted candidates, approved business effects, raw
  document paths relative to the run, digests and the 72 route definitions.
- `ROUTES.json`: binding acceptance/reason, executor verdict, source verification,
  read count and claimed write, with those stages kept distinct.
- `effects.sqlite`: actual durable records including amount, date, cost center,
  semantic note, candidate id, and stored/consumed source digests.
- `EFFECTS.json`: independently read SQL rows, ordered by route.
- `grid.csv`: actual effects and semantic mismatches, attribution differences,
  binding rejections and execution stops separately for each route.
- `SCORE.json`: counts per binding/executor and per fixture, with denominators.
- `CHECKS.json`: readback integrity, negative value controls and copied-database
  deletion/addition/change detection results.
- `ENVIRONMENT.json`: Python/SQLite versions and protocol/source/fixture hashes.
- `rawdocs/`: retained reviewed and actual live bytes.
- `oracle-mutations/`: the three deliberately modified sink copies and diagnostics.

`score_x2.py` imports no runner, binding, projection or normalizer code. It opens
SQLite in read-only URI mode and enables query-only. Business violations come from
SQL fields compared directly against explicit pre-execution approved-effect
values. Logs are used solely to test consistency between claimed and durable
execution. For an additional recorder check, the scorer independently reconstructs
the prescribed executed payload from submitted fixture fields and preserved live
bytes, using its own Decimal parsing. This detects a changed SQL row without
mistaking the legitimate observed C3 999 write for corruption.

The runner invokes that same scorer on separate copies containing a deleted row,
an extra row or a changed amount. All must fail validation; actual run sinks are
never changed for these tests. Attribution-policy differences are counted
separately from semantic violations. Instance-policy rejections mean the recorded
binding reason is a candidate-id mismatch; a semantic projection rejection in the
instance arm is counted as such instead. No rejection is automatically labeled a
false positive.

Semantic JSON and CSV artifacts contain neither execution timestamps nor absolute
output/source paths and can be compared across independent fresh runs.
