"""An independent effect sink.

The point of the sink is that "did the business write happen" is read from a
separate SQLite file written by the executor, never inferred from the gate's
return value. This is the rule from the protocol: an error response is not
evidence that no execution occurred.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS effects (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id TEXT NOT NULL,
    mechanism TEXT NOT NULL,
    record_id TEXT NOT NULL,
    field_name TEXT NOT NULL,
    value_json TEXT NOT NULL,
    instance_id TEXT NOT NULL,
    effective_date TEXT,
    cost_center TEXT,
    call_id TEXT,
    note TEXT,
    raw_json TEXT
)
"""


def open_sink(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def write_effect(conn: sqlite3.Connection, effect: dict) -> int:
    cur = conn.execute(
        "INSERT INTO effects (case_id, mechanism, record_id, field_name, value_json, instance_id,"
        " effective_date, cost_center, call_id, note, raw_json)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (
            effect["case_id"],
            effect["mechanism"],
            effect["record_id"],
            effect["field_name"],
            json.dumps(effect.get("value"), ensure_ascii=False),
            effect["instance_id"],
            str(effect.get("effective_date")) if effect.get("effective_date") is not None else None,
            str(effect.get("cost_center")) if effect.get("cost_center") is not None else None,
            effect.get("call_id"),
            effect.get("note"),
            json.dumps(effect.get("raw", {}), ensure_ascii=False, sort_keys=True),
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def read_effects(path: Path) -> list[dict]:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    rows = [dict(r) for r in conn.execute("SELECT * FROM effects ORDER BY seq")]
    conn.close()
    for r in rows:
        r["value"] = json.loads(r.pop("value_json"))
        r["raw"] = json.loads(r.pop("raw_json"))
    return rows
