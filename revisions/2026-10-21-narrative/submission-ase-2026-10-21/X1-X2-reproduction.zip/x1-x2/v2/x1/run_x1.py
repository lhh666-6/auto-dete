"""Corrected, offline X1: released HITL middleware and interrupt transport.

Run with --output-dir pointing to a directory that does not already exist.
All business effects are independently read from SQLite with mode=ro.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import importlib.metadata as md
import inspect
import json
import platform
import sqlite3
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from common.sink import open_sink, write_effect  # noqa: E402
from langchain.agents.middleware import HumanInTheLoopMiddleware  # noqa: E402
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage  # noqa: E402
from langgraph.checkpoint.memory import InMemorySaver  # noqa: E402
from langgraph.graph import END, START, MessagesState, StateGraph  # noqa: E402
from langgraph.types import Command, interrupt  # noqa: E402

PINNED = {"langchain": "1.2.10", "langchain-core": "1.2.13", "langgraph": "1.0.8",
          "langgraph-checkpoint": "4.0.0"}
ORIGINAL = {"record": "INV-1000", "field": "amount", "value": 100}
EDITED = {**ORIGINAL, "value": 999}
LC_APPROVE = {"decisions": [{"type": "approve"}]}
LG_APPROVE = {"approve": True}


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8")


def encode(value):
    """Keep raw framework objects inspectable without hiding identifiers."""
    if isinstance(value, BaseMessage):
        return value.model_dump(mode="json")
    if hasattr(value, "_asdict"):
        return encode(value._asdict())
    if dataclasses.is_dataclass(value):
        return encode(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return repr(value)


def read_sql(path, case_id=None):
    """Independent readback: never use gate return values to count effects."""
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as conn:
        conn.row_factory = sqlite3.Row
        if case_id is None:
            rows = conn.execute("SELECT * FROM effects ORDER BY seq").fetchall()
        else:
            rows = conn.execute("SELECT * FROM effects WHERE case_id=? ORDER BY seq", (case_id,)).fetchall()
        result = []
        for row in rows:
            row = dict(row)
            row["value"] = json.loads(row.pop("value_json"))
            row["raw"] = json.loads(row.pop("raw_json"))
            result.append(row)
        return result


def layers(mechanism):
    return {
        "native": (["LangChain HumanInTheLoopMiddleware.after_model and decision validation",
                    "LangGraph interrupt/resume transport and interrupt identifiers"]
                   if mechanism == "langchain-hitl" else
                   ["LangGraph interrupt/resume transport and interrupt identifiers"]),
        "official_configuration": ["InMemorySaver", "thread_id configuration"] +
                                  (["interrupt_on and allowed_decisions"] if mechanism == "langchain-hitl" else []),
        "author_adapter": ["scripted graph and proposals", "SQLite business-effect writer",
                           "scenario inputs and evidence recorder"] +
                          (["execute only latest AI calls without a following matching ToolMessage"]
                           if mechanism == "langchain-hitl" else
                           ["interrupt payload schema", "approve flag and optional args interpretation"]),
    }


def definitions():
    cases = []

    def add(name, mechanism, decisions=None, n=1, mode="single", allowed=None):
        cases.append({"case_id": name, "mechanism": mechanism, "mode": mode,
                      "turns": [[{"id": f"call_t{t}_c{c}", "args": dict(ORIGINAL)}
                                 for c in range(1, n + 1)]
                                for t in range(1, (2 if mode == "two_turn" else 1) + 1)],
                      "decision": decisions, "allowed_decisions": allowed or ["approve", "edit", "reject"]})

    lc = "langchain-hitl"
    add("L1-single-approve", lc, LC_APPROVE)
    add("L1-twins-approve", lc, {"decisions": [{"type": "approve"}, {"type": "approve"}]}, n=2)
    add("L1-twins-approve-reject", lc, {"decisions": [{"type": "approve"}, {"type": "reject"}]}, n=2)
    add("L1-twins-reject-approve", lc, {"decisions": [{"type": "reject"}, {"type": "approve"}]}, n=2)
    add("L1-wrong-count", lc, LC_APPROVE, n=2)
    edit = {"decisions": [{"type": "edit", "edited_action": {"name": "update_field", "args": EDITED}}]}
    add("L1-disallowed-edit", lc, edit, allowed=["approve"])
    add("L1-invalid-type", lc, {"decisions": [{"type": "unknown"}]})
    add("L1-authorized-edit", lc, edit)
    add("L1-same-thread-keyed", lc, LC_APPROVE, mode="two_turn")
    add("L1-same-thread-unkeyed", lc, LC_APPROVE, mode="two_turn")
    add("L1-completed-extra-resume", lc, LC_APPROVE, mode="completed")
    lg = "langgraph-interrupt"
    add("L2-approve", lg, LG_APPROVE)
    add("L2-authorized-edit", lg, {"approve": True, "args": EDITED})
    add("L2-same-thread-keyed", lg, LG_APPROVE, mode="two_turn")
    add("L2-same-thread-unkeyed", lg, LG_APPROVE, mode="two_turn")
    add("L2-completed-extra-resume", lg, LG_APPROVE, mode="completed")
    return cases


def payload_fields(payload):
    actions = payload.get("action_requests", [])
    return {"payload_keys": sorted(payload), "action_count": len(actions),
            "action_request_keys": [sorted(a) for a in actions],
            "action_entries_equal": len(actions) > 1 and all(a == actions[0] for a in actions),
            "action_call_id_key_present": any("id" in a or "call_id" in a for a in actions),
            "action_digest_key_present": any(any("digest" in k.lower() for k in a) for a in actions),
            "allowed_decisions": [r["allowed_decisions"] for r in payload.get("review_configs", [])]}


def pending_ids(snapshot):
    return [item.id for task in snapshot.tasks for item in task.interrupts]


def ai_calls(messages):
    return [tc for msg in messages if isinstance(msg, AIMessage) for tc in msg.tool_calls]


class CaseRun:
    def __init__(self, case, conn, sink_path):
        self.case, self.conn, self.sink_path = case, conn, sink_path
        self.raw = {"definition": case, "events": [], "executor_events": []}
        self.observation = {"mechanism": case["mechanism"], "layers": layers(case["mechanism"]), "stages": []}
        self.saver = InMemorySaver()
        self.config = {"configurable": {"thread_id": case["case_id"]}}
        self.graph = self.build()
        self.initial_refs = (self.graph, self.saver, self.config["configurable"]["thread_id"])

    def proposal(self, state):
        turn = sum(isinstance(m, HumanMessage) for m in state["messages"])
        return turn, self.case["turns"][turn - 1]

    def execute(self, call_id, args):
        return write_effect(self.conn, {"case_id": self.case["case_id"], "mechanism": self.case["mechanism"],
                            "record_id": args["record"], "field_name": args["field"], "value": args["value"],
                            "instance_id": "not-modeled", "call_id": call_id,
                            "note": "author-adapter execution", "raw": {"args": args}})

    def build(self):
        builder = StateGraph(MessagesState)
        if self.case["mechanism"] == "langchain-hitl":
            # The public configuration is deliberately explicit, including the restricted control.
            mw = HumanInTheLoopMiddleware(interrupt_on={"update_field": {
                "allowed_decisions": self.case["allowed_decisions"]}})

            def model_node(state):
                turn, proposals = self.proposal(state)
                calls = [{"name": "update_field", "args": dict(c["args"]), "id": c["id"], "type": "tool_call"}
                         for c in proposals]
                return {"messages": [AIMessage(content="", id=f"ai-{turn}", tool_calls=calls)]}

            def hitl_node(state):
                return mw.after_model(state, None) or {}

            def tools_node(state):
                messages = state["messages"]
                ai_index = max(i for i, m in enumerate(messages) if isinstance(m, AIMessage))
                # Reject creates an error ToolMessage while preserving the AI call. That call
                # is already answered. This is message-protocol routing, not a new auth guard.
                answered = {m.tool_call_id for m in messages[ai_index + 1:] if isinstance(m, ToolMessage)}
                pending = [tc for tc in messages[ai_index].tool_calls if tc["id"] not in answered]
                event = {"candidate_call_ids": [tc["id"] for tc in messages[ai_index].tool_calls],
                         "answered_call_ids": sorted(answered), "pending_call_ids": [tc["id"] for tc in pending],
                         "executed_call_ids": []}
                self.raw["executor_events"].append(event)
                output = []
                for tc in pending:
                    self.execute(tc["id"], dict(tc["args"]))
                    event["executed_call_ids"].append(tc["id"])
                    output.append(ToolMessage(content="ok", id=f"result-{tc['id']}",
                                              tool_call_id=tc["id"], name=tc["name"]))
                return {"messages": output}

            builder.add_node("model", model_node)
            builder.add_node("hitl", hitl_node)
            builder.add_node("tools", tools_node)
            builder.add_edge(START, "model")
            builder.add_edge("model", "hitl")
            builder.add_edge("hitl", "tools")
            builder.add_edge("tools", END)
        else:
            def approve_node(state):
                turn, proposals = self.proposal(state)
                proposed = proposals[0]
                # Schema and decision meaning belong entirely to this author adapter.
                answer = interrupt({"action": "set amount", "args": dict(proposed["args"]),
                                    "record": proposed["args"]["record"]})
                chosen = dict(answer.get("args", proposed["args"]))
                event = {"turn": turn, "answer": answer, "chosen_args": chosen, "executed_call_ids": []}
                self.raw["executor_events"].append(event)
                if answer.get("approve"):
                    self.execute(proposed["id"], chosen)
                    event["executed_call_ids"].append(proposed["id"])
                return {"messages": [AIMessage(content=json.dumps(answer, sort_keys=True), id=f"answer-{turn}")]}

            builder.add_node("approval", approve_node)
            builder.add_edge(START, "approval")
            builder.add_edge("approval", END)
        return builder.compile(checkpointer=self.saver)

    def invoke(self, label, input_value):
        before = len(read_sql(self.sink_path, self.case["case_id"]))
        result, error = None, None
        try:
            result = self.graph.invoke(input_value, self.config)
        except Exception as exc:
            error = {"type": type(exc).__name__, "message": str(exc)}
        snapshot = self.graph.get_state(self.config)
        history = list(self.graph.get_state_history(self.config))
        after = len(read_sql(self.sink_path, self.case["case_id"]))
        stage = {"label": label, "effects_before": before, "effects_after": after,
                 "effect_delta": after - before, "error_type": error["type"] if error else None,
                 "pending_interrupt_count": len(pending_ids(snapshot)), "pending_node_count": len(snapshot.next),
                 "returned_interrupt_count": len((result or {}).get("__interrupt__", []))}
        self.observation["stages"].append(stage)
        self.raw["events"].append({"label": label, "input": encode(input_value), "result": encode(result),
                                   "error": error, "snapshot": encode(snapshot), "history": encode(history),
                                   "runtime_object_identity": {"graph": id(self.graph), "saver": id(self.saver),
                                                               "graph_checkpointer": id(self.graph.checkpointer),
                                                               "thread_id": self.config["configurable"]["thread_id"]},
                                   "effect_counts": {"before": before, "after": after}})
        return snapshot

    def first_pending(self, snapshot):
        items = [item for task in snapshot.tasks for item in task.interrupts]
        if len(items) != 1:
            raise RuntimeError(f"Scenario requires exactly one batch interrupt; found {len(items)}")
        return items[0]

    def run(self):
        case = self.case
        first = self.invoke("turn1_propose", {"messages": [HumanMessage("set amount", id="human-1")]})
        first_interrupt = self.first_pending(first)
        first_id = first_interrupt.id
        self.raw["interrupt_ids"] = {"turn1": first_id}
        self.observation["initial_interrupt_id_present"] = bool(first_id)
        if case["mechanism"] == "langchain-hitl":
            self.observation["review_payload"] = payload_fields(first_interrupt.value)
        else:
            payload = first_interrupt.value
            self.observation["review_payload"] = {
                "payload_keys": sorted(payload), "payload_layer": "author_adapter",
                "has_call_id_key": "id" in payload or "call_id" in payload,
                "has_digest_key": any("digest" in k.lower() for k in payload),
                "reviewed_args": payload.get("args")}

        if case["mode"] == "two_turn":
            keyed = case["case_id"].endswith("-keyed")
            first_resume_value = {first_id: case["decision"]} if keyed else case["decision"]
            self.invoke("turn1_current_key_approve" if keyed else "turn1_unkeyed_approve",
                        Command(resume=first_resume_value))
            second = self.invoke("turn2_propose", {"messages": [HumanMessage("set amount again", id="human-2")]})
            second_interrupt = self.first_pending(second)
            current_id = second_interrupt.id
            self.raw["interrupt_ids"]["turn2"] = current_id
            self.observation["same_graph_object"] = self.graph is self.initial_refs[0]
            self.observation["same_saver_object"] = self.saver is self.initial_refs[1]
            self.observation["graph_uses_same_saver"] = self.graph.checkpointer is self.saver
            self.observation["same_thread_id"] = self.config["configurable"]["thread_id"] == self.initial_refs[2]
            self.observation["turn_interrupt_ids_differ"] = first_id != current_id
            self.observation["turn_proposal_args_equal"] = case["turns"][0][0]["args"] == case["turns"][1][0]["args"]
            self.observation["turn_call_ids_differ"] = case["turns"][0][0]["id"] != case["turns"][1][0]["id"]
            self.observation["first_review_payload_equals_second"] = first_interrupt.value == second_interrupt.value
            if keyed:
                old_result = self.invoke("turn2_old_key_approve", Command(resume={first_id: case["decision"]}))
                remaining = pending_ids(old_result)
                self.raw["interrupt_ids"]["after_old_key"] = remaining
                self.observation["current_interrupt_still_pending_after_old_key"] = current_id in remaining
                self.observation["pending_ids_unchanged_after_old_key"] = remaining == [current_id]
                self.observation["current_key_submitted_after_old_key"] = bool(remaining)
                if remaining:
                    post_old_current_id = self.first_pending(old_result).id
                    self.raw["interrupt_ids"]["current_key_used_after_old"] = post_old_current_id
                    self.observation["post_old_current_id_equals_turn2_id"] = post_old_current_id == current_id
                    self.invoke("turn2_current_key_approve", Command(resume={post_old_current_id: case["decision"]}))
            else:
                self.invoke("turn2_unkeyed_approve", Command(resume=case["decision"]))
                self.observation["same_unkeyed_payload_resubmitted"] = (
                    self.raw["events"][1]["input"]["resume"] == self.raw["events"][-1]["input"]["resume"])
                self.observation["interpretation"] = "Unkeyed affirmative approval is a newly supplied input; no stolen business grant is modeled."
        else:
            self.invoke("decision", Command(resume=case["decision"]))
            if case["mode"] == "completed":
                before_extra = self.graph.get_state(self.config)
                self.observation["completed_before_extra_resume"] = not before_extra.next
                self.observation["no_interrupt_before_extra_resume"] = not pending_ids(before_extra)
                self.invoke("completed_extra_resume", Command(resume=case["decision"]))

        final = self.graph.get_state(self.config)
        history = list(self.graph.get_state_history(self.config))
        effects = read_sql(self.sink_path, case["case_id"])
        self.observation["effects"] = [{"call_id": e["call_id"], "value": e["value"]} for e in effects]
        self.observation["effect_count"] = len(effects)
        self.observation["history_snapshot_count"] = len(history)
        self.observation["final_pending_interrupt_count"] = len(pending_ids(final))
        self.observation["final_pending_node_count"] = len(final.next)
        self.observation["executor_events"] = self.raw["executor_events"]
        if case["case_id"] == "L1-authorized-edit":
            final_calls = ai_calls(final.values["messages"])
            history_calls = [c for h in history for c in ai_calls(h.values.get("messages", []))]
            history_reviews = [i.value for h in history for t in h.tasks for i in t.interrupts]
            self.observation["authorized_edit"] = {
                "reviewed_args": first_interrupt.value["action_requests"][0]["args"],
                "submitted_edited_args": case["decision"]["decisions"][0]["edited_action"]["args"],
                "final_tool_calls": final_calls,
                "call_id_preserved": bool(final_calls) and final_calls[0]["id"] == case["turns"][0][0]["id"],
                "original_proposal_in_final_messages": any(c["args"] == ORIGINAL for c in final_calls),
                "original_proposal_in_checkpoint_history": any(c["args"] == ORIGINAL for c in history_calls),
                "original_review_payload_in_checkpoint_history": first_interrupt.value in history_reviews,
                "checkpoint_storage": "InMemorySaver; process-lifetime history only"}
        self.raw["final_history"] = encode(history)
        return self.observation, self.raw


def checks(cases, observations, evidence, effects, versions):
    rows = []

    def check(name, value, detail=None):
        row = {"name": name, "passed": bool(value)}
        if detail is not None:
            row["detail"] = detail
        rows.append(row)

    check("pinned_dependency_versions", versions == PINNED)
    check("all_defined_conditions_executed", set(observations) == {c["case_id"] for c in cases})
    for case in cases:
        name = case["case_id"]
        o, raw = observations[name], evidence[name]
        sql = [e for e in effects if e["case_id"] == name]
        check(f"{name}:layers_present", all(k in o["layers"] for k in ("native", "official_configuration", "author_adapter")))
        check(f"{name}:sql_effects_match_observation", o["effects"] == [{"call_id": e["call_id"], "value": e["value"]} for e in sql])
        check(f"{name}:executor_log_matches_sql", [c for event in raw["executor_events"] for c in event["executed_call_ids"]] == [e["call_id"] for e in sql])
        check(f"{name}:raw_stage_counts_match", all(s["effects_before"] == r["effect_counts"]["before"] and
                                                    s["effects_after"] == r["effect_counts"]["after"]
                                                    for s, r in zip(o["stages"], raw["events"]))
                                                   and len(o["stages"]) == len(raw["events"]))
        check(f"{name}:stage_effect_deltas_reconcile", sum(s["effect_delta"] for s in o["stages"]) == len(sql))
        check(f"{name}:initial_interrupt_and_no_initial_write", o["initial_interrupt_id_present"] and o["stages"][0]["effect_delta"] == 0)
        if case["mode"] == "two_turn":
            check(f"{name}:same_graph_saver_thread", all(o[k] for k in ("same_graph_object", "same_saver_object", "graph_uses_same_saver", "same_thread_id")))
            check(f"{name}:raw_runtime_identity_unchanged", all(
                event["runtime_object_identity"] == raw["events"][0]["runtime_object_identity"]
                for event in raw["events"]))
            check(f"{name}:first_turn_completed_before_second", raw["events"][1]["snapshot"]["next"] == [])
            check(f"{name}:two_actual_human_turns", sum(m["type"] == "human" for m in raw["events"][2]["snapshot"]["values"]["messages"]) == 2)
            check(f"{name}:same_args_distinct_call_ids", o["turn_proposal_args_equal"] and o["turn_call_ids_differ"])
        if case["mode"] == "completed":
            check(f"{name}:completed_boundary_exercised", o["completed_before_extra_resume"] and o["no_interrupt_before_extra_resume"])
    # These controls validate the author executor, not an asserted business-authorization theorem.
    for name, expected in [("L1-twins-approve-reject", ["call_t1_c1"]),
                           ("L1-twins-reject-approve", ["call_t1_c2"])]:
        check(f"{name}:answered_calls_not_reexecuted", [e["call_id"] for e in observations[name]["effects"]] == expected)
    return {"passed": all(r["passed"] for r in rows), "checks": rows,
            "scope": "Scenario construction and artifact agreement; measured native runtime outcomes are preserved in observations."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    try:
        output.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error(f"Refusing to overwrite existing output directory: {output}")
    versions = {p: md.version(p) for p in PINNED}
    source_files = {"x1/run_x1.py": Path(__file__).resolve(), "common/sink.py": ROOT / "common/sink.py",
                    "PROTOCOL.md": ROOT / "PROTOCOL.md",
                    "installed/human_in_the_loop.py": Path(inspect.getsourcefile(HumanInTheLoopMiddleware)),
                    "installed/types.py": Path(inspect.getsourcefile(interrupt))}
    metadata = {"versions": versions, "python": platform.python_version(), "executable": sys.executable,
                "started_utc": datetime.now(timezone.utc).isoformat(), "model_calls": 0, "network_calls": 0,
                "source_sha256": {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in source_files.items()}}
    dump(output / "environment.json", metadata)
    cases = definitions()
    dump(output / "CASES.json", {"conditions": cases, "declared_before_execution": True})
    sink_path = output / "effects.sqlite"
    conn = open_sink(sink_path)
    observations, evidence = {}, {}
    try:
        for case in cases:
            run = CaseRun(case, conn, sink_path)
            observations[case["case_id"]], evidence[case["case_id"]] = run.run()
        conn.close()
        effects = read_sql(sink_path)
        report = checks(cases, observations, evidence, effects, versions)
        dump(output / "OBSERVATIONS.json", {"schema_version": 2, "versions": versions,
             "mechanisms": ["langchain-hitl", "langgraph-interrupt"], "conditions": observations,
             "untested": ["post-approval unauthorized mutation injector", "authenticated business grants",
                          "durable approval history after process termination", "hosted model behavior"]})
        dump(output / "RAW-EVIDENCE.json", evidence)
        dump(output / "EFFECTS.json", effects)
        dump(output / "CHECKS.json", report)
        print(json.dumps({"output_dir": str(output), "passed": report["passed"],
                          "condition_count": len(observations), "effect_count": len(effects)}))
        return 0 if report["passed"] else 1
    except Exception as exc:
        conn.close()
        if "run" in locals():
            evidence[run.case["case_id"]] = run.raw
        dump(output / "RAW-EVIDENCE.json", evidence)
        dump(output / "CHECKS.json", {"passed": False, "harness_error": type(exc).__name__,
                                      "message": str(exc), "traceback": traceback.format_exc()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
