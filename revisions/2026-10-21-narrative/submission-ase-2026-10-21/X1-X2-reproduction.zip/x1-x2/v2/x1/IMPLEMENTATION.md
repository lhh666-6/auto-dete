# X1 version 2 implementation

`run_x1.py --output-dir <fresh-directory>` executes 16 bounded conditions with no model or network calls. An existing output directory is rejected. Dependency versions must equal the protocol pins for `CHECKS.json` to pass. The root integration runner invokes this CLI and performs the final independent pair of runs.

## Attribution and execution

The LangChain path calls the installed, unmodified `HumanInTheLoopMiddleware.after_model`. `interrupt_on`, allowed-decision settings, `InMemorySaver`, and thread configuration are official configuration. The scripted graph, pending-tool executor, and SQLite writer are author adapters.

In this middleware version a reject decision preserves the AI tool call and appends a matching error `ToolMessage`. The author executor treats calls with matching tool-result messages after the latest AI message as answered, and executes only unresolved calls. It does not interpret an approval decision or introduce an authentication guard. Raw executor evidence records candidate, answered, pending, and executed call IDs. The mixed controls exercise both positional orders. These runs evaluate middleware plus this explicit adapter, not an unmodified native agent executor.

The LangGraph path supplies its own `{action, args, record}` payload. Its author-written node interprets an `approve` flag and optional replacement `args`. Only pause/resume transport and interrupt IDs are native primitive behavior. Executing 999 in that path is a result of the declared adapter rule.

## Conditions

| Condition | Input sequence |
| --- | --- |
| L1-single-approve | One pending call, approve |
| L1-twins-approve | Two same-argument calls, two positional approvals |
| L1-twins-approve-reject | Approve first, reject second |
| L1-twins-reject-approve | Reject first, approve second |
| L1-wrong-count | Two calls, one decision |
| L1-disallowed-edit | Approve-only configuration, edit decision |
| L1-invalid-type | Unknown decision type |
| L1-authorized-edit | Explicit permitted edit from 100 to 999 |
| L1/L2-same-thread-keyed | First current-ID approval; new human turn and new call ID with same arguments; old-ID approval; if pending, actual current-ID approval |
| L1/L2-same-thread-unkeyed | First unkeyed approval; new human turn; identical unkeyed payload supplied again |
| L1/L2-completed-extra-resume | Approve to completion, then extra resume with no new human turn |
| L2-approve | Author node accepts `approve: true` and uses original args |
| L2-authorized-edit | Author node accepts `approve: true` with supplied args 999 |

The same-thread branches retain one compiled graph, its original saver, and one thread. Raw per-stage evidence stores their process object IDs and thread ID, as well as checkpoint and interrupt IDs. The first approval completes before the second human turn begins. The unkeyed branch supplies a new affirmative input; it does not model a stolen or authenticated business grant.

## Artifacts and checks

- `CASES.json` saves definitions and decision inputs before execution.
- `OBSERVATIONS.json` contains stable semantic measurements, SQL effect counts before/after every invocation, error classes, layer labels, ID relationship booleans, final effects, and history findings. Framework-generated IDs and timestamps are excluded.
- `RAW-EVIDENCE.json` preserves invocation inputs/results, exception messages, native IDs, checkpoint history after every stage, final history, and adapter executor events.
- `effects.sqlite` stores only actual committed tool-body effects. `EFFECTS.json` reads all rows through a separate `mode=ro` connection.
- `environment.json` records versions, Python, protocol hash, runner/common source hashes, and installed middleware/interrupt source hashes.
- `CHECKS.json` checks scenario construction and artifact agreement: same objects/thread, actual two human turns, completed-run boundaries, execution-log/SQL agreement, count reconciliation, and mixed-control routing. It does not assert an authorization theorem or force native runtime outcomes to favor a claim.

The original proposal and original review payload are searched in `get_state_history` after the authorized edit; final messages are inspected separately. Availability in `InMemorySaver` establishes process-lifetime checkpoint history only.

Post-approval unauthorized mutation, authenticated business grants, durable history after process termination, and hosted model behavior remain explicitly untested. This authorized-edit condition does not substitute for a post-approval mutation experiment.

## Local development observations

The first two development runs produced 18 SQL effects across the 16 conditions, with harness checks passing. Both mechanisms paused the second same-thread turn before a new write. An old keyed ID added no effect and left the current interrupt pending; the current ID then added one effect. Supplying the same unkeyed affirmative payload on the next turn added one effect. Extra resume after completion added none. LangChain's allowed edit wrote 999 under the original call ID; the original 100 proposal and review remained in checkpoint history. Count, disallowed-edit, and invalid-type controls raised `ValueError` without effects. Final integrated run artifacts, rather than these development notes, are the authoritative execution record.
