"""Compare two fresh corrected runs and check preservation of earlier evidence."""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sql_snapshot(path: Path) -> dict:
    """Read every user table from the actual database in SQLite read-only mode."""
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as conn:
        tables = [row[0] for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )]
        result = {}
        for table in tables:
            identifier = '"' + table.replace('"', '""') + '"'
            cursor = conn.execute(f"SELECT * FROM {identifier}")
            columns = [item[0] for item in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor]
            result[table] = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))
        return result


def hash_mismatches(manifest: Path, base: Path) -> list:
    problems = []
    for relative, expected in load(manifest).items():
        path = base / relative
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual != expected:
            problems.append({"path": relative, "expected": expected, "actual": actual})
    return problems


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--first", type=Path, required=True)
    parser.add_argument("--second", type=Path, required=True)
    parser.add_argument("--report", type=Path, default=ROOT / "VERIFICATION.json")
    args = parser.parse_args()
    first, second = args.first.resolve(), args.second.resolve()
    checks = []
    for run in (first, second):
        metadata = load(run / "RUN.json")
        checks.append({"check": f"{run.name}:runner_exit_codes",
                       "passed": all(item["exit_code"] == 0 for item in metadata["results"])})
        for experiment in ("x1", "x2"):
            results = load(run / experiment / "CHECKS.json")
            checks.append({"check": f"{run.name}:{experiment}:internal_checks",
                           "passed": results["passed"] is True})
    semantic_files = {
        "x1": ["OBSERVATIONS.json", "EFFECTS.json"],
        "x2": ["SCORE.json", "CASES.json", "EFFECTS.json", "grid.csv"],
    }
    for experiment, names in semantic_files.items():
        for name in names:
            a, b = first / experiment / name, second / experiment / name
            identical = load(a) == load(b) if a.suffix == ".json" else a.read_bytes() == b.read_bytes()
            checks.append({"check": f"{experiment}:{name}:deterministic", "passed": identical})
        a = sql_snapshot(first / experiment / "effects.sqlite")
        b = sql_snapshot(second / experiment / "effects.sqlite")
        checks.append({"check": f"{experiment}:sqlite_rows:deterministic", "passed": a == b})
    old_problems = hash_mismatches(ROOT / "PREVIOUS-VERSION-HASHES.json", ROOT.parent)
    paper_problems = hash_mismatches(ROOT / "PROTECTED-MANUSCRIPT-HASHES.json", REPOSITORY)
    checks.extend([
        {"check": "version_1_files_unchanged", "passed": not old_problems},
        {"check": "manuscript_files_unchanged", "passed": not paper_problems},
    ])
    report = {
        "passed": all(item["passed"] for item in checks),
        "runs": [str(first), str(second)],
        "checks": checks,
        "version_1_mismatches": old_problems,
        "manuscript_mismatches": paper_problems,
        "comparison_scope": "Semantic JSON/CSV and actual SQL rows. Raw randomized framework ids are retained but not compared byte-for-byte.",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("VERIFIED" if report["passed"] else "VERIFICATION FAILED")
    print(args.report.resolve())
    for check in checks:
        if not check["passed"]:
            print("FAILED", check["check"])
    return int(not report["passed"])


if __name__ == "__main__":
    raise SystemExit(main())
