# Corrected X1/X2 offline experiments

This version corrects the scenario and claim mismatches found in the initial study. The parent directory's original sources and runs are retained as historical artifacts. Use this directory for the corrected experiment, not the earlier RESULTS.md.

Read `PROTOCOL.md` for the fixed conditions and scope. The protocol is an amendment after inspecting the initial results, not a claim of preregistration before those observations. Python 3.11 and the pinned packages in `requirements.txt` are used. X2 itself uses the standard library. No API keys or hosted model calls are required.

From the repository root, run twice into new directories. Output directories must not already exist.

```text
python research/ase-x1-x2-2026-10-21/v2/run_all.py --output-dir research/ase-x1-x2-2026-10-21/v2/runs/reproduction-1
python research/ase-x1-x2-2026-10-21/v2/run_all.py --output-dir research/ase-x1-x2-2026-10-21/v2/runs/reproduction-2
python research/ase-x1-x2-2026-10-21/v2/verify.py --first research/ase-x1-x2-2026-10-21/v2/runs/reproduction-1 --second research/ase-x1-x2-2026-10-21/v2/runs/reproduction-2
python research/ase-x1-x2-2026-10-21/v2/summarize.py
```

The two experiments run real local framework and persistence paths with scripted inputs. They do not measure autonomous model behavior, human approval cost, natural incident prevalence, or the complete manuscript contract.

- X1 separates middleware behavior, official configuration, and the author-written graph/tool adapter. Cross-turn tests retain the same graph, saver, and thread. Raw interrupt/checkpoint identifiers are retained for inspection; determinism compares their relationships rather than randomized identifier bytes.
- X2 separates candidate binding from a common document-verifying executor. Its independent scorer reads approved fixtures and persisted business effects without importing the gate implementation. Both verified and unchecked execution are applied to every binding arm. Normalization is explicitly local to this experiment.

The versioned results summary, verification receipt, run source hashes, raw inputs, and SQLite files provide the evidence trail. `PREVIOUS-VERSION-HASHES.json` records the untouched version-1 artifacts. No manuscript or previously submitted experimental ledger is edited by these runners.

## Delivered evidence

- `RESULTS.md` is generated from the verified run pair.
- `runs/final-1/` and `runs/final-2/` contain the final independent executions. Development outputs have `dev` in their names and are not used for the reported results.
- `VERIFICATION.json` records deterministic semantic artifacts, actual SQL rows and protected-file hashes.
- `AUDIT.md` records a separate review of the code and independent SQL/raw-event readback. Its helper and detailed receipts reside in the repository's review directory identified there.
- `x2/score_x2.py --run-dir <run>/x2` recomputes scores without changing the sink or importing the gate implementation. Add `--output-dir <fresh-directory>` to save a separate readback.

The corrected version retains the original tests' useful observations, while fixing their interpretation. A new graph is no longer labeled a later turn. Authorized edits and checkpoint retention are measured separately. LangGraph payload schema is attributed to the adapter. Referent changes now affect actual tool inputs and durable business values. Binding rejection, executor verification stop and business-state violation are separate outcomes.
