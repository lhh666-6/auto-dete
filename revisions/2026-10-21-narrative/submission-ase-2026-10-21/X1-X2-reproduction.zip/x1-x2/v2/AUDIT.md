# Independent audit of corrected X1/X2 v2

Date: 2026-10-21. Verdict: **PASS within the declared deterministic scope. No confirmed correctness error or blocking protocol defect found in the final v2 implementations and final-1/final-2 artifacts.**

This audit reviewed v2/PROTOCOL.md, both runners, the X2 scorer, the shared X1 sink, integration/verification code, implementation notes, final run evidence, and the generated RESULTS.md. The earlier X1 audit was read only to identify relevant correction criteria; its findings were not treated as findings about v2. This reviewer did not modify sources, fixtures, real sinks, or measured results. Review code and receipts are under `reviews/x1x2-v2-audit-2026-10-21/` at the repository root.

## Independent verification performed

- Ran the separate audit helper `readback.py` against both final run directories. It imports no experiment implementation. **61 checks passed per run**, including actual read-only SQLite comparisons, raw old/current resume keys, graph/saver/thread identity, two human turns, X2 semantic-count reconstruction, and C3 file digests. Each run contains **18 X1 effects and 34 X2 effects**.
- Re-executed `score_x2.py` in read-only mode against each actual final X2 sink: both passed, with no issues. Re-executed it against each final run's three deliberately modified sink copies: deletion, addition, and amount alteration were detected in all **six** copies. Actual sinks were not changed.
- Checked current executable sources, protocol, dependency list, and implementation notes against both recorded RUN.json manifests: they match. README.md was updated after execution with final-result navigation; its recorded run-time hash consequently differs. This documentation-only change does not alter the executed code or fixtures. The generated RESULTS.md and this audit were added after execution.
- Inspected VERIFICATION.json: both fresh runs passed, semantic JSON/CSV and actual SQL rows agree, and the protected v1/manuscript hashes are unchanged. The independent SQL reconstruction agrees with the reported X2 results.

Receipts: `READBACK.json` and `SCORER-AND-HASHES.json` in the review directory. The latter deliberately retains the post-run README hash difference instead of hiding it.

## X1: scenario identity and attribution

**Same-thread behavior is actually exercised.** `x1/run_x1.py:145–157` constructs one graph, saver and thread per condition. The two-turn branch reuses them, adds a second HumanMessage, saves the raw input and runtime identities, and submits the observed old interrupt ID before the observed current ID (`x1/run_x1.py:227–303`). Independent inspection of the final raw records confirms one completed first turn and two human messages in the second-turn snapshot. In both mechanisms, the second proposal added zero effects, old-ID input added zero and retained the current interrupt, and current-ID input added one. The separate unkeyed branch supplies the same affirmative value anew; its second input added one effect. These observations establish the tested routing behavior, not authenticated business-grant semantics.

**Authorized editing and history are separated.** The input is an explicit edit from 100 to 999 (`x1/run_x1.py:111–114`), rather than an approved 100 changed secretly afterward. The actual SQL row contains 999. Final messages and checkpoint history are inspected separately (`x1/run_x1.py:324–336`): final messages have the edited arguments under the original call ID, while earlier checkpoints retain the original proposal and review payload. The reported history is process-lifetime InMemorySaver history. Post-approval unauthorized mutation remains expressly untested (`x1/run_x1.py:413–416`).

**Batch and control outcomes are supported.** Two equal action-request entries still have distinct list positions. The two mixed controls actually execute c1 and c2 respectively. Wrong decision count, disallowed edit and invalid type raise ValueError with no effects. The author executor skips calls already answered by a matching ToolMessage after the latest AI message (`x1/run_x1.py:181–198`); this necessary adapter behavior is recorded and attributed explicitly, not described as an unmodified native tool executor.

**Layers and outcome checks are appropriately bounded.** Installed middleware decisions and primitive transport are separated from official configuration and author graph/tool/payload behavior (`x1/run_x1.py:79–92`, `:165–225`). LangGraph's payload schema and optional replacement-argument interpretation are author code. Completed-run extra resumes are separate conditions. X1 checks enforce scenario construction, mixed-control routing and artifact agreement; they do not require the old-key result to favor a manuscript claim (`x1/run_x1.py:341–380`).

## X2: comparator fairness, actual referent consumption and oracle

**The principal arms differ in declared binding scope.** Every arm has the same value guard. Context uses K, content uses R, and instance adds candidate ID to K; the raw-content route is marked diagnostic (`x2/run_x2.py:22–26`, `:60–78`). Content digests use the declared projection. Money normalization, semantic-note inclusion and rendering/key-order exclusions are explicit; this is a local equality relation rather than the manuscript's canonical JSON equality.

**C3 performs the stated file operation.** Reviewed bytes are retained read-only with recorded digests; candidate fields and ID stay identical. Both changed and unchanged cases use `set_amount_from_document` (`x2/run_x2.py:83–110`). CASES.json is saved before the live-file mutation. The shared executor reads the live bytes once, hashes them, and derives the written amount from those bytes. Verified mode stops before SQL on digest mismatch and parses the same captured bytes if validation succeeds (`x2/run_x2.py:169–197`, `:243–250`). This removes a check/use reread gap in this single-process path. It does not establish a distributed or concurrent transaction guarantee.

All four bindings accept the same-ID C3 candidate. Unchecked execution actually persists 999.00 for the changed document; verified execution writes nothing. The matched unchanged-document control persists 101.00 in both modes for all four bindings. Consequently the referent-protection result belongs to the common executor check, not to instance binding.

**The semantic oracle is independent of the gate implementation.** `x2/score_x2.py` imports only standard-library modules, opens SQLite read-only (`:45–55`), validates retained source bytes (`:62–102`), and derives semantic mismatches by directly comparing SQL fields with pre-execution approved_effect fields (`:143–145`). Log/SQL disagreement and reconstructed-execution disagreement are separate checks (`:105–142`). Legitimate C3 999 effects remain measured semantic violations; changing a stored amount to 777 instead produces a recorder inconsistency. No arm name or binding acceptance label defines semantic truth.

Independent readback reproduced these counts, each out of **nine specified fixtures per binding/mode**:

| Binding | Unchecked semantic violations | Verified semantic violations | Unchecked / verified writes |
| --- | ---: | ---: | ---: |
| context | 4 | 3 | 8 / 7 |
| content | 1 | 0 | 5 / 4 |
| instance | 1 | 0 | 2 / 1 |
| content_raw diagnostic | 1 | 0 | 4 / 3 |

The remaining three context violations are changed effective date/cost center fixtures outside K. Attribution-policy differences and same-semantics rejections remain separate from semantic violations. The 72 crossed routes are not 72 independent tasks, and an instance-policy rejection is not automatically a false positive.

## Scope and completion

The generated RESULTS.md is consistent with the inspected artifacts and preserves the main attribution and denominator limits. These are offline scripted experiments, not hosted-agent or human-review measurements. They do not implement the complete manuscript guard G, estimate natural incident prevalence, measure human approval cost, or test durable approval-history retention, concurrent replay, authenticated grants, or unauthorized post-approval mutation. Those exclusions are disclosed and are scope boundaries, not unresolved failures of the present protocol.

No additional experiment or source change is required to complete this bounded v2 execution.
