"""Generate corrected results from a verified pair of experiment runs."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verification", type=Path, default=ROOT / "VERIFICATION.json")
    parser.add_argument("--output", type=Path, default=ROOT / "RESULTS.md")
    args = parser.parse_args()
    verification = load(args.verification)
    if not verification["passed"]:
        raise SystemExit("Cannot publish a verified-results summary from a failed verification.")
    run = Path(verification["runs"][1])
    one, two = load(run / "x1/OBSERVATIONS.json"), load(run / "x2/SCORE.json")
    first_effects = load(run / "x1/EFFECTS.json")
    checks1, checks2 = load(run / "x1/CHECKS.json"), load(run / "x2/CHECKS.json")
    with (run / "x2/grid.csv").open(encoding="utf-8", newline="") as handle:
        grid = list(csv.DictReader(handle))
    cond = one["conditions"]

    def stage(case, label):
        return next(item for item in cond[case]["stages"] if item["label"] == label)

    def truth(value):
        return "是" if value else "否"

    def effects(case):
        return ", ".join(f"{row['call_id']}={row['value']}" for row in cond[case]["effects"]) or "无"

    lines = [
        "# X1/X2 修正版实验结果", "", "完成日期 2026-10-21。此报告由通过校验的运行产物生成。",
        f"两次运行见 `{Path(verification['runs'][0]).name}` 与 `{run.name}`；完整路径和逐项检查在 `VERIFICATION.json`。",
        "没有调用模型。原实验文件、运行产物和受保护的稿件文件哈希保持不变。", "",
        "## X1 实际审批对象与同会话续程", "",
        f"共 {len(cond)} 个确定性条件，SQLite 实际记录 {len(first_effects)} 次效果。版本为 " +
        ", ".join(f"{key} {value}" for key, value in one["versions"].items()) + "。",
        "官方中间件和挂起恢复 primitive 未改动。测试图、工具执行器和记录器为作者适配；官方配置、原生行为和适配行为逐条件标注。", "",
        "| 机制 | 第二轮产生新中断 ID | 第二轮提议新增写入 | 旧 ID 恢复新增写入 | 旧 ID 后当前审批仍挂起 | 当前 ID 恢复新增写入 |",
        "|---|---|---:|---:|---|---:|",
    ]
    for prefix, label in (("L1", "LangChain HITL"), ("L2", "LangGraph primitive＋作者节点")):
        key = prefix + "-same-thread-keyed"
        old, proposed = stage(key, "turn2_old_key_approve"), stage(key, "turn2_propose")
        current = [item for item in cond[key]["stages"] if item["label"] == "turn2_current_key_approve"]
        lines.append(f"| {label} | {truth(cond[key]['turn_interrupt_ids_differ'])} | {proposed['effect_delta']} | "
                     f"{old['effect_delta']} | {truth(cond[key]['current_interrupt_still_pending_after_old_key'])} | "
                     f"{current[0]['effect_delta'] if current else '未执行'} |")
    lines += ["", "以上两轮均使用同一个 graph、checkpointer 和 thread，原始 ID 与完整历史另存 RAW-EVIDENCE.json。", "",
              "| 其他条件 | 读回结果 |", "|---|---|"]
    for key, label in (("L1-twins-approve-reject", "同批先批准、后拒绝"),
                       ("L1-twins-reject-approve", "同批先拒绝、后批准"),
                       ("L1-authorized-edit", "明确编辑 100→999")):
        lines.append(f"| {label} | {effects(key)} |")
    edit = cond["L1-authorized-edit"]["authorized_edit"]
    lines.append(f"| 编辑前提议保存在历史 checkpoint | {truth(edit['original_proposal_in_checkpoint_history'])} |")
    lines.append(f"| 编辑前审批 payload 保存在历史 checkpoint | {truth(edit['original_review_payload_in_checkpoint_history'])} |")
    for prefix in ("L1", "L2"):
        key = prefix + "-same-thread-unkeyed"
        lines.append(f"| {prefix} 第二轮再次传入相同的无键批准输入 | 新增 {stage(key, 'turn2_unkeyed_approve')['effect_delta']} 次写入 |")
        key = prefix + "-completed-extra-resume"
        lines.append(f"| {prefix} 已完成后再次 resume | 新增 {stage(key, 'completed_extra_resume')['effect_delta']} 次写入 |")
    for key in ("L1-wrong-count", "L1-disallowed-edit", "L1-invalid-type"):
        result = stage(key, "decision")
        lines.append(f"| {key} | {result['error_type'] or '未报错'}，新增 {result['effect_delta']} 次写入 |")
    payload = cond["L1-twins-approve"]["review_payload"]
    lines += ["", f"相同参数的两个 action-request 条目内容相等为 {truth(payload['action_entries_equal'])}，"
              f"条目包含显式 call-id 键为 {truth(payload['action_call_id_key_present'])}。列表位置仍区分两个决定。",
              "明确编辑是审阅者授权的内容变化，历史保留与最终消息替换可以同时成立。无键批准是调用者在新中断处再次提供的肯定输入，不能等同于旧业务授权被盗用。",
              "这些条件刻画了测试接口中的对象和路由语义，不建立框架存在审批绕过、没有持久授权能力或不能扩展的结论。未做进程重启、并发重放或批准后未授权变更注入。", "",
              "## X2 绑定范围与真实外部依赖", "",
              f"共 {two['case_count']} 个构造案例，跨三种主要绑定方式、一个诊断变体和两种共享执行模式，共 {two['route_count']} 条路线。"
              f"其中主要比较 {two['denominators']['principal_binding_routes']} 条，诊断 {two['denominators']['diagnostic_routes']} 条。这些路线不是独立业务样本。",
              "C3 在审阅后实际修改文件。工具按声明的操作读取文件金额并写入 SQLite；验证模式校验并消费同一份读入字节。未变文档对照使用同样的操作。", "",
              "| 绑定方式 | 未校验外部内容时的语义违规 | 加入共同摘要校验后的语义违规 | 校验执行器停止 | 每种执行模式的案例数 |",
              "|---|---:|---:|---:|---:|"]
    for binding in ("context", "content", "instance", "content_raw"):
        unchecked, verified = two["by_binding"][binding]["unchecked_live"], two["by_binding"][binding]["verified_read"]
        label = binding + ("（诊断变体）" if binding == "content_raw" else "")
        lines.append(f"| {label} | {unchecked['semantic_violation_routes']} | {verified['semantic_violation_routes']} | "
                     f"{verified['executor_stops']} | {unchecked['route_count']} |")
    lines += ["", "| C3 路线 | 绑定判定 | 执行器结果 | 实际持久化金额 |", "|---|---|---|---|"]
    for row in grid:
        if row["class"] not in {"C3", "C3-control"}:
            continue
        lines.append(f"| {row['case_id']} / {row['binding']} / {row['executor_mode']} | "
                     f"{row['binding_accepted']} | {row['executor_verdict']} | {row['actual_amount_decimal2dp'] or '无写入'} |")
    lines += ["", "这组结果将三个问题分开。", "",
              "1. K 遗漏生效日期或成本中心时，语义改变可以通过窄上下文比较。摘要校验外部文件不会补齐 K 中缺少的业务字段。",
              "2. 完整内容比较与实例绑定在这些语义变化案例中都能拒绝；实例绑定还拒绝同内容的新实例。这是责任对象的选择，不是额外的内容安全胜出。",
              "3. 实例身份和候选字段相等本身不校验外部文件。实际文档消费测试中，共享摘要校验使各绑定方式都停止变更文档、放行未变文档。该收益来自共同执行检查。", "",
              "独立评分器只读 SQLite，以执行前保存的 approved_effect 判定实际业务语义，再用独立解析的输入检查记录一致性；不导入 gate、投影或规范化实现。另在数据库副本中删除、新增、修改效果，验证评分器能发现异常。",
              "本测试只实现选定绑定比较器及共同执行器，不是正文完整 G。金额按此实验声明的两位小数规则规范化；不能直接替代正文的 canonical JSON 语义。", "",
              "## 核验与论文用途", "",
              f"X1 内部检查通过为 {truth(checks1['passed'])}；X2 内部检查通过为 {truth(checks2['passed'])}；"
              f"两次完整运行的语义产物与 SQL 内容一致为 {truth(verification['passed'])}。",
              "本轮结果适合补充审批对象和设计选择的比较表。原在线续程实验继续承担 agent 行为和成本证据；本轮没有新增模型恢复率、人工审批成本或自然失配率的结论。", "",
              "完整数据见两次运行的 OBSERVATIONS、CASES、ROUTES、SCORE、grid、RAW-EVIDENCE 及 effects.sqlite。复现命令见 README.md。", ""]
    args.output.write_text("\n".join(lines), encoding="utf-8")
    print(args.output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
