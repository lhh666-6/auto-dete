"""Run both corrected offline experiments into a fresh, named output directory."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    results = []
    for experiment in ("x1", "x2"):
        command = [sys.executable, str(ROOT / experiment / f"run_{experiment}.py"),
                   "--output-dir", str(out / experiment)]
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8",
                                errors="replace", check=False)
        (out / f"{experiment}.stdout.txt").write_text(result.stdout, encoding="utf-8")
        (out / f"{experiment}.stderr.txt").write_text(result.stderr, encoding="utf-8")
        results.append({"experiment": experiment, "exit_code": result.returncode,
                        "output": experiment})
        print(f"{experiment}: exit={result.returncode}, artifacts={out / experiment}")
        if result.returncode:
            print(result.stderr, file=sys.stderr)
    sources = {}
    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT)
        if not path.is_file() or any(part in {"runs", "__pycache__"} for part in relative.parts):
            continue
        if path.suffix in {".py", ".md", ".txt"}:
            sources[relative.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    metadata = {
        "started_utc": started,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "executable": sys.executable,
        "online_model_calls": 0,
        "results": results,
        "source_sha256": sources,
    }
    (out / "RUN.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return int(any(result["exit_code"] != 0 for result in results))


if __name__ == "__main__":
    raise SystemExit(main())
