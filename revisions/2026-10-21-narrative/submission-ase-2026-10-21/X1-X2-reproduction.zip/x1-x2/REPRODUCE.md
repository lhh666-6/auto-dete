# X1/X2 standalone reproduction package

This package contains the corrected version-2 deterministic experiments and their two saved final runs. The protocol was amended after inspecting version-1 observations; it is not a preregistration before those observations. No hosted model or human reviewer is used by these experiments.

`v2/` contains exactly the 111 files named in the original `FINAL-MANIFEST.json`, plus that manifest itself, all copied without changes. Unlisted development runs are excluded. The only new files are this guide and `verify_saved.py`.

## Check the saved evidence without running experiments

Use Python 3.11 and run from the extracted `x1-x2` directory:

```text
python verify_saved.py
```

This needs only the Python standard library. It checks the pinned manifest and all 111 file hashes, compares the two runs' semantic JSON/CSV and actual SQLite rows, and calls the frozen independent `v2/x2/score_x2.py` scorer on both saved databases. The scorer also reads the existing deletion/addition/alteration diagnostic copies. All SQLite connections use read-only mode. The script writes no files, disables bytecode caches, confirms input bytes/inventories are unchanged, and prints a JSON receipt to standard output. Exit code 0 and `"passed": true` indicate success. A shell redirection can save the receipt outside this package.

The package assembly on 21 October 2026 performed this offline readback, including from a fresh extraction of the ZIP. It did **not** execute `run_all.py`, create new experiment runs, install dependencies, or make model calls. Comparing retained run outputs is not a claim of a newly rerun experiment or a new independent-machine replication.

## Execute the experiments again, if desired

Use a Python 3.11 environment and install the frozen dependency versions:

```text
python -m pip install -r v2/requirements.txt
python v2/run_all.py --output-dir reproduction-1
python v2/run_all.py --output-dir reproduction-2
python verify_saved.py --first reproduction-1 --second reproduction-2
```

Both output directories must be new. X1 uses the pinned LangChain/LangGraph packages; X2 uses the standard library. No API key is required. New run directories belong beside `v2/`, so frozen sources and evidence remain unchanged. The `--first` and `--second` arguments accept other run-directory paths too; the verifier continues to authenticate the frozen package while comparing the specified runs. Randomized framework checkpoint/interrupt IDs are retained as raw evidence, while their measured relationships and semantic results are compared.

To read one X2 run independently without saving any files:

```text
python v2/x2/score_x2.py --run-dir reproduction-1/x2
```

## Historical records and scope

Do not run the original `v2/verify.py` main entry point for this standalone package, and do not run `summarize.py` to overwrite frozen results. `VERIFICATION.json`, `PREVIOUS-VERSION-HASHES.json`, `PROTECTED-MANUSCRIPT-HASHES.json`, `RUN.json`, `README.md`, and `RESULTS.md` are preserved historical records. The historical verifier checked the then-current manuscript and version-1 tree. The manuscript has since undergone authorized revision and that external tree is intentionally outside this package; those old hashes are not current manuscript-validation claims. Run metadata records hashes at execution time; the final manifest authenticates delivered file bytes. This guide supersedes the repository-relative reproduction commands in the preserved historical README for use of this standalone package.

X1 characterizes the tested native interrupt interfaces and author adapters. X2 compares selected bindings and a shared document-consuming executor; it does not implement the complete manuscript guard. Neither measures autonomous agent recovery, human review cost, or natural mismatch prevalence. See `v2/PROTOCOL.md`, `v2/RESULTS.md`, and the saved run records for details.
