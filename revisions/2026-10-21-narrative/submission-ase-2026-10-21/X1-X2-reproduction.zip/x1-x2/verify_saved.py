"""Read-only validation of the frozen X1/X2 package and two saved run directories.

Prints one JSON receipt to stdout; never reruns experiments or writes a report.
Only the frozen independent X2 scorer is imported. Python 3.11, standard library.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import platform
import sqlite3
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
V2 = ROOT / "v2"
MANIFEST_SHA256 = "7e850e40e45f2afeffed1a2ab5eadb62738343043406049f5a35dc09d55cb066"
MANIFEST_FILE_COUNT = 111


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(directory: Path) -> dict[str, str]:
    return {p.relative_to(directory).as_posix(): digest(p)
            for p in sorted(directory.rglob("*")) if p.is_file()}


def normalized_rows(rows: list[dict]) -> list[dict]:
    return sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))


def sql_snapshot(path: Path) -> dict:
    # Same semantic comparison as frozen verify.py, without its historical checks.
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True) as conn:
        conn.execute("PRAGMA query_only=ON")
        if conn.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError(f"SQLite integrity check failed: {path}")
        tables = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        result = {}
        for table in tables:
            identifier = '"' + table.replace('"', '""') + '"'
            cursor = conn.execute(f"SELECT * FROM {identifier}")
            columns = [item[0] for item in cursor.description]
            result[table] = normalized_rows([dict(zip(columns, row)) for row in cursor])
        return result


def read_grid(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def csv_rows(rows: list[dict]) -> list[dict]:
    # csv.DictWriter's representation, with no file creation.
    return [{key: "" if value is None else str(value) for key, value in row.items()}
            for row in rows]


def display_path(path: Path) -> str:
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def verify(first: Path, second: Path) -> dict:
    checks = []

    def record(name: str, passed: bool, **details) -> None:
        checks.append({"check": name, "passed": bool(passed), **details})

    watched = sorted({V2.resolve(), first, second}, key=str)
    before = {str(p): inventory(p) for p in watched}
    manifest_path = V2 / "FINAL-MANIFEST.json"
    actual_manifest = digest(manifest_path)
    record("frozen_manifest_sha256", actual_manifest == MANIFEST_SHA256,
           actual=actual_manifest, expected=MANIFEST_SHA256)
    if actual_manifest != MANIFEST_SHA256:
        return {"passed": False, "checks": checks,
                "reason": "Refusing to import code from an unverified manifest."}

    files = load(manifest_path)["files"]
    mismatches = []
    for relative, expected in files.items():
        path = (V2 / relative).resolve()
        if not path.is_relative_to(V2.resolve()):
            raise ValueError(f"Manifest path escapes v2: {relative}")
        actual = digest(path) if path.is_file() else None
        if actual != expected:
            mismatches.append({"path": relative, "expected": expected, "actual": actual})
    record("manifest_entry_count", len(files) == MANIFEST_FILE_COUNT, count=len(files))
    record("all_frozen_file_hashes", not mismatches, checked=len(files), mismatches=mismatches)
    if mismatches or len(files) != MANIFEST_FILE_COUNT:
        return {"passed": False, "checks": checks,
                "reason": "Refusing to import code with failed frozen file checks."}

    for index, run in enumerate((first, second), 1):
        metadata = load(run / "RUN.json")
        record(f"run{index}:saved_runner_success",
               len(metadata["results"]) == 2 and
               {r["experiment"] for r in metadata["results"]} == {"x1", "x2"} and
               all(r["exit_code"] == 0 for r in metadata["results"]))
        for experiment in ("x1", "x2"):
            saved = load(run / experiment / "CHECKS.json")
            record(f"run{index}:{experiment}:saved_checks", saved["passed"] is True)

    semantic_files = {"x1": ["OBSERVATIONS.json", "EFFECTS.json"],
                      "x2": ["SCORE.json", "CASES.json", "EFFECTS.json", "grid.csv"]}
    sql_counts = []
    for experiment, names in semantic_files.items():
        for name in names:
            a, b = first / experiment / name, second / experiment / name
            same = load(a) == load(b) if a.suffix == ".json" else read_grid(a) == read_grid(b)
            record(f"{experiment}:{name}:run_pair_equal", same)
        a = sql_snapshot(first / experiment / "effects.sqlite")
        b = sql_snapshot(second / experiment / "effects.sqlite")
        record(f"{experiment}:sqlite_rows:run_pair_equal", a == b)
        sql_counts.append({"experiment": experiment,
                           "first_rows": {k: len(v) for k, v in a.items()},
                           "second_rows": {k: len(v) for k, v in b.items()}})

    scorer_path = V2 / "x2" / "score_x2.py"
    spec = importlib.util.spec_from_file_location("frozen_x2_independent_scorer", scorer_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load frozen independent scorer")
    scorer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scorer)
    for index, run in enumerate((first, second), 1):
        x2 = run / "x2"
        result = scorer.score_run(x2)
        record(f"run{index}:x2:independent_readback", result["checks"]["passed"] is True,
               issues=result["checks"]["issues"],
               routes=result["checks"]["fixture_route_count"],
               effects=result["checks"]["sql_effect_count"])
        record(f"run{index}:x2:rescored_summary_matches_saved",
               result["score"] == load(x2 / "SCORE.json"))
        record(f"run{index}:x2:rescored_effects_match_saved",
               normalized_rows(result["effects"]) == normalized_rows(load(x2 / "EFFECTS.json")))
        record(f"run{index}:x2:rescored_grid_matches_saved",
               csv_rows(result["grid"]) == read_grid(x2 / "grid.csv"))
        # Re-read existing diagnostic copies; do not create or mutate databases.
        for mutation in ("deleted_effect", "extra_effect", "changed_amount"):
            detected = scorer.score_run(x2, x2 / "oracle-mutations" / f"{mutation}.sqlite")
            record(f"run{index}:x2:saved_{mutation}_detected",
                   detected["checks"]["passed"] is False and bool(detected["checks"]["issues"]))

    after = {str(p): inventory(p) for p in watched}
    record("input_file_bytes_and_inventory_unchanged", before == after)
    return {"passed": all(c["passed"] for c in checks),
            "mode": "offline readback of existing evidence; no experiment execution",
            "python": platform.python_version(), "new_model_calls": 0,
            "runs": [display_path(first), display_path(second)],
            "frozen_files_checked": len(files), "checks": checks, "sql_counts": sql_counts,
            "comparison_scope": "Semantic JSON/CSV and actual SQLite rows; randomized raw framework IDs are preserved but not compared byte-for-byte.",
            "historical_receipts": "VERIFICATION.json and protected/previous-version hashes are preserved as historical receipts. This script does not apply them to the revised manuscript or require the omitted version-1 tree."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--first", type=Path, default=V2 / "runs" / "final-1")
    parser.add_argument("--second", type=Path, default=V2 / "runs" / "final-2")
    args = parser.parse_args()
    try:
        report = verify(args.first.resolve(), args.second.resolve())
    except Exception as exc:
        report = {"passed": False, "error_type": type(exc).__name__, "error": str(exc)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
