ASE manuscript upload source, 21 October 2026.
Entry point: main.tex (one self-contained editable manuscript).
Compile with pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX. main.bbl is also supplied.
Figures and tables are included in the text. Figure generation assets and recovery readbacks are retained for provenance.
The two Online Resource PDFs are separate supplementary uploads; their editable sources are in the complete source deposit on GitHub.
