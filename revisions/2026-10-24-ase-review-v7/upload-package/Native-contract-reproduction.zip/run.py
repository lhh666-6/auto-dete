"""X3: scripted native interrupts composed with the unchanged relational gate."""
from __future__ import annotations
import argparse
from copy import deepcopy
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import importlib.metadata as md
import json
from pathlib import Path
import platform
import sqlite3
import sys
from typing import TypedDict

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'backend'))
from stores import Store
from reference import certificate
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command

CASES = ('corrected', 'deny', 'identity-reuse', 'identity-fresh', 'wrong-value',
         'stale', 'rollback-cas', 'rollback-commit', 'duplicate-resume', 'consumed-replay')
INITIAL = {'address': 'old', 'batch': 'unchanged'}
PROPOSAL, APPROVED = 'machine proposal', 'reviewed correction'


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str) + '\n', encoding='utf-8')


class State(TypedDict, total=False):
    candidate: str
    grant: str
    decision: str
    mode: str
    outcome: str


class Trial:
    def __init__(self, case, output):
        self.case, self.output = case, output
        output.mkdir()
        self.store = Store('full', output / 'authority.sqlite', INITIAL)
        packet = self.store._packet('address', PROPOSAL, 1, 'reviewed-instance', 'constructed-evidence')
        self.store._add(packet)
        self.packets = {'original': packet}
        self.handles, self.grants, self.attempts, self.events = {}, [], [], []
        self.snapshot_index = 0
        builder = StateGraph(State)
        builder.add_node('review', self.review)
        builder.add_node('handoff', self.handoff)
        builder.add_node('execute', self.execute)
        builder.add_node('recover', self.recover)
        builder.add_edge(START, 'review')
        builder.add_conditional_edges('review', lambda s: 'handoff' if s['decision'] == 'approve' else END)
        builder.add_edge('handoff', 'execute')
        builder.add_conditional_edges('execute', lambda s: END if s['outcome'] == 'COMMITTED' else 'recover')
        builder.add_conditional_edges('recover', lambda s: {'reuse': 'execute', 'fresh': 'review', 'stop': END}[s['decision']])
        self.graph = builder.compile(checkpointer=InMemorySaver())
        self.config = {'configurable': {'thread_id': case}}

    def snapshot(self, label):
        self.snapshot_index += 1
        target = self.output / f'{self.snapshot_index:03d}-{label}.sqlite'
        with closing(sqlite3.connect(self.store.path.resolve().as_uri() + '?mode=ro', uri=True)) as src:
            with closing(sqlite3.connect(target)) as dest:
                src.backup(dest)
        return target.name

    def review(self, state):
        packet = self.packets[state['candidate']]
        answer = interrupt({'stage': 'review', 'candidate': packet, 'proposed': PROPOSAL})
        if answer.get('approve') is not True:
            return {'decision': 'deny'}
        ids = {'address': packet['id']}
        value = answer['authorized_value']
        bundle = self.store.engine.prepare(packet['expected_version'], {'address': value}, ids)
        key = f'grant-{len(self.grants)+1}'
        handle = {'version': packet['expected_version'], 'approval': bundle, 'ids': ids,
                  'packets': {'address': packet}, 'preview': {'complete_successor': {**INITIAL, 'address': value}}}
        self.handles[key] = handle
        self.grants.append({'key': key, 'candidate': state['candidate'], 'candidate_packet': packet,
                            'authorized_value': value, 'native_resume_value': answer,
                            'captured_bundle': repr(bundle)})
        return {'decision': 'approve', 'grant': key, 'mode': 'normal'}

    def handoff(self, state):
        # Instrumentation barrier: not an additional human approval request.
        answer = interrupt({'stage': 'handoff-barrier', 'grant': state['grant'], 'candidate': state['candidate']})
        return {'mode': answer['mode']}

    def execute(self, state):
        handle = deepcopy(self.handles[state['grant']])
        actual = deepcopy(handle['preview']['complete_successor'])
        failpoint = None
        if state['mode'] == 'identity':
            replacement = deepcopy(self.packets['original'])
            replacement['candidate_id'] += ':replacement'
            replacement['id'] = certificate(replacement).certificate_id
            self.store._add(replacement)
            self.packets['replacement'] = replacement
            handle['ids'] = {'address': replacement['id']}
            handle['packets'] = {'address': replacement}
        elif state['mode'] == 'wrong-value':
            actual['address'] = 'unapproved value'
        elif state['mode'] == 'rollback-cas':
            failpoint = 'after_cas'
        elif state['mode'] == 'rollback-commit':
            failpoint = 'before_commit'
        before = self.snapshot('attempt-before')
        outcome = self.store.commit(handle, actual, failpoint=failpoint)
        after = self.snapshot('attempt-after')
        self.attempts.append({'mode': state['mode'], 'grant': state['grant'], 'before': before, 'after': after,
            'supplied_ids': handle['ids'], 'reviewed_ids': self.handles[state['grant']]['ids'],
            'submitted_values': actual, 'gate_result': outcome})
        return {'outcome': outcome['status']}

    def recover(self, state):
        answer = interrupt({'stage': 'recovery', 'gate_result': self.attempts[-1]['gate_result'],
                            'reviewed_candidate': self.packets[state['candidate']], 'grant': state['grant']})
        action = answer['action']
        if action == 'fresh':
            return {'decision': action, 'candidate': 'replacement', 'mode': 'normal'}
        if action not in ('reuse', 'stop'):
            raise ValueError('Unsupported scripted continuation')
        return {'decision': action, 'mode': 'normal'}

    def invoke(self, label, value):
        before = self.snapshot('invoke-before')
        result = self.graph.invoke(value, self.config)
        snapshot = self.graph.get_state(self.config)
        pending = [{'id': i.id, 'payload': i.value} for task in snapshot.tasks for i in task.interrupts]
        after = self.snapshot('invoke-after')
        self.events.append({'label': label, 'input': repr(value), 'result': repr(result),
                            'state': snapshot.values, 'pending': pending, 'before': before, 'after': after,
                            'grants_created': len(self.grants), 'attempt_count': len(self.attempts)})
        return pending

    def resume(self, label, pending, value):
        assert len(pending) == 1
        return self.invoke(label, Command(resume={pending[0]['id']: value}))

    def run(self):
        p = self.invoke('initial-review', {'candidate': 'original'})
        first_id = p[0]['id']
        if self.case == 'deny':
            self.resume('deny', p, {'approve': False})
        else:
            p = self.resume('approve', p, {'approve': True, 'authorized_value': APPROVED})
            if self.case == 'stale':
                before = self.snapshot('external-before')
                self.store.external_change({**INITIAL, 'batch': 'independent'})
                self.events.append({'label': 'independent-advance', 'before': before, 'after': self.snapshot('external-after')})
            mode = 'identity' if self.case.startswith('identity') else (self.case if self.case in ('wrong-value', 'rollback-cas', 'rollback-commit') else 'normal')
            p = self.resume('execute-first', p, {'mode': mode})
            if p:
                action = 'fresh' if self.case == 'identity-fresh' else ('stop' if self.case == 'stale' else 'reuse')
                p = self.resume('choose-' + action, p, {'action': action})
                if action == 'fresh':
                    new_id = p[0]['id']
                    p = self.invoke('old-review-id', Command(resume={first_id: {'approve': True, 'authorized_value': APPROVED}}))
                    assert len(p) == 1 and p[0]['id'] == new_id
                    p = self.resume('approve-replacement', p, {'approve': True, 'authorized_value': APPROVED})
                    self.resume('execute-replacement', p, {'mode': 'normal'})
            if self.case == 'duplicate-resume':
                self.invoke('repeat-completed-resume', Command(resume={first_id: {'approve': True, 'authorized_value': APPROVED}}))
            if self.case == 'consumed-replay':
                h = self.handles['grant-1']
                before = self.snapshot('replay-before')
                result = self.store.commit(h, h['preview']['complete_successor'])
                self.events.append({'label': 'direct-consumed-replay', 'before': before, 'after': self.snapshot('replay-after'), 'gate_result': result})
        save(self.output / 'records.json', {'case': self.case, 'initial': INITIAL, 'proposal': PROPOSAL,
             'approved': APPROVED, 'grants': self.grants, 'attempts': self.attempts, 'events': self.events})
        self.store.close()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--development', action='store_true')
    a = p.parse_args()
    assert md.version('langgraph') == '1.0.8'
    if not a.development:
        freeze = json.loads((HERE / 'FREEZE.json').read_text())
        for name, sha in freeze['files'].items():
            assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == sha, name
    a.output.mkdir(parents=True, exist_ok=False)
    save(a.output / 'RUN.json', {'started_utc': datetime.now(timezone.utc).isoformat(), 'development': a.development,
        'protocol_sha256': hashlib.sha256((HERE / 'PROTOCOL.md').read_bytes()).hexdigest(),
        'python': platform.python_version(), 'versions': {p: md.version(p) for p in ('langgraph','langgraph-checkpoint','langchain-core','SQLAlchemy')},
        'cases': CASES, 'scope': 'Deterministic in-process composition; scripted decisions; no model calls.'})
    for case in CASES:
        Trial(case, a.output / case).run()
    print(json.dumps({'output': str(a.output), 'conditions': len(CASES)}))


if __name__ == '__main__':
    main()
