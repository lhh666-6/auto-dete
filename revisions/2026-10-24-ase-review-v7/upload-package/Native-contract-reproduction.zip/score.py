"""Independent, read-only X3 scorer. Imports neither the gate nor LangGraph."""
import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3

EXPECTED = {'corrected': (1, 1), 'deny': (0, 0), 'identity-reuse': (2, 1),
            'identity-fresh': (2, 2), 'wrong-value': (2, 1), 'stale': (1, 1),
            'rollback-cas': (2, 1), 'rollback-commit': (2, 1), 'duplicate-resume': (1, 1),
            'consumed-replay': (1, 1)}  # gate attempts, scripted review grants
TABLES = ('record_versions', 'fact_transitions', 'human_decisions', 'authorization_bindings')


def read_db(path):
    with closing(sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True)) as con:
        con.row_factory = sqlite3.Row
        tables = {t: sorted([dict(r) for r in con.execute('SELECT * FROM ' + t)],
                           key=lambda x: json.dumps(x, sort_keys=True)) for t in TABLES}
        head = dict(con.execute('SELECT * FROM record_versions ORDER BY version DESC LIMIT 1').fetchone())
        head['values'] = json.loads(head['values'])
        head['fact_sources'] = json.loads(head['fact_sources'])
        links = [dict(r) for r in con.execute('''SELECT t.transition_id,t.field_key,t.created_version,
          t.value_payload,t.certificate_id,b.certificate_id reviewed_certificate,b.authorized_value_payload,
          c.candidate_id,c.value_payload proposal,d.candidate_id decided_candidate
          FROM fact_transitions t JOIN authorization_bindings b ON t.decision_id=b.decision_id
          JOIN candidate_certificates c ON t.certificate_id=c.certificate_id
          JOIN human_decisions d ON t.decision_id=d.decision_id''')]
    return {'tables': tables, 'head': head, 'links': links}


def validate_links(db):
    assert len(db['links']) == len(db['tables']['fact_transitions'])
    assert len(db['tables']['authorization_bindings']) == len(db['links'])
    assert len(db['tables']['human_decisions']) == len(db['links'])
    for link in db['links']:
        assert link['certificate_id'] == link['reviewed_certificate']
        assert link['candidate_id'] == link['decided_candidate']
        assert json.loads(link['value_payload']) == json.loads(link['authorized_value_payload'])
    by_id = {x['transition_id']: x for x in db['links']}
    for field, source in db['head']['fact_sources'].items():
        assert source in by_id
        assert by_id[source]['field_key'] == field
        assert json.loads(by_id[source]['value_payload']) == db['head']['values'][field]


def check_final(db, initial, case, records):
    validate_links(db)
    expected = {'address': 'old', 'batch': 'unchanged'} if case == 'deny' else (
        {'address': 'old', 'batch': 'independent'} if case == 'stale' else
        {'address': 'reviewed correction', 'batch': 'unchanged'})
    assert db['head']['values'] == expected
    delta = int(case != 'deny')
    assert len(db['tables']['record_versions']) == len(initial['tables']['record_versions']) + delta
    assert db['head']['version'] == initial['head']['version'] + delta
    assert len(db['links']) == len(initial['links']) + delta
    if case not in ('deny', 'stale'):
        source = db['head']['fact_sources']['address']
        link = next(x for x in db['links'] if x['transition_id'] == source)
        assert json.loads(link['proposal']) == 'machine proposal'
        assert link['candidate_id'] == ('reviewed-instance:replacement' if case == 'identity-fresh' else 'reviewed-instance')
        assert db['head']['fact_sources']['batch'] == initial['head']['fact_sources']['batch']
        assert link['reviewed_certificate'] == records['grants'][-1]['candidate_packet']['id']
    if case == 'stale':
        assert db['head']['fact_sources']['address'] == initial['head']['fact_sources']['address']


def score_case(directory):
    raw = json.loads((directory / 'records.json').read_text(encoding='utf-8'))
    case = raw['case']
    assert len(raw['attempts']) == EXPECTED[case][0]
    assert len(raw['grants']) == EXPECTED[case][1]
    first = raw['events'][0]
    assert first['label'] == 'initial-review' and len(first['pending']) == 1 and first['grants_created'] == 0
    assert first['pending'][0]['payload']['stage'] == 'review'
    initial = read_db(directory / first['before'])
    checked_files = {}
    def read(name):
        p = directory / name
        checked_files[name] = hashlib.sha256(p.read_bytes()).hexdigest()
        result = read_db(p)
        validate_links(result)
        return result
    commits, unchanged = 0, 0
    for index, attempt in enumerate(raw['attempts']):
        before, after = read(attempt['before']), read(attempt['after'])
        expect_write = attempt['mode'] == 'normal' and case != 'stale'
        if expect_write:
            assert after['head']['version'] == before['head']['version'] + 1
            assert after['head']['values']['address'] == 'reviewed correction'
            assert len(after['links']) == len(before['links']) + 1
            assert after['head']['fact_sources']['batch'] == before['head']['fact_sources']['batch']
            commits += 1
        else:
            assert after['tables'] == before['tables'], (case, index)
            unchanged += 1
        if attempt['mode'] == 'identity':
            assert attempt['supplied_ids'] != attempt['reviewed_ids']
    for event in raw['events']:
        before, after = read(event['before']), read(event['after'])
        if event['label'] in ('initial-review', 'approve', 'deny', 'old-review-id',
                              'approve-replacement', 'repeat-completed-resume', 'direct-consumed-replay'):
            assert before['tables'] == after['tables'], event['label']
        if event['label'] == 'old-review-id':
            assert len(event['pending']) == 1 and event['pending'][0]['payload']['stage'] == 'review'
            assert event['grants_created'] == 1
    if case == 'identity-fresh':
        current = next(e for e in raw['events'] if e['label'] == 'choose-fresh')['pending'][0]['id']
        old = first['pending'][0]['id']
        assert current != old
        assert next(e for e in raw['events'] if e['label'] == 'old-review-id')['pending'][0]['id'] == current
    final = read('authority.sqlite')
    check_final(final, initial, case, raw)
    return {'case': case, 'pass': True, 'gate_attempts': len(raw['attempts']),
            'correction_commits': commits, 'rejected_or_rolled_back_attempts_without_partial_rows': unchanged,
            'review_grants': len(raw['grants']), 'final_version': final['head']['version'], 'checked_files': checked_files}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('run', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    rows = []
    for case in EXPECTED:
        try:
            rows.append(score_case(a.run / case))
        except Exception as exc:
            rows.append({'case': case, 'pass': False, 'error': type(exc).__name__ + ': ' + str(exc)})
    result = {'scope': 'SQL readback and native interrupt records; no imported gate or framework.',
              'conditions': len(rows), 'passed': sum(r['pass'] for r in rows), 'results': rows}
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'conditions': len(rows), 'passed': result['passed'], 'failures': [r for r in rows if not r['pass']]}))
    if result['passed'] != len(rows):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
