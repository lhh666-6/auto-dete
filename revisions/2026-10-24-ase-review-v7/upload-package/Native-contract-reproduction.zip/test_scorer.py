"""Negative controls for the readback oracle; mutations occur only in copies."""
import argparse
from contextlib import closing
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
from score import read_db, check_final


def main():
    p = argparse.ArgumentParser()
    p.add_argument('run', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    case = a.run / 'corrected'
    raw = json.loads((case / 'records.json').read_text())
    initial = read_db(case / raw['events'][0]['before'])
    mutations = {
        'wrong-final-value': '''UPDATE record_versions SET "values"='{"address":"wrong","batch":"unchanged"}' WHERE version=2''',
        'missing-transition': 'DELETE FROM fact_transitions WHERE created_version=2',
        'wrong-authorized-value': '''UPDATE authorization_bindings SET authorized_value_payload='"wrong"'
          WHERE decision_id IN (SELECT decision_id FROM fact_transitions WHERE created_version=2)''',
        'extra-version': None,
    }
    # Inspect named columns for a portable addition mutation, not schema position.
    results = []
    with tempfile.TemporaryDirectory(prefix='x3-scorer-') as tmp:
        for name, sql in mutations.items():
            target = Path(tmp) / (name + '.sqlite')
            shutil.copy2(case / 'authority.sqlite', target)
            with closing(sqlite3.connect(target)) as con:
                if sql:
                    con.execute(sql)
                else:
                    con.row_factory = sqlite3.Row
                    row = dict(con.execute('SELECT * FROM record_versions WHERE version=2').fetchone())
                    row['record_id'], row['version'] = 'mutation-extra', 3
                    cols = ','.join('"' + x + '"' for x in row)
                    con.execute('INSERT INTO record_versions ('+cols+') VALUES ('+','.join('?' for _ in row)+')', list(row.values()))
                con.commit()
            detected = False
            try:
                check_final(read_db(target), initial, 'corrected', raw)
            except AssertionError:
                detected = True
            assert detected, name
            results.append({'mutation': name, 'detected': detected})
    a.output.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({'mutations': len(results), 'detected': len(results)}))


if __name__ == '__main__':
    main()
