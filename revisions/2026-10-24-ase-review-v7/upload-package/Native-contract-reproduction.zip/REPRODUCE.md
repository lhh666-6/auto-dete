# X3 native interrupt and relational contract composition

Python 3.11; install requirements.txt. All review and recovery decisions are
scripted. No model calls or credentials are needed. LangGraph interrupt/resume
and the existing pinned relational backend are unmodified; run.py supplies the
graph, payload interpretation, application grant handles and interventions.
The handoff interrupt is an instrumentation barrier, not a human approval.
Grants and checkpointer state are in process until the database transaction;
this experiment does not test restart-safe review storage.

From this extracted directory:

```
python score.py runs/final-1 --output readback-1.json
python score.py runs/final-2 --output readback-2.json
python test_scorer.py runs/final-1 --output scorer-negative-controls.json
python run.py --output fresh-run
python score.py fresh-run --output fresh-score.json
```

run.py refuses an existing output directory and checks FREEZE.json. Scoring
reads SQLite through independent read-only connections and imports neither the
gate nor the framework. Each saved run has ten conditions. Expected: ten passes,
eight authorized address commits, one independent batch update, six rejected or
rolled-back first attempts with no partial transactional rows. Approval denial,
old-ID resume at the new review, duplicate native resume and consumed application
grant replay produce no extra business write. Six rejected/rollback attempts
include the stale-predecessor case, which ends without an address correction.
The four negative controls change a final value, delete a transition, alter an
authorized value or add an extra version in database copies; all must be detected.

Raw records, every invocation/attempt SQLite snapshot, final databases, runtime
versions and source hashes are retained. Candidate IDs/timestamps and native
interrupt IDs can vary across runs; compare the declared semantic observations,
not byte identity. The two final executions use one frozen program and fresh
SQLite databases on the same machine. No confidence interval or statistical
robustness claim is appropriate. Development records are retained locally,
separately from the two final runs; a Windows cleanup failure during scorer
negative-control development was fixed by explicitly closing SQLite connections.

The backend contains the same stores.py, source manifest and 19 contract files
used in the existing store comparison. Their contents were not edited.
