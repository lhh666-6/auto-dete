# X3: native interrupt to durable correction contract

Purpose: test one composition boundary left separate by X1 and the store study.
Use released LangGraph 1.0.8 interrupt/resume with InMemorySaver and the exact,
byte-pinned original relational contract implementation. All decisions are
scripted. No LLM, human participant, provider request or public benchmark is used.

An author-written graph first pauses over an already registered immutable
candidate. Only a matching affirmative resume creates its correction grant.
A second handoff pause allows a controlled intervention between review and
commit. The graph then invokes the existing relational gate. Rejection leads
to a recovery pause; reuse submits the original candidate/grant, while fresh
authorization visits a new native review interrupt before creating a new grant.
Candidate/grant handles remain application objects in this in-process probe.
This is not a durable checkpoint/restart or distributed transaction experiment.

Ten predeclared conditions, each in an isolated SQLite database:

1. Corrected approval: proposal differs from reviewed correction; one write.
2. Denial: no correction grant or successor write.
3. Identity substitution, then reviewed-candidate reuse: first attempt rejects,
   recovery writes once with the original candidate and authorization.
4. Identity substitution, then fresh review: first attempt rejects; old native
   review identifier cannot resume the new review; new identifier authorizes
   the replacement and one write follows.
5. Wrong executed value, then corrected reuse: first attempt rejects, original
   approved value subsequently writes once.
6. Independent predecessor advance after approval: stale attempt rejects;
   the independent update is preserved, without automatic recovery.
7. Failpoint after compare-and-swap, then retry: rollback preserves the
   pre-attempt business state and grant eligibility; retry writes once.
8. Failpoint before transaction commit, then retry: same requirements.
9. Duplicate native resume after a completed run: no additional business write.
10. Direct replay of the consumed application grant: no additional business
    write. This is an explicit adapter replay control, not concurrent replay.

At every graph invocation and gate attempt, save direct SQLite snapshots,
native pending interrupt identifiers/payloads and the scripted input. The
independent scorer imports no gate or graph module. It reads saved SQLite
copies using fresh read-only connections; checks version counts, corrected
values, unchanged-field sources, candidate/authorization/transition linkage,
absence of partial transactional rows after rejects/rollback, and the final
database. Gate-reported COMMITTED/REJECTED is not its business-effect oracle.

Freeze this protocol, implementation and scorer before final runs. Keep any
development attempts separately. Run two complete executions into fresh output
directories with the same frozen source, retaining both even if a test fails.
Report all ten conditions and exact scope. Repetition checks deterministic
repeatability, not statistical robustness or autonomous recovery rates.
