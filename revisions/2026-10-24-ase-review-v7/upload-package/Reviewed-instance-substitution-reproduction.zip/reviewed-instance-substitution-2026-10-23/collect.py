from pathlib import Path
import argparse
import concurrent.futures
import json
import os
import shutil
import subprocess
import sys
import time
import psutil
from study_common import HERE, read, write, sha, now, verify_freeze

ROOT = HERE.parent / 'innovation-round2-2026-10-23'
PYTHONS = {'pydantic_ai': ROOT / 'pydantic-control/.venv/Scripts/python.exe'}
PHASES = {'live': ['live'], 'same_process': ['same_process'],
          'fresh_process': ['prepare', 'resume']}

def clean_environment(python, scratch):
    allowed = ['SystemRoot', 'WINDIR', 'COMSPEC', 'USERPROFILE', 'APPDATA',
               'LOCALAPPDATA', 'PROGRAMDATA', 'PATHEXT', 'NUMBER_OF_PROCESSORS']
    env = {k: os.environ[k] for k in allowed if k in os.environ}
    env.update(PATH=str(Path(python).parent) + os.pathsep + str(Path(os.environ['SystemRoot']) / 'System32'),
               TEMP=str(scratch), TMP=str(scratch), PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1',
               OTEL_SDK_DISABLED='true', LOGFIRE_SEND_TO_LOGFIRE='false',
               AGNO_TELEMETRY='false', DO_NOT_TRACK='1', LANGCHAIN_TRACING_V2='false')
    return env

def tree_stats(pid):
    try:
        parent = psutil.Process(pid)
        processes = parent.children(recursive=True) + [parent]
    except psutil.NoSuchProcess:
        return 0, []
    rss, ids = 0, []
    for process in processes:
        try:
            rss += process.memory_info().rss
            ids.append(process.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return rss, ids

def terminate_tree(process):
    if process.poll() is not None:
        return
    # Only the PID launched by this runner is eligible. No name-based/global kill.
    subprocess.run([str(Path(os.environ['SystemRoot']) / 'System32/taskkill.exe'),
                    '/PID', str(process.pid), '/T', '/F'], stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL, timeout=10)
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)

def directory_bytes(folder):
    total = 0
    for path in Path(folder).rglob('*'):
        try:
            if path.is_file():
                total += path.stat().st_size
        except FileNotFoundError:
            pass
    return total

def supervise(command, folder, stem, stop_path, timeout=60, memory_mib=768,
              artifact_bytes=32*1024*1024, log_bytes=4*1024*1024,
              minimum_free=512*1024*1024, env=None):
    folder, stop_path = Path(folder), Path(stop_path)
    folder.mkdir(parents=True, exist_ok=True)
    stdout, stderr = folder / (stem + '.stdout.txt'), folder / (stem + '.stderr.txt')
    started, peak, reason, seen = time.monotonic(), 0, None, set()
    if stop_path.exists():
        return {'status': 'stopped_before_launch', 'duration_seconds': 0}
    with stdout.open('xb') as outlog, stderr.open('xb') as errlog:
        process = subprocess.Popen(command, cwd=folder, env=env, stdout=outlog,
                                   stderr=errlog, creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            while process.poll() is None:
                rss, ids = tree_stats(process.pid)
                seen.update(ids)
                peak = max(peak, rss)
                if stop_path.exists():
                    reason = 'global_stop'
                elif time.monotonic() - started > timeout:
                    reason = 'timeout'
                elif rss > memory_mib * 1024 * 1024:
                    reason = 'memory_limit'
                elif stdout.stat().st_size > log_bytes or stderr.stat().st_size > log_bytes:
                    reason = 'log_limit'
                elif directory_bytes(folder) > artifact_bytes:
                    reason = 'artifact_limit'
                elif shutil.disk_usage(folder).free < minimum_free:
                    reason = 'disk_free_limit'
                if reason:
                    terminate_tree(process)
                    break
                time.sleep(.10)
        except BaseException:
            terminate_tree(process)
            raise
    # A fast exit must not bypass persistent resource checks between polling ticks.
    if reason is None:
        if stop_path.exists():
            reason = 'global_stop'
        elif stdout.stat().st_size > log_bytes or stderr.stat().st_size > log_bytes:
            reason = 'log_limit'
        elif directory_bytes(folder) > artifact_bytes:
            reason = 'artifact_limit'
        elif shutil.disk_usage(folder).free < minimum_free:
            reason = 'disk_free_limit'
    return {'status': reason or ('exited' if process.returncode == 0 else 'worker_nonzero'),
            'pid': process.pid, 'observed_tree_pids': sorted(seen),
            'returncode': process.returncode, 'peak_tree_rss_bytes': peak,
            'duration_seconds': time.monotonic() - started}

def artifact_hashes(out):
    return {p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*'))
            if p.is_file() and p.name != 'complete.json'}

def verify_complete(out, case, expected_freeze=None):
    record = read(out / 'complete.json')
    expected_freeze = expected_freeze or sha(HERE / 'freeze.json')
    if record.get('freeze_sha256') != expected_freeze:
        raise RuntimeError('RESUME_FREEZE_MISMATCH:' + case['id'])
    if record['case_id'] != case['id'] or read(out / 'case.json') != case:
        raise RuntimeError('RESUME_INPUT_MISMATCH:' + case['id'])
    if artifact_hashes(out) != record['artifacts']:
        raise RuntimeError('RESUME_ARTIFACT_DRIFT:' + case['id'])
    return record

def run_case(case, output_root):
    out, stop = output_root / case['id'], output_root / 'STOP'
    if (out / 'complete.json').exists():
        verify_complete(out, case)
        return {'case_id': case['id'], 'status': 'verified_skip'}
    if out.exists():
        # Never replay a cell whose effects may already have occurred.
        return {'case_id': case['id'], 'status': 'incomplete_no_retry'}
    if stop.exists():
        return {'case_id': case['id'], 'status': 'not_dispatched_stop'}
    out.mkdir()
    write(out / 'case.json', case)
    scratch = out / 'scratch'
    scratch.mkdir()
    phases = PHASES[case['lifecycle']]
    processes, status = [], 'collected'
    for phase in phases:
        command = [str(PYTHONS[case['framework']]), '-P', '-B', str(HERE / 'worker.py'),
                   '--case-file', str(out / 'case.json'), '--out', str(out),
                   '--phase', phase, '--frozen']
        record = supervise(command, out, phase, stop,
                           env=clean_environment(command[0], scratch))
        processes.append({'phase': phase, **record})
        if (out / (phase + '.json')).exists():
            result = read(out / (phase + '.json'))
            if result.get('network_attempts', 0):
                write(stop, {'reason': 'network_attempt', 'case_id': case['id']})
                status = 'network_attempt'
                break
        else:
            status = 'missing_phase_record'
        if record['status'] not in ['exited', 'worker_nonzero']:
            status = record['status']
            write(stop, {'reason': status, 'case_id': case['id']})
            break
        if record['returncode'] != 0:
            status = 'worker_error'
            break
    write(out / 'processes.json', processes)
    terminal = {'case_id': case['id'], 'status': status, 'ended_utc': now(),
                'freeze_sha256': sha(HERE / 'freeze.json'), 'artifacts': artifact_hashes(out)}
    write(out / 'complete.json', terminal)
    return {k: terminal[k] for k in ['case_id', 'status']}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--concurrency', type=int, choices=[1, 2, 3, 4], default=2)
    p.add_argument('--limit', type=int, default=0)
    p.add_argument('--output', default='outputs-v1')
    a = p.parse_args()
    freeze_hash = verify_freeze()
    root = (HERE / a.output).resolve()
    assert root.parent == HERE, 'Output must be a direct study child'
    root.mkdir(exist_ok=True)
    lock = root / 'collector.lock'
    with lock.open('x', encoding='utf-8') as f:
        json.dump({'pid': os.getpid(), 'utc': now()}, f)
    started, records = now(), []
    try:
        cases = read(HERE / 'cases.json')
        todo = []
        for case in cases:
            folder = root / case['id']
            if (folder / 'complete.json').exists():
                verify_complete(folder, case)
            elif folder.exists():
                records.append({'case_id': case['id'], 'status': 'incomplete_no_retry'})
            else:
                todo.append(case)
        if a.limit:
            todo = todo[:a.limit]
        # At most concurrency tasks are pending, so STOP prevents further dispatch.
        pending, iterator = {}, iter(todo)
        with concurrent.futures.ThreadPoolExecutor(max_workers=a.concurrency) as pool:
            def submit_one():
                if (root / 'STOP').exists():
                    return False
                case = next(iterator, None)
                if case is None:
                    return False
                pending[pool.submit(run_case, case, root)] = case['id']
                return True
            for _ in range(a.concurrency):
                submit_one()
            while pending:
                done, _ = concurrent.futures.wait(pending, return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    case_id = pending.pop(future)
                    try:
                        record = future.result()
                    except Exception as e:
                        record = {'case_id': case_id, 'status': 'collector_error', 'error': repr(e)}
                        write(root / 'STOP', record)
                    records.append(record)
                    if len(records) % 12 == 0 or record['status'] != 'collected':
                        print(json.dumps({'finished_this_invocation': len(records), **record}), flush=True)
                    submit_one()
        verify_freeze()
    finally:
        write(root / ('batch-' + str(time.time_ns()) + '.json'),
              {'started_utc': started, 'ended_utc': now(), 'freeze_sha256': freeze_hash,
               'concurrency': a.concurrency, 'records': records, 'paid_calls': 0})
        lock.unlink()
    print(json.dumps({'finished_this_invocation': len(records), 'stopped': (root / 'STOP').exists()}))

if __name__ == '__main__':
    main()
