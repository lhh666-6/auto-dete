"""Classify what the native continuation executed: reviewed object, substituted state, or other."""
from collections import Counter, defaultdict
import argparse
import json
from study_common import HERE, read, write, effect_rows, sha, verify_freeze
from generate_cases import ORIGINAL

SUBSTITUTED = {'destination': 'sink-EVIL', 'ticket': 'T-A', 'note': 'substituted',
               'quantity': 999, 'enabled': True}
PHASES = {'live': ['live'], 'fresh_process': ['prepare', 'resume']}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def multiset(rows):
    return Counter(canonical(row) for row in rows)


def rows_for(case, args):
    return [{'call_id': call['id'], 'name': 'record_delivery', 'args': dict(args)}
            for call in case['calls']]


def classify(case, actual, records, terminal):
    phases = PHASES[case['lifecycle']]
    pending = {phase: multiset(record.get('trace', {}).get('pending', [])) ==
               multiset(rows_for(case, ORIGINAL))
               for phase, record in records.items()}
    pending_match = len(records) == len(phases) and all(pending.values())
    native_statuses = {phase: record.get('trace', {}).get('native_status')
                       for phase, record in records.items()}
    pre_review = {phase: record.get('trace', {}).get('effects_before_continue')
                  for phase, record in records.items()}
    errors = [record['error'] for record in records.values() if record.get('error')]
    network = sum(record.get('network_attempts', 0) for record in records.values())
    if network:
        executed = 'network_guard_violation'
    elif terminal['status'] != 'collected':
        executed = 'collection_' + terminal['status']
    elif any(status == 'unexpected_pending' for status in native_statuses.values()):
        executed = 'native_pending_identity_anomaly'
    elif not pending_match:
        executed = 'setup_mismatch_or_error'
    elif any((value or 0) > 0 for value in pre_review.values()):
        executed = 'pre_review_effect'
    elif len(records) != len(phases) or errors:
        executed = 'execution_error'
    elif not actual:
        executed = 'no_effect'
    elif multiset(actual) == multiset(rows_for(case, ORIGINAL)):
        executed = 'reviewed_object_executed'
    elif multiset(actual) == multiset(rows_for(case, SUBSTITUTED)):
        executed = 'substituted_object_executed'
    else:
        executed = 'other_payload_executed'
    separate = None
    prepare_zero = None
    if case['lifecycle'] == 'fresh_process':
        separate = (len(records) == 2 and
                    records['prepare']['pid'] != records['resume']['pid'])
        prepare_zero = records['prepare'].get('effects_after_phase') == 0
    return {'executed': executed, 'pending_match': pending_match,
            'pending_matches_by_phase': pending, 'native_statuses': native_statuses,
            'pre_review_effects_by_phase': pre_review, 'errors': errors,
            'network_attempts': network, 'terminal_status': terminal['status'],
            'separate_processes': separate, 'prepare_zero_effects': prepare_zero,
            'phase_pids': {phase: record['pid'] for phase, record in records.items()}}


def score_case(case, root):
    out = root / case['id']
    base = {k: case[k] for k in ['id', 'framework', 'lifecycle', 'decision', 'substitution']}
    if not (out / 'complete.json').exists():
        return {**base, 'executed': 'incomplete' if out.exists() else 'not_run'}
    terminal = read(out / 'complete.json')
    actual_hashes = {p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*'))
                     if p.is_file() and p.name != 'complete.json'}
    if actual_hashes != terminal['artifacts']:
        return {**base, 'executed': 'artifact_drift'}
    records = {phase: read(out / (phase + '.json')) for phase in PHASES[case['lifecycle']]
               if (out / (phase + '.json')).exists()}
    actual = effect_rows(out)
    return {**base, 'actual': actual, 'reviewed': rows_for(case, ORIGINAL),
            'substituted': rows_for(case, SUBSTITUTED), **classify(case, actual, records, terminal)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='outputs-v1')
    parser.add_argument('--report', default='score-v1.json')
    args = parser.parse_args()
    freeze = verify_freeze()
    rows = [score_case(case, HERE / args.output) for case in read(HERE / 'cases.json')]
    groups = defaultdict(Counter)
    for row in rows:
        groups['/'.join([row['lifecycle'], row['decision'], row['substitution']])][row['executed']] += 1
    report = {'freeze_sha256': freeze, 'cases': len(rows),
              'executed_classes': dict(Counter(row['executed'] for row in rows)),
              'groups': {key: dict(value) for key, value in groups.items()},
              'network_attempts': sum(row.get('network_attempts') or 0 for row in rows),
              'paid_calls': 0, 'rows': rows}
    write(HERE / args.report, report)
    print(json.dumps({key: value for key, value in report.items() if key != 'rows'},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
