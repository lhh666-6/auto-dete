Same-identifier reviewed-instance substitution (16 cells)
========================================================

Question: after the human review step and before the native continuation, the state
the continuation executes from is replaced for the SAME native tool_call_id. Does a
native approval execute the reviewed object or the substituted state, and which stored
object carries the executable arguments?

Pydantic AI 2.60.0. Matrix: 2 lifecycles (in-process continuation, clean restart) x
2 human decisions (approve without re-supplying the object, override carrying the
reviewed object) x 4 substitution targets (none, deferred request object, persisted
message history, both). One call per cell, deterministic scripted model, no model or
paid calls.

Result: 12 cells executed the reviewed object, 4 executed the substituted object.
Approval without the reviewed object executed substituted history arguments (4/4 of
the history-changing cells, both lifecycles); substituting only the deferred request
object was inert (2/2 reviewed); re-supplying the reviewed object executed the
reviewed object in 8/8 cells.

Frozen protocol, code, cases, seals (including installed SDK source hashes), scoring
records, report, collector batch logs and this README are included. Raw per-cell
databases remain in the local study directory; score-v1.json retains every executed
payload.

Rerun:  python -B generate_cases.py      (only in a copy without freeze.json)
        python -B runtime_checks.py
        python -B freeze_study.py
        python -B collect.py --concurrency 2 --limit 4
        python -B collect.py --concurrency 4
        python -B score.py --output outputs-v1 --report score-v1.json

The threat injection is harness-controlled and applied only between review and
continuation; it is not evidence of a production compromise. No prevalence,
significance or novelty claim.
