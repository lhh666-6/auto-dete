# Same-identifier reviewed-instance substitution: 16-cell frozen check

Generated 2026-10-23 from the frozen study (freeze
`b5871cf623af9cb81fa5c17ac034c913345c8b5d6ed0836e29ed14da498d7a66`). Pydantic AI 2.60.0,
deterministic scripted model, no model or paid calls.

## Question

The 504-cell and 54-cell studies measured whether reviewed arguments reach the intended
pending call. This check measures the complementary case: after the review step and
before the native continuation, the state the continuation executes from is replaced
for the **same** native `tool_call_id`. The human decision either only approves
(`ToolApproved()`) or re-supplies the reviewed object
(`ToolApproved(override_args=...)`).

## Matrix and result

16 cells = 2 lifecycles x 2 decisions x 4 substitution targets (one call per cell).

| Decision | Substitution target | Live | Fresh process |
|---|---|---|---|
| approve | none | reviewed object | reviewed object |
| approve | requests only | reviewed object | reviewed object |
| approve | history only | **substituted object** | **substituted object** |
| approve | history + requests | **substituted object** | **substituted object** |
| override | none | reviewed object | reviewed object |
| override | requests only | reviewed object | reviewed object |
| override | history only | reviewed object | reviewed object |
| override | history + requests | reviewed object | reviewed object |

Totals: 12 cells executed the reviewed object, 4 executed the substituted object. All
16 cells had matching native pending identity, zero effects before the native
continuation, and no setup, execution, collection or network anomaly.

## Findings

1. A native approval that does not re-supply the reviewed object executes whatever the
   persisted message history describes: substituting one field of that history after
   review changed the executed payload in 4/4 such cells, in both lifecycles.
2. Substituting only the deferred request object is inert (2/2 executed the reviewed
   object): the executable arguments come from the persisted message history, not from
   the approval-request object.
3. Re-supplying the reviewed object through the native override argument executes the
   reviewed object in 8/8 cells, including every substituted cell. The observed
   difference comes from the application carrying the reviewed object, not from the SDK
   re-validating the pending call.

## Framing against the documented trust boundary

The Pydantic AI documentation treats client-supplied message history as input outside
the boundary the framework enforces, and does not present native approval as a
substitute for server-side authorization (message-history documentation, accessed
2026-10-24). These results are therefore stated as an empirical observation about an
application-maintained responsibility boundary, not as a framework defect. Post-approval
substitution is itself reported in prior work on approval hijacking; the contribution
here is the controlled reproduction through documented native interfaces and the
localization of the state that carries the executable arguments.

## Claim boundary

One framework, one pinned version, one call per cell, a harness-controlled threat
injection applied between review and continuation (not a production compromise), and
one realization per cell. No prevalence, significance, cross-framework or novelty
claim. The study does not test concurrent access, authenticated reviewers,
cross-principal permissions or crash recovery. It supports the manuscript's statement
that a native approval covers the pending call identifier, so keeping the executed
arguments equal to the reviewed ones is an application responsibility.
