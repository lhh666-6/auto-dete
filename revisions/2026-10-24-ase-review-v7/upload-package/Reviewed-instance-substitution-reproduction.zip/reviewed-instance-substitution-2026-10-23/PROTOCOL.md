# Frozen protocol: same-identifier reviewed-instance substitution

Prepared 2026-10-23 Asia/Shanghai, before collection. Version 1. Pydantic AI 2.60.0.

## Question

The manuscript's review--execution gap says that a native approval can be satisfied by
the pending call while the executed action no longer equals the reviewed object. The
504-cell and 54-cell studies measured whether reviewed arguments reach the intended
call. This study measures the complementary case: after the review step, the state that
the continuation executes from is replaced for the **same** native tool-call identifier.

RQ: when the human decision only approves the pending call (`ToolApproved()`), does the
native continuation execute the reviewed object or the substituted state? When the
decision re-supplies the reviewed object (`ToolApproved(override_args=...)`), which one
is executed? Which stored object carries the executable arguments?

## Threat injection, stated explicitly

The substitution is a controlled injection of the threat model described in the
literature on post-approval substitution. It is applied **after** the review step and
**before** the native continuation, to the persisted message history and/or the
deferred request object, keeping the native `tool_call_id` unchanged. It never mutates
a live SDK object during a public call, never edits SDK internals, and the executed
arguments are recorded by the tool body itself. Substitution targets: `none`,
`history`, `requests`, `both`.

## Matrix

16 constructed cells = 2 lifecycles x 2 human decisions x 4 substitution targets.
Lifecycle: `live` (pause and continue in one process) and `fresh_process` (persisted
state, exit, new interpreter). Decision: `approve` or `override`. One call per cell,
one declared local tool, ASCII payloads. All cells are retained.

## Outcome classification

The scorer compares the persisted effect rows with the reviewed object and with the
substituted object and reports, per cell: `reviewed_object_executed`,
`substituted_object_executed`, `other_payload_executed`, `no_effect`, or an integrity
class (network guard violation, collection failure, native pending-identity anomaly,
setup mismatch, pre-review effect, execution error). Native pending identity must match
the declared proposal in every phase. This is not a pass/fail study: both executed
objects are legitimate outcomes that answer the question.

## Reporting and limits

Report lifecycle x decision x substitution strata with all denominators. One framework,
one pinned version, one call per cell, a deterministic scripted model and one
realization per cell: no prevalence, significance, cross-framework or novelty claim.
The substitution is a harness-controlled threat injection, not evidence that any
production system was compromised. The study does not test concurrency, authenticated
reviewers, cross-principal access or crash recovery.

## Execution limits

Paid model calls 0; network disabled before adapter import; one directory per cell;
per-stage wall cap 60 s; process-tree RSS cap 768 MiB; artifact cap 32 MiB; global STOP;
exclusive phase claims; completed cases are never replayed. Frozen hashes are verified
before and after collection; runtime and oracle controls must pass before the freeze.
