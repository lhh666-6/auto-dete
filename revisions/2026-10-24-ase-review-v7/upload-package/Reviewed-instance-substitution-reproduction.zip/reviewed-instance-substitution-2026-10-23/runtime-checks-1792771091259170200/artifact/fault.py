from pathlib import Path
import time
Path('big').write_bytes(b'x'*100000)
time.sleep(10)
