import time
print('x'*100000,flush=True)
time.sleep(10)
