from pathlib import Path
Path('big').write_bytes(b'x'*100000)
