import time
x=bytearray(120*1024*1024)
time.sleep(10)
