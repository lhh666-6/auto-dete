import subprocess,sys,time
p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(20)'])
time.sleep(20)
