print('x'*100000,flush=True)
