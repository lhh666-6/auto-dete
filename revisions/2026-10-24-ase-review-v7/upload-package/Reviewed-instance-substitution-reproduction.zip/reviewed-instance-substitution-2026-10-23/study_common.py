from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sqlite3

HERE = Path(__file__).resolve().parent

def now():
    return datetime.now(timezone.utc).isoformat()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.partial')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def create_effect_db(out):
    with sqlite3.connect(Path(out) / 'effects.sqlite', timeout=20) as db:
        db.execute('CREATE TABLE IF NOT EXISTS effects(seq INTEGER PRIMARY KEY, call_id TEXT, tool_name TEXT, payload TEXT)')

def append_effect(out, call_id, payload):
    # Actual arguments only. No expected value or case file is read here.
    with sqlite3.connect(Path(out) / 'effects.sqlite', timeout=20) as db:
        db.execute('INSERT INTO effects(call_id,tool_name,payload) VALUES(?,?,?)',
                   (call_id, 'record_delivery', json.dumps(payload, ensure_ascii=False)))

def effect_rows(out):
    path = Path(out) / 'effects.sqlite'
    if not path.exists():
        return []
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as db:
        return [{'call_id': r[0], 'name': r[1], 'args': json.loads(r[2])}
                for r in db.execute('SELECT call_id,tool_name,payload FROM effects ORDER BY seq')]

def verify_freeze():
    freeze = read(HERE / 'freeze.json')
    for name, digest in freeze['files'].items():
        if sha(HERE / name) != digest:
            raise RuntimeError('SOURCE_DRIFT:' + name)
    for item in freeze['sdk_sources']:
        if sha(item['path']) != item['sha256']:
            raise RuntimeError('SDK_DRIFT:' + item['path'])
    return sha(HERE / 'freeze.json')
