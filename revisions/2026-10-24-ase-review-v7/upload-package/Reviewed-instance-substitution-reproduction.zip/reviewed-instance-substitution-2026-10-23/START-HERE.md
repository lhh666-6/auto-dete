# Start here: Reviewed-instance substitution study

This is the current v7 navigation guide for the preserved evidence archive.
Read this guide first, then [REPRODUCE-V4.md](REPRODUCE-V4.md) for the
portable verification procedure and interpretation corrections. The `V4` in that
filename identifies the existing portable verifier instructions; they remain the
current verification route in this v7 distribution.

## Verify the included evidence

Use Python 3.11 or later with its standard library. After extracting all files,
run these commands from this study directory:

```text
python verify_offline.py
```

The entrypoint is [verify_offline.py](verify_offline.py). It reads the
included SQLite databases in read-only mode, reconstructs reviewed expectations
from the original cases and patches, compares recorded effects with archived
scores, and checks package, completion and frozen-source hashes. It does not
import SDKs, use the network, call a model or run a collector. Recorded absolute
SDK paths are collection-time provenance and are not reopened by this route.
No SDK installation is required for this offline verification.

Expected summary: `verification: PASS`, `16` cells, `12` exact matches
and `4` retained experimental mismatches. Those mismatches are study
outcomes, not verification failures. Missing or altered evidence and disagreement
with the archived scores produce a nonzero exit code. Each archive is a separate
collection; do not pool cells across studies as independent observations.

For an optional full NEW report, run this command inside the study directory:

```text
python verify_offline.py --report readback.json
```

Choose a new report filename if that file already exists; the verifier refuses
to overwrite it.

## Current contents and preserved historical notes

Raw per-cell databases **are included** in this distribution, including
`outputs-v1/<case-id>/effects.sqlite` for all 16 main cells, with
completion records and recorded process traces. The archived scores can therefore
be checked against the distributed raw effects.

[README.txt](README.txt) is a preserved historical collection note.
Its statements that raw databases were omitted or remained local describe an
earlier package and do not describe this distribution. Its local-run commands
and any instruction to regenerate a seal are historical, not the current offline
verification procedure. Follow this guide and `REPRODUCE-V4.md` first.

Keep the original `freeze.json`, `package-manifest.json`, sources, cases, raw
outputs and scores intact. **Do not run `freeze_study.py` over this sealed study**
or replace its freeze to accommodate another machine. The current offline route
preserves the original freezes; it neither regenerates a seal nor recollects data.
`collect.py`, `score.py` and the historical runtime commands retain local SDK and
Windows assumptions. Recollection, if undertaken separately, requires a NEW study
directory, the recorded environment and its own freeze and outputs; it must not
replace this evidence. See `REPRODUCE-V4.md` for the precise boundary.

Only navigation files were added for v7. All earlier archive-member payloads,
including the historical README and existing manifests, are preserved byte for
byte. The new navigation files are not retroactively inserted into the frozen
study inventories; those inventories are integrity records, not signatures.
