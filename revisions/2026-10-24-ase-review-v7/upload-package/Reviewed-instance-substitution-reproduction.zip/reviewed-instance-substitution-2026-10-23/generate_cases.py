"""Deterministic matrix for the reviewed-instance substitution study.

2 lifecycles x 2 human decisions x 4 substitution targets = 16 cells, single call.
"""
from copy import deepcopy
from itertools import product
from study_common import HERE, sha, write
import hashlib

LIFECYCLES = ['live', 'fresh_process']
DECISIONS = ['approve', 'override']
SUBSTITUTIONS = ['none', 'history', 'requests', 'both']
ORIGINAL = {'destination': 'sink-A', 'ticket': 'T-A', 'note': 'proposed-A',
            'quantity': 7, 'enabled': True}


def make_case(lifecycle, decision, substitution, prefix='main'):
    case_id = '-'.join([prefix, 'pydantic_ai', lifecycle, decision, substitution])
    return {'id': case_id, 'framework': 'pydantic_ai', 'lifecycle': lifecycle,
            'decision': decision, 'substitution': substitution,
            'scenario': 'single', 'edit': 'none', 'payload_family': 'ascii',
            'calls': [{'id': 'call-A', 'original': deepcopy(ORIGINAL), 'patch': {}}]}


def generate():
    cases = [make_case(*x) for x in product(LIFECYCLES, DECISIONS, SUBSTITUTIONS)]
    return sorted(cases, key=lambda c: hashlib.sha256(
        ('reviewed-instance-v1|' + c['id']).encode()).hexdigest())


def validate(case):
    schema = {'destination': str, 'ticket': str, 'note': str, 'quantity': int, 'enabled': bool}
    assert case['decision'] in DECISIONS and case['substitution'] in SUBSTITUTIONS
    ids = [c['id'] for c in case['calls']]
    assert len(ids) == len(set(ids)) and len(ids) == 1
    call = case['calls'][0]
    assert set(call['original']) == set(schema) and not call['patch']
    for key, value in call['original'].items():
        assert type(value) is schema[key], (case['id'], key)
    return True


if __name__ == '__main__':
    cases = generate()
    assert len(cases) == 16 and all(validate(c) for c in cases)
    assert not (HERE / 'freeze.json').exists(), 'Do not regenerate frozen cases'
    write(HERE / 'cases.json', cases)
    print({'main': len(cases), 'hash': sha(HERE / 'cases.json')})
