"""Portable v4 readback. Standard library only; never imports SDKs or collects runs.

Run from any directory: python /path/to/extracted/study/verify_offline.py
An experimental mismatch is a retained result, not a verification failure.
Missing data, altered hashes and disagreements with the frozen scores fail closed.
"""
from collections import Counter, defaultdict
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import sys


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canon(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def local(base, name):
    target = (base / name).resolve()
    if not target.is_relative_to(base.resolve()):
        raise ValueError('Path outside package: ' + name)
    return target


def verify(base):
    checks = 0
    def require(condition, message):
        nonlocal checks
        checks += 1
        if not condition:
            raise ValueError(message)

    package = read(base/'package-manifest.json')
    for name, digest in package['files'].items():
        path = local(base, name)
        require(path.is_file() and sha(path) == digest, 'Package hash mismatch: ' + name)
    freeze = read(base/'freeze.json')
    frozen_hash = sha(base/'freeze.json')
    require(frozen_hash == package['original_freeze_sha256'], 'Original freeze changed')
    for name, digest in freeze['files'].items():
        path = local(base, name)
        require(path.is_file() and sha(path) == digest, 'Frozen source mismatch: ' + name)
    # Absolute SDK installation paths in freeze.json are historical provenance.
    # They are deliberately not opened by the portable effects verifier.
    cases = read(base/'cases.json')
    scores = read(base/'score-v1.json')['rows']
    require(len({c['id'] for c in cases}) == len(cases), 'Duplicate case identifier')
    scored = {r['id']:r for r in scores}
    require(len(scored) == len(scores), 'Duplicate archived score identifier')
    require(set(scored) == {c['id'] for c in cases}, 'Cases and archived scores differ')
    groups = defaultdict(Counter)
    rows = []
    for case in cases:
        cell = local(base/'outputs-v1', case['id'])
        complete = read(cell/'complete.json')
        require(complete['status'] == 'collected', case['id'] + ': not collected')
        require(complete['freeze_sha256'] == frozen_hash, case['id'] + ': wrong freeze')
        actual_files = {p.relative_to(cell).as_posix() for p in cell.rglob('*') if p.is_file() and p.name != 'complete.json'}
        require(actual_files == set(complete['artifacts']), case['id'] + ': artifact inventory differs')
        for name, digest in complete['artifacts'].items():
            require(sha(local(cell, name)) == digest, case['id'] + ': altered artifact ' + name)
        with sqlite3.connect((cell/'effects.sqlite').as_uri()+'?mode=ro', uri=True) as db:
            require(db.execute('PRAGMA quick_check').fetchone()[0] == 'ok', case['id'] + ': SQLite integrity')
            observed = [{'call_id':r[0], 'name':r[1], 'args':json.loads(r[2])}
                        for r in db.execute('SELECT call_id,tool_name,payload FROM effects ORDER BY seq')]
        expected = [{'call_id':c['id'], 'name':'record_delivery', 'args':{**c['original'], **c['patch']}} for c in case['calls']]
        match = Counter(map(canon, observed)) == Counter(map(canon, expected))
        old = scored[case['id']]
        old_match = old['effect_match'] if 'effect_match' in old else old['executed'] == 'reviewed_object_executed'
        require(match == old_match, case['id'] + ': archived score disagrees with raw effects')
        phases = ['prepare','resume'] if case['lifecycle'] == 'fresh_process' else [case['lifecycle']]
        phase_data = {p:read(cell/(p+'.json')) for p in phases}
        pending = [{'call_id':c['id'], 'name':'record_delivery', 'args':c['original']} for c in case['calls']]
        for phase, record in phase_data.items():
            require(not record.get('error') and not record.get('network_attempts',0), case['id']+': worker/network error')
            trace = record.get('trace',{})
            require(not trace.get('framework_errors',[]), case['id']+': framework error')
            require(Counter(map(canon,trace.get('pending',[]))) == Counter(map(canon,pending)), case['id']+': pending calls differ')
        if case['lifecycle'] == 'fresh_process':
            require(phase_data['prepare']['pid'] != phase_data['resume']['pid'], case['id']+': same process')
            require(phase_data['prepare']['effects_after_phase'] == 0, case['id']+': premature effect')
        label = 'match' if match else 'mismatch'
        group = '/'.join([case['framework'],case['lifecycle']] + ([case['decision'],case['substitution']] if 'decision' in case else []))
        groups[group][label] += 1
        rows.append({'id':case['id'],'match':match,'expected':expected,'observed':observed})
    require(len(rows) == package['expected_cases'], 'Wrong total cell count')
    require(sum(r['match'] for r in rows) == package['expected_matches'], 'Wrong total exact matches')
    return {'verification':'PASS','cases':len(rows),'match':sum(r['match'] for r in rows),
            'mismatch':sum(not r['match'] for r in rows),'checks':checks,
            'original_freeze_sha256':frozen_hash,
            'sdk_source_verification':'Not performed: recorded absolute SDK paths are provenance, not needed for offline readback.',
            'groups':{k:dict(v) for k,v in sorted(groups.items())},'rows':rows}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, help='Optional NEW JSON report; an existing file is never overwritten')
    args = parser.parse_args()
    try:
        result = verify(Path(__file__).resolve().parent)
        if args.report:
            with args.report.open('x', encoding='utf-8') as f:
                json.dump(result,f,ensure_ascii=False,indent=2)
                f.write('\n')
        print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2))
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error) as exc:
        print(json.dumps({'verification':'FAIL','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        raise SystemExit(1)
