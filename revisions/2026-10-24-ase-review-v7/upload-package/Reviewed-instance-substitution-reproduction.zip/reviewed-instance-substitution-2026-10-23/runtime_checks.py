"""Runtime and oracle controls for the reviewed-instance substitution study."""
from pathlib import Path
import copy
import subprocess
import sys
import threading
import time
import psutil
from study_common import HERE, read, write, sha, now, create_effect_db, append_effect
from collect import supervise, artifact_hashes, verify_complete, clean_environment
from score import score_case, rows_for, SUBSTITUTED
from generate_cases import ORIGINAL


def main():
    folder = HERE / ('runtime-checks-' + str(time.time_ns()))
    folder.mkdir()
    checks = []

    def run(label, program, expected, **limits):
        work = folder / label
        work.mkdir()
        script = work / 'fault.py'
        script.write_text(program, encoding='utf-8')
        stop = work / 'STOP'
        if label == 'global_stop':
            timer = threading.Timer(.4, lambda: write(stop, {'test': True}))
            timer.start()
        result = supervise([sys.executable, '-P', '-B', str(script)], work, 'fault', stop, **limits)
        if label == 'global_stop':
            timer.join()
        dead = all(not psutil.pid_exists(pid) for pid in result.get('observed_tree_pids', []))
        checks.append({'name': label, 'expected': expected, 'actual': result,
                       'descendants_dead': dead,
                       'pass': result['status'] == expected and dead})

    run('timeout_tree', "import subprocess,sys,time\np=subprocess.Popen([sys.executable,'-c','import time; time.sleep(20)'])\ntime.sleep(20)\n", 'timeout', timeout=.8)
    run('memory', "import time\nx=bytearray(120*1024*1024)\ntime.sleep(10)\n", 'memory_limit', memory_mib=60)
    run('log', "import time\nprint('x'*100000,flush=True)\ntime.sleep(10)\n", 'log_limit', log_bytes=1000)
    run('artifact', "from pathlib import Path\nimport time\nPath('big').write_bytes(b'x'*100000)\ntime.sleep(10)\n", 'artifact_limit', artifact_bytes=2000)
    run('global_stop', "import time\ntime.sleep(10)\n", 'global_stop')
    run('fast_exit_log', "print('x'*100000,flush=True)\n", 'log_limit', log_bytes=1000)
    run('fast_exit_artifact', "from pathlib import Path\nPath('big').write_bytes(b'x'*100000)\n", 'artifact_limit', artifact_bytes=2000)

    work = folder / 'resume'
    work.mkdir()
    case = {'id': 'test-resume'}
    write(work / 'case.json', case)
    write(work / 'complete.json', {'case_id': case['id'], 'freeze_sha256': 'fixture-freeze',
                                   'artifacts': artifact_hashes(work)})
    checks.append({'name': 'validated_resume',
                   'pass': verify_complete(work, case, 'fixture-freeze')['case_id'] == case['id']})
    try:
        verify_complete(work, case, 'different-freeze')
        blocked = False
    except RuntimeError:
        blocked = True
    checks.append({'name': 'resume_wrong_freeze_refused', 'pass': blocked})
    (work / 'unexpected.txt').write_text('retained test mutation', encoding='utf-8')
    try:
        verify_complete(work, case, 'fixture-freeze')
        blocked = False
    except RuntimeError:
        blocked = True
    checks.append({'name': 'resume_tamper_refused', 'pass': blocked})

    env = clean_environment(sys.executable, folder)
    checks.append({'name': 'credentials_not_forwarded',
                   'pass': not any(any(x in k.upper() for x in ['API_KEY', 'TOKEN', 'SECRET', 'PASSWORD'])
                                   for k in env)})
    claimed = folder / 'claimed-phase'
    claimed.mkdir()
    write(claimed / 'case.json', {'id': 'duplicate-claim', 'framework': 'must-never-import'})
    write(claimed / 'live.claim.json', {'prior_claim': True})
    refused = subprocess.run([sys.executable, '-P', '-B', str(HERE / 'worker.py'),
                              '--case-file', str(claimed / 'case.json'), '--out', str(claimed),
                              '--phase', 'live'], capture_output=True, text=True)
    checks.append({'name': 'worker_claim_refuses_before_effects',
                   'pass': refused.returncode == 3 and not (claimed / 'effects.sqlite').exists()
                           and not (claimed / 'live.json').exists()})

    cases = read(HERE / 'cases.json')
    oracle_case = next(c for c in cases if c['lifecycle'] == 'live'
                       and c['decision'] == 'approve' and c['substitution'] == 'none')
    root = folder / 'oracle'
    pending = [{'call_id': call['id'], 'name': 'record_delivery', 'args': call['original']}
               for call in oracle_case['calls']]
    base_trace = {'pending': pending, 'native_status': 'completed',
                  'framework_errors': [], 'effects_before_continue': 0}

    def run_oracle(name, rows, trace_extra=None):
        oracle_root = folder / ('oracle-' + name)
        dest = oracle_root / oracle_case['id']
        dest.mkdir(parents=True)
        write(dest / 'case.json', oracle_case)
        create_effect_db(dest)
        write(dest / 'live.json', {'pid': 1234, 'trace': {**base_trace, **(trace_extra or {})}})
        for row in rows:
            append_effect(dest, row['call_id'], row['args'])
        write(dest / 'complete.json', {'status': 'collected', 'artifacts': artifact_hashes(dest)})
        return score_case(oracle_case, oracle_root)['executed']

    reviewed = rows_for(oracle_case, ORIGINAL)
    substituted = rows_for(oracle_case, SUBSTITUTED)
    other = [{**reviewed[0], 'args': {**ORIGINAL, 'note': 'other'}}]
    checks.append({'name': 'oracle_reviewed_object',
                   'pass': run_oracle('reviewed', reviewed) == 'reviewed_object_executed'})
    checks.append({'name': 'oracle_substituted_object',
                   'pass': run_oracle('substituted', substituted) == 'substituted_object_executed'})
    checks.append({'name': 'oracle_other_payload',
                   'pass': run_oracle('other', other) == 'other_payload_executed'})
    checks.append({'name': 'oracle_no_effect', 'pass': run_oracle('none', []) == 'no_effect'})
    checks.append({'name': 'oracle_pre_review_effect',
                   'pass': run_oracle('pre-review', reviewed, {'effects_before_continue': 1})
                   == 'pre_review_effect'})

    report = {'utc': now(), 'checks': checks, 'passed': sum(c['pass'] for c in checks),
              'total': len(checks)}
    write(folder / 'RESULT.json', report)
    write(HERE / 'runtime-checks-latest.json',
          {'path': str(folder / 'RESULT.json'), 'sha256': sha(folder / 'RESULT.json'),
           'passed': report['passed'], 'total': report['total']})
    print({'passed': report['passed'], 'total': report['total'], 'path': str(folder)})
    assert report['passed'] == report['total'], 'Runtime or oracle control failed'


if __name__ == '__main__':
    main()
