import os
import sys
from pathlib import Path

assert sys.flags.safe_path, 'Use Python -P'
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from study_common import read, write, now, sha, create_effect_db, effect_rows, verify_freeze
import argparse
import asyncio
import importlib.util
import socket
import traceback

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--case-file', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--phase', required=True, choices=['live', 'same_process', 'prepare', 'resume'])
    p.add_argument('--frozen', action='store_true')
    a = p.parse_args()
    case = read(a.case_file)
    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    target = out / (a.phase + '.json')
    if target.exists():
        print('NO_REPLAY_COMPLETED_PHASE', flush=True)
        return 3
    # Claim before SDK import, DB opening or execution. A crashed phase is not
    # automatically replayable, even if its final JSON was never written.
    try:
        with (out / (a.phase + '.claim.json')).open('x', encoding='utf-8') as claim:
            import json
            json.dump({'pid': os.getpid(), 'utc': now(), 'case_id': case['id']}, claim)
    except FileExistsError:
        print('NO_REPLAY_CLAIMED_PHASE', flush=True)
        return 3
    record = {'case_id': case['id'], 'phase': a.phase, 'started_utc': now(),
              'pid': os.getpid(), 'input_sha256': sha(a.case_file), 'paid_calls': 0}
    attempts = []
    loop = None
    try:
        if a.frozen:
            record['freeze_sha256'] = verify_freeze()
            declared = next(c for c in read(HERE / 'cases.json') if c['id'] == case['id'])
            assert declared == case, 'Case differs from frozen manifest'
        # Windows asyncio needs its private self-pipe before denial of new sockets.
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        def deny(*args, **kwargs):
            attempts.append('blocked-new-network-operation')
            raise RuntimeError('NETWORK_DISABLED')
        socket.socket.connect = deny
        socket.socket.connect_ex = deny
        socket.socket.sendto = deny
        socket.create_connection = deny
        socket.getaddrinfo = deny
        record['network_guard_installed_before_adapter'] = True
        create_effect_db(out)
        record['effects_before_phase'] = len(effect_rows(out))
        spec = importlib.util.spec_from_file_location('study_adapter', HERE / 'adapters' / (case['framework'] + '.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        record['trace'] = module.execute(case, out, a.phase)
        record['effects_after_phase'] = len(effect_rows(out))
        if a.frozen:
            verify_freeze()
    except Exception as e:
        record['error'] = {'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()}
    finally:
        record['network_attempts'] = len(attempts)
        record['ended_utc'] = now()
        if loop is not None:
            try:
                loop.close()
            except Exception as e:
                record['loop_cleanup_error'] = repr(e)
        if target.exists():
            raise RuntimeError('NO_OVERWRITE:' + str(target))
        write(target, record)
    print({'case': case['id'], 'phase': a.phase, 'error': record.get('error', {}).get('type')}, flush=True)
    return 2 if record.get('error') else 0

if __name__ == '__main__':
    raise SystemExit(main())
