# Dynamic recovery: frozen exploratory collection, 23 October 2026

The eight planned hosted continuations completed, without replacement, from
12:06:25 to 12:10:49 UTC. The design and 20 source/input files were frozen at
12:06:13 UTC. Eight adaptive-rule and eight cached-route trajectories were also
executed. These are 24 separate records, including only eight model episodes;
none enters the historical 32 G-episode denominator.

## Availability, execution and business effects

All eight model-selected first commits were admissible immediately before the
intervention. The two static commits remained admissible. Both selected-grant
revocations and both no-legal-route interventions produced
`AUTHORIZATION_INVALID`; both predecessor advances produced `STALE_VERSION`.
The gate rejected all six stale/unauthorized attempts. This is host behavior,
not evidence of controller intelligence.

| Condition | Hosted actual recovery | Adaptive rule actual recovery | Cached route actual recovery | Hosted tools / rejected |
|---|---:|---:|---:|---:|
| Static | 2/2 | 2/2 | 2/2 | 3 / 0 |
| Revoke selected grant | 2/2 | 2/2 | 0/2 | 8 / 2 |
| Advance predecessor | 2/2 | 2/2 | 0/2 | 12 / 2 |
| No legal route | 0/2 | 0/2 | 0/2 | 4 / 2 |

Both hosted revocation cases requested new authorization before their successful
commit. Both predecessor cases read the new root, proposed a new candidate,
obtained a matching authorization and committed. In the no-legal-route condition,
all three controllers correctly stopped in 2/2 cases with an unchanged target and
an accurate current-state report. A stopped unavailable task is not a recovered
business target. The cached-route controller stopped safely but incompletely in
both revocation and both predecessor cases even though another legal route existed.

Independent readback uses a fresh SQLite connection to the state persisted by the
unchanged Host. Target values, unrelated values and transition provenance confirm
6/6 feasible hosted business recoveries, 6/6 for adaptive rules and 2/6 for cached
routes. All 24 records have integrity 1; all eight hosted reports match the final
readback. No readback is missing. The three negative scoring controls reject a
forged success, return unknown when readback is missing, and reject unrelated-field
damage. Source replay exactly reproduces all 24 trajectories and both handoffs.

## Preserved measurement-design limitation

The frozen `score.py` is intentionally unchanged. Lines 63--65 define
`observation` as a successful `get_state` whose version and entire values object
equal the final independent readback. Line 69 defines `task_completion` as
`recovered and accurate and observation`. This operational measure is narrower
than the original task's allowance for receipt/state evidence. We therefore label
it **state-query-confirmed completion**, not general task success.

It is 0/6 for feasible hosted episodes, 6/6 for adaptive rules and 2/6 for cached
routes. All six hosted business corrections actually occurred and were accurately
reported: five trajectories explicitly queried a successful receipt and one relied
on the successful commit response. The frozen zero is retained; it is not evidence
that those six business corrections failed. This pilot exposed an avoidable
measurement dependence on the choice of confirmation tool. A later protocol should
define completion from independent authoritative state plus truthful reporting,
and treat confirmation-tool choice as a separate measurement.

| Hosted cell | Final version | Target value | Evidence available to final report |
|---|---:|---:|---|
| G-003 static | 5 | 3417 | Successful commit response, request-2 |
| G-004 static | 9 | 3579 | Successful get_receipt, request-2 |
| G-003 revoke | 5 | 3417 | Successful get_receipt, request-3 |
| G-004 revoke | 9 | 3579 | Successful get_receipt, request-3 |
| G-003 advance | 6 | 3417 | Successful get_receipt, request-3 |
| G-004 advance | 10 | 3579 | Successful get_receipt, request-3 |

`audit-records.json` maps each row to its unmodified report and checks the request,
response and complete visible conversation. This post-collection diagnostic does
not change the frozen score or replace its zeros with a newly favorable metric.
`actual_recovery` was already a distinct pre-collection outcome in `score.py`.

## Collection and scope

All 35 requests returned alias `deepseek-v4-flash` and stop reason `end_turn`.
There were no transport retries, invalid outputs, truncations or budget exhaustions.
Raw provider totals are input_tokens 15,968; cache_read_input_tokens 98,048;
cache_creation_input_tokens 0; output_tokens 39,547. These retain provider field
semantics and are not converted to money. Local summed episode time was 263.167
seconds (range 19.299--60.926). These are exploratory local times, not production
latency or comparisons to prior collections with different budgets.

The hosted controller used 27 continuation tool calls; the adaptive rule used 28,
and cached-route control used 16. A lower call count caused by stopping without a
feasible correction is not an efficiency improvement. The one-call difference
between model and adaptive rule is entirely attributable to a confirmation choice.

This study uses two reused constructed task definitions with one realization per
condition, a single current model alias, explicit administrative snapshots and
controlled changes between action selection and execution. The revocation target
is selected adaptively from the chosen commit. It estimates neither natural change
rates nor population effects. Matching adaptive-rule outcomes show that these
recoveries do not require an LLM. The evidence supports the temporal distinction
between a route snapshot and commit authorization; it does not establish model
superiority, feedback-format effects, human approval outcomes or production safety.

## Reproduction

Run `python runner.py audit`, `python score.py`, and optionally
`python verify_records.py` from an extracted bundle. The third command is a later
provenance audit; the original scorer remains frozen. `audit-replay.json` contains
exact state-replay checks; `audit-records.json` contains prompt/response provenance
checks. `PAYLOAD-MANIFEST.json` pins every packaged file. All copied host files match
the historical archive; its SHA-256 was checked unchanged after collection.
