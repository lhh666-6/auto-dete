# Separate dynamic recovery study

Read `PROTOCOL.md` for the fixed design and limitations. Eight hosted continuations
are planned, plus eight adaptive rule and eight cached-route rule controls. The
host, independent oracle and provider adapter are byte-identical copies from the
historical feedback reproduction archive. All newly written code is local here.

Python 3.11 and `jsonschema==4.26.0` are the tested runtime. After extracting the
bundle, reproduce the saved execution audit and independent scoring without any
model calls:

```text
python -m pip install -r requirements.txt
python runner.py audit
python score.py
```

`freeze.json` pins the protocol, source, inputs, configuration and allocation before
collection. `provenance.json` maps the copied original sources to the source archive.
`raw/<controller>/<cell>/` retains every started episode, complete visible messages,
provider responses/usage, state boundary records, a SQLite store and a fresh-connection
readback. `runtime/` records local runtime and collection times. `summary.json` and
`results.csv` distinguish available initial routes, commit-time admissibility,
observed business recovery, correct stops, unknowns and costs.

No credentials are included. Live collection is deliberately separate from offline
reconstruction. The original invocation used the existing encrypted local credential
via `runner.py collect --controller model --credential-file <local-file>`; alternatively
the unchanged provider adapter accepts `PHASE2_DSH_API_KEY`. Every existing episode
directory is protected against overwrite. A fresh live replication requires a new
copy with a newly declared collection and freeze; do not delete historical results
to rerun a failed cell. The archive does not fix provider-side model weights.

`runner.py package` writes `Dynamic-recovery-reproduction.zip` and a SHA-256 payload
manifest. It excludes that archive from itself. No part of this study changes the
historical 32 G-episode denominator, measures human review/production latency, or
establishes LLM superiority. Runtime is local exploratory timing only.
