# Dynamic recovery study audit — 23 October 2026

Owned scope: `experiments/dynamic-recovery/**` and the new
`supplements/online-resource-2/dynamic-recovery.tex`. No historical raw studies,
frozen source archives, main manuscript or other SI sources were changed.

The protocol and 20 files were frozen at 12:06:13 UTC. The eight hosted episodes
ran 12:06:25–12:10:49 UTC using the existing authorized encrypted credential and
the unchanged historical provider adapter. No global API configuration was changed.
There were exactly eight hosted episodes, eight adaptive rule trajectories and
eight cached-route controls. All records are retained; there were no unstarted
cells or replaced runs. The source Feedback-sensitivity archive remained unchanged.

Observed hosted outcomes: 6/6 feasible business corrections verified by fresh
SQLite readback, 2/2 correct stops when no legal route remained, 8/8 integrity and
8/8 accurate final reports. All first selected commits were initially admissible;
the six dynamically invalidated first attempts were rejected. Adaptive rules match
these outcomes. Cached routes recover only the two static cases and correctly stop
in the two unavailable cases; their four other feasible tasks remain incomplete.
These are dynamic mechanism witnesses, not evidence of LLM advantage.

The original frozen scoring code is unchanged. Its `observation` at score.py
lines 63–65 requires `get_state` at the final version with all final values;
line 69 computes `task_completion = recovered and accurate and observation`.
Consequently its strict state-query-confirmed completion is **0/6 hosted**, **6/6
adaptive rule**, **2/6 cached route**. This is a pilot measurement-design limitation:
the original task allows receipt/state evidence. Five feasible hosted trajectories
queried successful receipts and one relied on its successful commit response.
Do not describe the strict zeros as failed business corrections and do not rewrite
the frozen score. Independent business recovery was already a separate frozen
outcome. `audit-records.json` provides the exact six evidence mappings:

| Task / condition | Evidence | Version | Value |
|---|---|---:|---:|
| G-003 static | commit response request-2 | 5 | 3417 |
| G-004 static | get_receipt request-2 | 9 | 3579 |
| G-003 revoke | get_receipt request-3 | 5 | 3417 |
| G-004 revoke | get_receipt request-3 | 9 | 3579 |
| G-003 advance | get_receipt request-3 | 6 | 3417 |
| G-004 advance | get_receipt request-3 | 10 | 3579 |

Validation completed: 24 exact host replays, two exact handoff reconstructions,
35 raw-response/visible-prompt matches, all conversation records exact, three
scorer negative controls, and source-archive hash unchanged. All 35 responses
returned deepseek-v4-flash with end_turn. No retries, truncations, invalid actions
or budget exhaustion. No completion or superiority significance tests were run.

Read `experiments/dynamic-recovery/RESULTS.md` for complete counts, raw usage and
limitations. `runner.py audit` and `score.py` reconstruct without live calls;
`verify_records.py` is an additional post-collection provenance check and does not
amend scoring. `freeze.json`, `provenance.json`, runtime records, raw records and
`PAYLOAD-MANIFEST.json` accompany the standalone reproduction ZIP.
