"""Additional post-collection provenance audit, not a scoring amendment."""
import sys
sys.dont_write_bytecode=True
from collections import Counter
import hashlib
import json
from pathlib import Path
import runner

HERE=Path(__file__).resolve().parent
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    runner.verify_freeze();runner.imports()
    from phase2.providers import OUTPUT_RULE, parse_action
    from phase2.kernel import canonical
    count=0; aliases=Counter(); stops=Counter(); tokens=Counter(); times=[]; basis=[]
    for task in runner.TASKS:
        assert runner.initial_block(task)==read(HERE/'prepared'/(task+'.json'))
    for path in sorted((HERE/'raw').glob('*/*/episode.json')):
        data=read(path)
        messages=read(HERE/'prepared'/(data['cell']['task_id']+'.json'))['messages']
        returned=None
        for event in data['events']:
            if event['kind']=='provider_return':
                directory=path.parent/f"decision-{event['step']:02d}"/f"attempt-{event['attempt']}"
                prompt=OUTPUT_RULE+'\nVISIBLE CONVERSATION:\n'+canonical(messages)
                assert (directory/'prompt.txt').read_text(encoding='utf-8')==prompt
                response=read(directory/'response.json')
                metadata=read(directory/'metadata.json')
                raw=''.join(b.get('text','') for b in response['content'] if b.get('type')=='text')
                assert raw==metadata['raw_action']
                assert metadata['model']==response.get('model')==event['metadata']['model']
                assert metadata['usage']==response.get('usage',{})==event['metadata']['usage']
                assert metadata['provider_request_id']==response.get('id')
                returned=parse_action(raw)
                aliases[response.get('model')]+=1;stops[response.get('stop_reason')]+=1
                for key,value in response.get('usage',{}).items():
                    if isinstance(value,(int,float)):tokens[key]+=value
                times.append(metadata['elapsed_seconds']);count+=1
            elif event['kind']=='decision':
                if data['controller']=='model': assert returned==event['action']
                messages.append({'kind':'agent_action','action':event['action']})
            elif event['kind']=='tool_execution':
                messages.append({'kind':'tool_result','tool_name':event['tool'],'result':event['result']})
            elif event['kind']=='visible_administration': messages.append(event['notice'])
        assert messages==read(path.parent/'conversation.json')
        if data['controller']=='model':
            tools=[e for e in data['events'] if e['kind']=='tool_execution']
            last_success=next((e for e in reversed(tools) if e['tool']=='commit' and e['result'].get('status')=='ok'),None)
            if last_success:
                receipt=next((e for e in tools if e['tool']=='get_receipt'
                    and e['result'].get('commit_request_id')==last_success['result']['commit_request_id']
                    and e['result'].get('status')=='ok'),None)
                basis.append({'task_id':data['cell']['task_id'],'mode':data['cell']['mode'],
                    'successful_commit_request_id':last_success['result']['commit_request_id'],
                    'successful_commit_version':last_success['result']['version'],
                    'successful_commit_value':last_success['result']['committed_value'],
                    'report':data['report'], 'confirmation': 'get_receipt' if receipt else 'commit_response',
                    'strict_get_state_completion':False})
    archive=HERE.parent.parent/'Feedback-sensitivity-reproduction.zip'
    original=read(HERE/'provenance.json')
    archive_check={'checked':archive.exists(),'unchanged':None}
    if archive.exists():
        archive_check['unchanged']=hashlib.sha256(archive.read_bytes()).hexdigest()==original['source_archive_sha256']
        assert archive_check['unchanged']
    result={'audit_kind':'post_collection_provenance_checks_no_rescoring',
        'source_archive':archive_check,'initial_handoffs_reconstructed':2,
        'all_conversations_exact':True,'provider_responses_checked':count,
        'returned_alias_counts':dict(aliases),'stop_reason_counts':dict(stops),'usage_totals':dict(tokens),
        'provider_request_seconds':times,'completion_evidence_diagnostic':basis,
        'limitation':'Frozen task_completion requires get_state at final version and excludes successful receipts/commit replies. Keep its zeros; this diagnostic does not change that score.'}
    runner.write(HERE/'audit-records.json',result)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
