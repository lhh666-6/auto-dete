"""Reaudit the frozen 14 October feedback study without rewriting its records.

Calls only read-only audit/analysis functions; never prepare, live or summarize.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repository-root', type=Path, default=BASE.parent.parent)
    p.add_argument('--output', type=Path, default=BASE / 'tables' / 'feedback-sensitivity')
    a = p.parse_args()
    root = a.repository_root / 'research/agent-recovery-feedback-ablation-2026-10-14'
    before = {p.relative_to(root).as_posix(): sha(p) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    freeze = read(root / 'freeze.json')
    for name, expected in freeze['files'].items():
        assert sha(root / name) == expected, name
    pilot = load('frozen_feedback_pilot', root / 'pilot.py')
    analysis = load('frozen_feedback_analysis', root / 'analysis.py')
    assert not pilot.check_provenance()
    cells = read(root / 'allocation.json')['cells']
    rows = []
    for kind in ('rule', 'live'):
        for cell in cells:
            directory = root / kind / cell['cell_id']
            assert read(directory / 'started.json')['started_utc'] > freeze['frozen_utc'] if kind == 'live' else True
            block = read(root / 'prepared' / (cell['block_id'] + '.json'))
            row = pilot.audit_episode(directory, block, cell)
            assert not row['audit_errors'], (cell, row['audit_errors'])
            rows.append(row)
    summary = {'results': rows, 'all_episode_audits_pass': True,
               'original_and_freeze_errors': [], 'incomplete_started': []}
    result = analysis.build_analysis(root, summary, read(root / 'allocation.json'))
    groups = []
    for feedback in ('facts', 'facts_plus_options'):
        rs = [r for r in rows if r['controller'] == 'model' and r['feedback'] == feedback]
        groups.append({'feedback': feedback, 'episodes': len(rs),
                      'feasible_completion': sum(r['U'] for r in rs if r['authorization_state'] != 'unavailable'),
                      'feasible_denominator': sum(r['authorization_state'] != 'unavailable' for r in rs),
                      'unavailable_safe_stops': sum(r['safe_stop'] for r in rs if r['authorization_state'] == 'unavailable'),
                      'integrity_1': sum(r['I'] == 1 for r in rs), 'tool_calls': sum(r['tool_calls'] for r in rs),
                      'authorization_requests': sum(r['authorization_requests'] for r in rs),
                      'rejected_operations': sum(r['rejected_commits'] + r['rejected_authorizations'] for r in rs)})
    delta = Counter(p['delta']['all_tool_calls'] for p in result['pairs'] if p['controller'] == 'model')
    after = {p.relative_to(root).as_posix(): sha(p) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert before == after
    a.output.mkdir(parents=True, exist_ok=True)
    audit = {'source': str(root), 'frozen_utc': freeze['frozen_utc'], 'frozen_files_checked': len(freeze['files']),
             'raw_files_unchanged': len(before), 'episodes_reconstructed': len(rows), 'model_groups': groups,
             'paired_call_differences': dict(delta), 'source_hashes': before,
             'scope': 'Reconstruction of an existing, separately frozen exploratory study; no new hosted collection.'}
    for name, value in [('audit.json', audit), ('analysis.json', result), ('episodes.json', summary)]:
        (a.output / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    analysis.write_pairs(a.output / 'pairs.csv', result['pairs'])
    print(json.dumps({k:v for k,v in audit.items() if k != 'source_hashes'}))


if __name__ == '__main__':
    main()
