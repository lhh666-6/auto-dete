# Frozen feedback-sensitivity study: offline reproduction

This package preserves the exploratory study collected on 14 October 2026.
It contains 24 hosted trajectories, 24 separate deterministic rule trajectories,
80 frozen study files and the exact 41 source dependencies named in provenance.
No new hosted collection was performed for the 23 October revision.

Use Python 3.11. The tested dependency is jsonschema 4.26.0; installation
may require network access, but the reconstruction command does not.

From this extracted directory:

```text
python -m pip install -r requirements.txt
python qa/feedback_sensitivity.py --repository-root . --output rebuilt
```

The entry point imports only the frozen audit functions, checks the original
source hashes and study freeze, reconstructs saved actions, tool effects and
final scoring, and writes derived outputs under `rebuilt/`. It does not call a
provider, create new trajectories or rewrite the raw study files. The archived
pilot and analysis CLIs are retained as historical source; use the read-only
entry point above for this package.

Expected: 48 reconstructed episodes, no audit errors; in each hosted feedback
variant 8/8 feasible completions, 4/4 unavailable-state correct stops, 12/12
integrity passes, 16 tool calls, four authorization requests and zero rejected
continuation operations. Paired tool-call differences (options minus facts)
are -1 in three pairs, zero in six and +1 in three.

Study directory: research/agent-recovery-feedback-ablation-2026-10-14/.
`PROTOCOL.md`, `freeze.json`, `allocation.json`, `cells/`, `live/`, `rule/`
and `prepared/` retain the design and complete records. `SOURCE-MANIFEST.json`
pins every distributed payload. Original output/protection files are retained
as historical artifacts; this entry point does not reconstruct unrelated
prior-study protection checks. Four reused task definitions and one realization
per cell support descriptive statements only, separately from formal-study
completion estimates. Provider aliases do not identify immutable model weights.
