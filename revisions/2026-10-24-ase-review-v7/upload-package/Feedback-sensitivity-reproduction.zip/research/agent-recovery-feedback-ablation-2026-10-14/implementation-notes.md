# Ablation runner implementation notes

The new runner was copied from `agent-recovery-feedback-minipilot-2026-10-14-expanded-output/pilot.py`. Only the new directory's `pilot.py`, `test_pilot.py`, and this note were authored by the implementation worker. Existing batches were read only. The worker did not run `prepare`, `live`, or create a freeze.

## Scope and invariants

- Selected checkpoint/prefix inputs are deployment B for FORMAL-G-003 through FORMAL-G-006, in ascending ID order. Only checkpoint state and the seven-message checkpoint conversation are loaded; original suffix outcomes are not consulted.
- The 24 cells comprise four tasks, three administrative states, and two presentations: `facts` and `facts_plus_options`.
- Both arms contain identical historical rejection facts and current administration facts. The sole added prompt field is `result.legal_next_action_options` in the plus arm.
- `options_from_visible` accepts only the visible result object and reads `current_administration.old_grant_status` and `reviewer_active`. It does not query the Host, scoring oracle, case, or hidden state. The mapping is deliberately scoped to this fixture: unavailable reviewer yields `[]`; active grant with available reviewer yields `reuse_reviewed`, `reauthorize`, `fresh_proposal`; revoked grant with available reviewer yields the last two labels.
- `fixture_preconditions` separately checks both candidates with `Host.valid`, distinct instances, matching candidate/grant contexts, reviewed snapshot, target, reviewer identity, authorized value, required visible capabilities, and agreement of the narrow visible-facts mapping with the unchanged oracle. The original replay and exact administrative-delta checks remain in place.
- The deterministic rule controller, common instructions, original Provider facade, parsing, oracle, tool execution, model alias, temperature, and transport interface are retained. No thinking parameter or fallback model is added. Limits remain six decisions, output allowance 393216, request timeout 1800 seconds, episode allowance 21600 seconds, and at most one transient retry.
- HTTP 400, authentication/quota/model-unavailable failures preserve the existing global-stop behavior. Empty/truncated action output remains a retained provider data error without an automatic retry or allowance reduction. The existing retained `error` field after a successful transient retry is unchanged; use terminal and attempt records to interpret it.

## Allocation and preparation

`allocate_cells` uses seed 20261014. It first shuffles the 12 task-by-state blocks, then assigns exactly two `facts`-first and two `facts_plus_options`-first tasks within each state. Each pair is executed adjacently. Cell metadata adds `pair_id` (equal to `block_id`), zero-based `pair_index`, and one-based `order_in_pair`; `allocation.json` also contains a `pairs` list and each pair's `feedback_order`.

`prepare` generates `pair-invariance.json` and includes the checks in `preflight.json`. For each pair it compares canonical message bytes after removing only the options field, saves the two corresponding hashes, checks initial-state byte equality, checks visible options against oracle paths, and records fixture-precondition errors. Planned episode counts are computed from the allocation length.

The freeze list includes protocol, runner/tests, `analysis.py`, `test_analysis.py`, public config, allocation, provenance, preflight, pair invariance, `protected-before.json`, `prior-batches-protection.json`, and every input/prepared/cell artifact. Previous-batch `comparability.json` is not required for this new task sample. Parent-owned files must exist before freeze creation.

## Notice timing and provenance

`run_episode` starts its monotonic episode clock, constructs the actual notice exactly once, and reuses that object in the saved notice and initial visible history. It saves `notice-build.json` separately from the prompt. The per-episode audit score includes that object under `notice_build`.

Fields in `notice-build.json`:

- `schema_version`: `notice-build-v1`.
- `feedback`, `source`: `shared_visible_result_facts`, and `options_algorithm`: `g-fixture-visible-facts-v1`.
- `visible_facts_sha256`: canonical visible result before any options are attached.
- `notice_sha256` and `notice_utf8_bytes`: canonical UTF-8 bytes of the final notice.
- `notice_wall_ns` and `notice_process_ns`: construction duration, including the visible-facts digest and any option calculation. These exclude final notice serialization for metrics, filesystem writes, and prefix-copying.
- `options_wall_ns` and `options_process_ns`: duration of the isolated options mapping; both zero in the facts arm.
- `options_compute_calls`: zero in facts, one in facts-plus-options.

The audit reconstructs the notice, verifies source hashes, bytes, arm, algorithm and option-call count, and checks nonnegative timing types and sensible component nesting. It does not pretend to reproduce measured nanosecond durations. These small single-call measurements are instrumentation observations, not precise general performance estimates. They remain distinct from model usage, request latency and total episode duration; no monetary conversion is performed here.

## Offline verification

Tests were updated before implementation. Running the copied old implementation exposed the intended failures: old tasks/feedback, absent balanced allocation and scope checking, and the absent single-build/timing provenance behavior. After the minimal implementation changes, all 15 tests passed in about nine seconds.

Coverage includes exact administrative isolation, actual INSTANCE_MISMATCH reproduction, oracle-free presentation, identical paired factual messages, 24-cell balanced adjacency, hidden-version drift rejection, all selected rule trajectories matching across arms, single notice construction, metadata tamper detection, raw provider request and response/action replay, actual timeout/output allowance use through a mocked transport, no empty-output retry/fallback, and authentication/quota/unsupported-parameter stopping. All provider tests use an offline substituted transport; no model request was made by the worker.

Preparation, final code review, prior-batch protection verification, freeze creation and live collection are left to the parent task as assigned.
