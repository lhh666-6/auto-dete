"""Offline analysis contracts; synthetic files never contact a provider."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


HERE = Path(__file__).resolve().parent


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding='utf-8')


def cells(tasks=('FORMAL-G-003',), states=('valid',)):
    return [{'cell_id': f'{task}__{state}__{feedback}', 'task_instance_id': task,
             'authorization_state': state, 'feedback': feedback,
             'block_id': f'{task}__{state}', 'pair_id': f'{task}__{state}'}
            for task in tasks for state in states for feedback in ('facts', 'facts_plus_options')]


def row(cell, **overrides):
    return {**cell, 'controller': 'model', 'terminal': 'agent_final', 'U': True,
            'state_goal': True, 'I': 1, 'safe_stop': False, 'audit_errors': [], **overrides}


def episode(root, cell, tools=(), responses=(), failures=(), elapsed=5.0, controller='model'):
    directory = root / ('live' if controller == 'model' else 'rule') / cell['cell_id']
    save(directory / 'started.json', {'started_utc': '2026-10-14T01:00:00+00:00'})
    save(directory / 'outcome.json', {'terminal': 'agent_final', 'error': None,
        'global_stop': False, 'decisions': len(responses), 'elapsed_seconds': elapsed,
        'ended_utc': '2026-10-14T01:00:05+00:00'})
    save(directory / 'notice-build.json', {'notice_wall_ns': 20, 'notice_process_ns': 10,
        'options_wall_ns': 0, 'options_process_ns': 0, 'options_compute_calls': 0,
        'notice_utf8_bytes': 123})
    for index, (tool, status) in enumerate(tools):
        save(directory / 'steps' / f'{index:02}' / 'tool.json',
             {'tool': tool, 'result': {'status': status}})
    for index, response in enumerate(responses):
        save(directory / 'steps' / f'{index:02}' / 'attempt-0' / 'response.json', response)
        save(directory / 'steps' / f'{index:02}' / 'attempt-0' / 'request-meta.json', {'attempt': 0})
    for step, attempt, code in failures:
        save(directory / 'steps' / f'{step:02}' / f'attempt-{attempt}' / 'failure.json', {'code': code})
        save(directory / 'steps' / f'{step:02}' / f'attempt-{attempt}' / 'request-meta.json', {'attempt': attempt})
    return directory


class AnalysisContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = HERE / 'analysis.py'
        if not path.exists():
            return
        spec = importlib.util.spec_from_file_location('ablation_analysis_contract', path)
        cls.a = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.a)

    def setUp(self):
        self.assertTrue(hasattr(self, 'a'), 'Offline analysis implementation is not yet present')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_missing_arm_never_zero_filled_or_compared(self):
        plan = cells()
        episode(self.root, plan[1], tools=[('get_state', 'ok')])
        result = self.a.build_analysis(self.root, {'results': [row(plan[1])]}, {'cells': plan})
        pair = next(p for p in result['pairs'] if p['controller'] == 'model')
        self.assertEqual(pair['status'], 'incomplete')
        self.assertIsNone(pair['delta'])
        self.assertEqual(pair['missing_arms'], ['facts'])
        self.assertIsNone(next(c for c in result['cells'] if c['controller'] == 'model'
                               and c['feedback'] == 'facts')['costs'])

    def test_plus_minus_facts_and_rejected_reads_are_separate(self):
        plan = cells()
        episode(self.root, plan[0], [('commit', 'rejected'), ('get_state', 'ok'), ('commit', 'ok')], elapsed=5)
        episode(self.root, plan[1], [('get_state', 'ok')], elapsed=8)
        result = self.a.build_analysis(self.root, {'results': [row(plan[0]), row(plan[1], U=False,
            state_goal=False)]}, {'cells': plan})
        pair = next(p for p in result['pairs'] if p['controller'] == 'model')
        self.assertEqual(pair['status'], 'complete')
        self.assertEqual(pair['delta']['all_tool_calls'], -2)
        self.assertEqual(pair['delta']['rejected_calls'], -1)
        self.assertEqual(pair['delta']['get_state_reads'], 0)
        self.assertEqual(pair['delta']['elapsed_seconds'], 3)
        self.assertEqual(pair['delta']['safe_endpoint'], -1)
        self.assertFalse(pair['both_safe_endpoints'])

    def test_unavailable_safe_stop_counts_without_U_and_requires_integrity(self):
        plan = cells(states=('unavailable',))
        for c in plan:
            episode(self.root, c)
        result = self.a.build_analysis(self.root, {'results': [row(plan[0], U=False,
            safe_stop=True), row(plan[1], U=False, safe_stop=True, I=0)]}, {'cells': plan})
        observed = [c for c in result['cells'] if c['controller'] == 'model']
        self.assertTrue(observed[0]['safe_endpoint'])
        self.assertFalse(observed[1]['safe_endpoint'])

    def test_raw_usage_and_transport_failures_do_not_disappear(self):
        c = cells()[0]
        response = {'stop_reason': 'max_tokens', 'content': [{'type': 'thinking'}],
            'usage': {'input_tokens': 100, 'cache_read_input_tokens': 60,
                      'cache_creation_input_tokens': 20, 'output_tokens': 5000}}
        episode(self.root, c, [('request_authorization', 'rejected'), ('get_state', 'ok')],
                responses=[response], failures=[(0, 1, 'DEEPSEEK_TRANSPORT')])
        result = self.a.collect_cell(self.root, c, 'model', row(c))
        cost = result['costs']
        self.assertEqual(cost['input_tokens'], 100)
        self.assertEqual(cost['cache_read_input_tokens'], 60)
        self.assertEqual(cost['cache_creation_input_tokens'], 20)
        self.assertEqual(cost['output_tokens'], 5000)
        self.assertEqual(cost['requests'], 2)
        self.assertEqual(cost['retry_attempts'], 1)
        self.assertEqual(cost['responses_over_4096'], 1)
        self.assertEqual(cost['max_actual_output_tokens'], 5000)
        self.assertEqual(result['stop_reasons'], {'max_tokens': 1})
        self.assertEqual(result['failed_attempts_without_usage'], 1)
        self.assertEqual(result['transport_failure_codes'], {'DEEPSEEK_TRANSPORT': 1})
        self.assertEqual(cost['rejected_calls'], 1)
        self.assertEqual(cost['get_state_reads'], 1)

    def test_absent_usage_is_unknown_not_zero_and_rule_has_no_provider_usage(self):
        c = cells()[0]
        episode(self.root, c, responses=[{'stop_reason': 'end_turn', 'content': [], 'usage': {}}])
        result = self.a.collect_cell(self.root, c, 'model', row(c))
        self.assertIsNone(result['costs']['output_tokens'])
        self.assertEqual(result['usage_missing_responses']['output_tokens'], 1)
        episode(self.root, c, controller='simple_rule')
        rule = self.a.collect_cell(self.root, c, 'simple_rule', row(c, controller='simple_rule'))
        self.assertIsNone(rule['costs']['output_tokens'])

    def test_pre_live_groups_keep_planned_denominators_and_four_task_totals(self):
        plan = cells(tuple(f'FORMAL-G-{n:03}' for n in range(3, 7)), ('valid', 'revoked', 'unavailable'))
        result = self.a.build_analysis(self.root, {'results': []}, {'cells': plan})
        self.assertEqual(len(result['groups']), 4)
        self.assertTrue(all(g['planned_episodes'] == 12 and g['terminal_episodes'] == 0
                            for g in result['groups']))
        self.assertEqual(len(result['task_totals']), 8)
        self.assertTrue(all(g['planned_episodes'] == 6 for g in result['task_totals']))
        self.assertEqual(len(result['pairs']), 24)
        self.assertTrue(all(p['status'] == 'incomplete' and p['delta'] is None for p in result['pairs']))

    def test_notice_timing_and_timeline_preserve_raw_units(self):
        c = cells()[0]
        episode(self.root, c)
        result = self.a.collect_cell(self.root, c, 'model', row(c))
        self.assertEqual(result['costs']['notice_wall_ns'], 20)
        self.assertEqual(result['costs']['options_wall_ns'], 0)
        self.assertEqual(result['costs']['notice_utf8_bytes'], 123)
        self.assertEqual(result['timeline']['started_utc'], '2026-10-14T01:00:00+00:00')

    def test_partial_response_usage_is_not_a_complete_paired_token_difference(self):
        plan = cells()
        response = {'stop_reason': 'end_turn', 'content': [], 'usage': {'output_tokens': 100}}
        episode(self.root, plan[0], responses=[response, {'stop_reason': 'end_turn', 'content': [], 'usage': {}}])
        episode(self.root, plan[1], responses=[response])
        result = self.a.build_analysis(self.root, {'results': [row(c) for c in plan]}, {'cells': plan})
        pair = next(p for p in result['pairs'] if p['controller'] == 'model')
        self.assertIsNone(pair['delta']['output_tokens'])

    def test_pair_csv_preserves_metric_columns_before_any_collection(self):
        import csv
        result = self.a.build_analysis(self.root, {'results': []}, {'cells': cells()})
        destination = self.root / 'pairs.csv'
        self.a.write_pairs(destination, result['pairs'])
        with destination.open(encoding='utf-8-sig', newline='') as stream:
            reader = csv.DictReader(stream)
            records = list(reader)
            self.assertIn('delta_all_tool_calls', reader.fieldnames)
            self.assertIn('delta_output_tokens', reader.fieldnames)
        self.assertTrue(all(record['delta_all_tool_calls'] == '' for record in records))

    def test_protection_uses_repo_relative_paths_and_does_not_change_inputs(self):
        import hashlib
        target = self.root / 'old' / 'data.txt'
        target.parent.mkdir()
        target.write_text('unchanged', encoding='utf-8')
        original = target.read_bytes()
        manifest = self.root / 'protection.json'
        save(manifest, {'files': [{'path': 'old/data.txt', 'sha256': hashlib.sha256(original).hexdigest()},
                                 {'path': 'old/missing.txt', 'sha256': '0' * 64}]})
        result = self.a.check_protection(self.root, [manifest])
        self.assertFalse(result['all_unchanged'])
        self.assertEqual(result['files_checked'], 2)
        self.assertEqual(result['changes'][0]['path'], 'old/missing.txt')
        self.assertEqual(target.read_bytes(), original)


if __name__ == '__main__':
    unittest.main()
