# Recovery feedback: facts versus facts plus options

这是投稿后开展的一次独立探索性验证，不属于 KAIS 原冻结正式实验。详细设计、终点及解释边界见 [PROTOCOL.md](PROTOCOL.md)。

## 比较什么

4 个前两次 minipilot 未用过的 G 任务实例，3 个当前授权状态，2 种反馈，共 24 条模型轨迹，另有 24 条确定性规则对照。两组的权限事实相同，只有一组附带从这些可见事实生成的恢复路径标签。保留充足输出预算。

## 离线核查

使用 Python 3.11，从本目录运行：

```text
python -B test_pilot.py
python -B test_analysis.py
python -B analysis.py
```

这些命令不调用模型。分析读取当前目录原始记录，并核对冻结清单及原文件保护清单；不重跑或改写以前的两轮结果。运行依赖相邻 `../agent-policy-phase2-formal-2026-10-07/src/phase2/` 的既有冻结内核和独立评分器，依赖文件 hash 记录在 provenance.json 中。

## 文件入口

- `PROTOCOL.md`：真实采集前固定的问题、任务选择、比较条件与分析原则。
- `freeze.json`：协议、代码、分析程序、输入与分配的采集前 SHA-256。
- `allocation.json`、`preflight.json`：配对顺序、两组信息一致性和规则预检查。
- `live/`：模型请求正文、原始响应、逐步动作及最终状态；请求中不保存认证头。
- `rule/`：规则对照，与模型证据分开。
- `summary.json`、`results.csv`：独立重建与评分。
- `analysis.json`、`pairs.csv`：分组成本和逐对差值，缺失条目不补零。
- `protected-before.json`、`prior-batches-protection.json`、`protection-after.json`：原研究、投稿文件、前两轮数据的只读核对。
- `RESULTS.md`：采集完成后的结论及是否值得继续的判断。

## 真实采集

真实采集使用既有加密凭证，需要服务访问权限。`python -B pilot.py live` 在首次调用前验证冻结，并保留全部请求和结果。它会跳过已终止条目；遇到已开始但未终止的条目会停止供检查，不能据此宣称支持任意崩溃位置自动恢复。`prepare` 在冻结后拒绝运行。

本轮计划量到此为止；结果不自动并入论文或前两批分母。
