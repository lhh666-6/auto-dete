Agno continuation-route ablation (54 cells)
===========================================

Question: with the pause, reviewed objects and recorded arguments held fixed, does the
reviewed-argument sharing follow the Agno continuation entrypoint or the process
boundary?

Routes: live (original in-memory RunOutput, continue_run(run_response=...));
same_process (run reloaded by run_id, continue_run(run_id, session_id, requirements),
same process); fresh_process (run persisted, new interpreter, run_id + requirements).

Result: live 6/18 exact match; same_process 18/18; fresh_process 18/18. The mechanism
follows the continuation route and the state it continues from, not the process
boundary. One framework, one pinned version (Agno 3.1.10), constructed cells, no model
calls, no prevalence or novelty claim.

Contents: every file sealed by freeze.json, plus score-v1.json, REPORT.md, the seal
itself, collector batch logs and this README. Raw per-cell databases are retained in
the local study directory.

Rerun:  python -B runtime_checks.py
        python -B collect.py --concurrency 2 --limit 6
        python -B collect.py --concurrency 4
        python -B score.py --output outputs-v1 --report score-v1.json

The seal hashes installed SDK sources by absolute path, so on another machine either
reinstall Agno 3.1.10 at the recorded path or regenerate the seal with
`python freeze_study.py` before rerunning.
