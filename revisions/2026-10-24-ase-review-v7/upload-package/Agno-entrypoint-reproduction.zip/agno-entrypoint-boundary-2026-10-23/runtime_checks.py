from pathlib import Path
import copy
import os
import subprocess
import sys
import threading
import time
import psutil
from study_common import HERE, read, write, sha, now, create_effect_db, append_effect
from collect import supervise, artifact_hashes, verify_complete, clean_environment
from score import judge, expected_effects, score_case

def main():
    folder = HERE / ('runtime-checks-' + str(time.time_ns()))
    folder.mkdir()
    checks = []
    def run(label, program, expected, **limits):
        work = folder / label
        work.mkdir()
        script = work / 'fault.py'
        script.write_text(program, encoding='utf-8')
        stop = work / 'STOP'
        if label == 'global_stop':
            timer = threading.Timer(.4, lambda: write(stop, {'test': True}))
            timer.start()
        result = supervise([sys.executable, '-P', '-B', str(script)], work, 'fault', stop, **limits)
        if label == 'global_stop':
            timer.join()
        descendants_dead = all(not psutil.pid_exists(pid) for pid in result.get('observed_tree_pids', []))
        checks.append({'name': label, 'expected': expected, 'actual': result,
                       'descendants_dead': descendants_dead,
                       'pass': result['status'] == expected and descendants_dead})
    run('timeout_tree', "import subprocess,sys,time\np=subprocess.Popen([sys.executable,'-c','import time; time.sleep(20)'])\ntime.sleep(20)\n", 'timeout', timeout=.8)
    run('memory', "import time\nx=bytearray(120*1024*1024)\ntime.sleep(10)\n", 'memory_limit', memory_mib=60)
    run('log', "import time\nprint('x'*100000,flush=True)\ntime.sleep(10)\n", 'log_limit', log_bytes=1000)
    run('artifact', "from pathlib import Path\nimport time\nPath('big').write_bytes(b'x'*100000)\ntime.sleep(10)\n", 'artifact_limit', artifact_bytes=2000)
    run('disk_free', "import time\ntime.sleep(10)\n", 'disk_free_limit', minimum_free=10**18)
    run('global_stop', "import time\ntime.sleep(10)\n", 'global_stop')
    run('fast_exit_log', "print('x'*100000,flush=True)\n", 'log_limit', log_bytes=1000)
    run('fast_exit_artifact', "from pathlib import Path\nPath('big').write_bytes(b'x'*100000)\n", 'artifact_limit', artifact_bytes=2000)
    work = folder / 'resume'
    work.mkdir()
    case = {'id': 'test-resume'}
    write(work / 'case.json', case)
    write(work / 'complete.json', {'case_id': case['id'], 'freeze_sha256': 'fixture-freeze', 'artifacts': artifact_hashes(work)})
    checks.append({'name': 'validated_resume', 'pass': verify_complete(work, case, 'fixture-freeze')['case_id'] == case['id']})
    try:
        verify_complete(work, case, 'different-freeze')
        wrong_freeze_blocked = False
    except RuntimeError:
        wrong_freeze_blocked = True
    checks.append({'name': 'resume_wrong_freeze_refused', 'pass': wrong_freeze_blocked})
    (work / 'unexpected.txt').write_text('retained test mutation', encoding='utf-8')
    try:
        verify_complete(work, case, 'fixture-freeze')
        blocked = False
    except RuntimeError:
        blocked = True
    checks.append({'name': 'resume_tamper_refused', 'pass': blocked})
    sample = next(c for c in read(HERE / 'cases.json') if c['scenario'] == 'equal_second' and c['edit'] == 'false')
    correct = expected_effects(sample)
    checks.append({'name': 'oracle_correct', 'pass': judge(sample, correct)['effect_match']})
    for label, mutation in [('wrong_id', lambda x: x[0].update(call_id='other')),
                            ('bool_int', lambda x: x[1]['args'].update(enabled=0)),
                            ('dropped_field', lambda x: x[0]['args'].pop('ticket')),
                            ('duplicate', lambda x: x.append(copy.deepcopy(x[0]))),
                            ('other_call_changed', lambda x: x[0]['args'].update(enabled=False))]:
        altered = copy.deepcopy(correct)
        mutation(altered)
        judged = judge(sample, altered)
        checks.append({'name': 'oracle_' + label, 'pass': not judged['effect_match'] and not judged['role_match']})
    env = clean_environment(sys.executable, folder)
    checks.append({'name': 'credentials_not_forwarded',
                   'pass': not any(any(x in k.upper() for x in ['API_KEY', 'TOKEN', 'SECRET', 'PASSWORD']) for k in env)})
    claimed = folder / 'claimed-phase'
    claimed.mkdir()
    write(claimed / 'case.json', {'id': 'duplicate-claim', 'framework': 'must-never-import'})
    write(claimed / 'live.claim.json', {'prior_claim': True})
    refused = subprocess.run([sys.executable, '-P', '-B', str(HERE / 'worker.py'),
                              '--case-file', str(claimed / 'case.json'), '--out', str(claimed), '--phase', 'live'],
                             capture_output=True, text=True)
    checks.append({'name': 'worker_claim_refuses_before_effects',
                   'pass': refused.returncode == 3 and not (claimed / 'effects.sqlite').exists()
                           and not (claimed / 'live.json').exists()})
    valid = next(c for c in read(HERE / 'cases.json') if c['lifecycle'] == 'live')
    root = folder / 'score-status'
    dest = root / valid['id']
    dest.mkdir(parents=True)
    write(dest / 'case.json', valid)
    create_effect_db(dest)
    for row in expected_effects(valid):
        append_effect(dest, row['call_id'], row['args'])
    pending = [{'call_id': c['id'], 'name': 'record_delivery', 'args': c['original']} for c in valid['calls']]
    trace = {'pid': 12345, 'trace': {'pending': pending, 'native_status': 'completed', 'framework_errors': []}}
    write(dest / 'live.json', trace)
    write(dest / 'complete.json', {'status': 'timeout', 'artifacts': artifact_hashes(dest)})
    scored = score_case(valid, root)
    checks.append({'name': 'successful_effect_does_not_mask_timeout',
                   'pass': scored['classification'] == 'collection_timeout' and scored['effect_match']})
    trace['trace']['native_status'] = 'unsupported'
    write(dest / 'live.json', trace)
    write(dest / 'complete.json', {'status': 'collected', 'artifacts': artifact_hashes(dest)})
    checks.append({'name': 'unsupported_not_failure', 'pass': score_case(valid, root)['classification'] == 'unsupported'})
    # v1.1 pre-freeze amendment controls: the two new diagnostic categories must be
    # reachable and must take precedence over setup-mismatch / conformant classes.
    trace['trace'] = {'pending': [{'call_id': 'not-the-declared-id', 'name': 'record_delivery',
                                   'args': valid['calls'][0]['original']}],
                      'native_status': 'unexpected_pending',
                      'framework_errors': [{'type': 'PendingIdentityMismatch'}]}
    write(dest / 'live.json', trace)
    write(dest / 'complete.json', {'status': 'collected', 'artifacts': artifact_hashes(dest)})
    checks.append({'name': 'native_pending_identity_anomaly_reported',
                   'pass': score_case(valid, root)['classification'] == 'native_pending_identity_anomaly'})
    trace['trace'] = {'pending': pending, 'native_status': 'completed', 'framework_errors': [],
                      'effects_before_continue': 1}
    write(dest / 'live.json', trace)
    write(dest / 'complete.json', {'status': 'collected', 'artifacts': artifact_hashes(dest)})
    checks.append({'name': 'pre_review_effect_not_conformant',
                   'pass': score_case(valid, root)['classification'] == 'pre_review_effect'})
    report = {'utc': now(), 'checks': checks, 'passed': sum(c['pass'] for c in checks), 'total': len(checks)}
    write(folder / 'RESULT.json', report)
    write(HERE / 'runtime-checks-latest.json', {'path': str(folder / 'RESULT.json'), 'sha256': sha(folder / 'RESULT.json'),
                                             'passed': report['passed'], 'total': report['total']})
    print({'passed': report['passed'], 'total': report['total'], 'path': str(folder)})
    assert report['passed'] == report['total'], 'Runtime or oracle preflight failed'

if __name__ == '__main__':
    main()
