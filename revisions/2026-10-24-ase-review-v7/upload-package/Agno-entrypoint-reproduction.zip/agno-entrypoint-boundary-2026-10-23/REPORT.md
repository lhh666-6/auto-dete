# Agno continuation route versus process boundary: 54-cell addendum

Generated 2026-10-23 from the frozen addendum study (freeze
`f17ade246c0e92371874b9fc6373461f2f42ca1ff85ec9e0d2c8d95dd8076166`). Deterministic
scripted model; no model or paid calls; Agno 3.1.10 only.

## Question

The 504-cell study found that in Agno 3.1.10 the in-process continuation from the
original run object delivered one pending call's reviewed arguments to another pending
call, while the documented fresh-process route did not. That contrast bundled the
continuation entrypoint, in-memory object aliasing versus deserialized state, and the
process boundary. This addendum holds the pause, review objects and arguments fixed
and varies only the continuation route.

| Route | Continuation state | Process |
|---|---|---|
| `live` | original in-memory `RunOutput`, `continue_run(run_response=...)` | same |
| `same_process` | run reloaded by `run_id`, `continue_run(run_id, session_id, requirements)` | same |
| `fresh_process` | persisted run, new interpreter, `run_id` + `requirements` | new |

## Result

54 cells = 3 routes x 3 scenarios x 3 edits x 2 payload families (single call; two
equal originals with only the second edited; two distinct originals with both edited;
edits text, integer zero, boolean false; ASCII and Unicode families).

| Route | Cells | Exact effect match | Mismatch |
|---|---:|---:|---:|
| `live` (original run object) | 18 | 6 | 12 |
| `same_process` (run_id, same process) | 18 | 18 | 0 |
| `fresh_process` (run_id, new process) | 18 | 18 | 0 |

All 12 mismatches are multi-call `live` cells (equal-original and distinct-original
scenarios); the six `live` conformant cells are the single-call cells, where no
cross-call sharing can change the delivered payload. Native pending identity matched
in all 54 cells, no tool effect existed before a native continue step, and there were
no setup, unsupported, worker, collection or network anomalies.

## Decomposition

- `live` versus `same_process`: same process, same pause, different continuation
  entrypoint and object state. The mechanism appears only in `live`, so the cause lies
  in continuing from the original in-memory run object rather than from a run reloaded
  by identifier.
- `same_process` versus `fresh_process`: same entrypoint, different process and
  persistence. No difference, so the clean process boundary is not the cause.
- The reviewed-argument delivery therefore follows the **continuation route**, not the
  process boundary. This resolves the confound recorded in the 504-cell report; the
  earlier disclaimer that the difference "does not identify a restart effect" remains
  true but can now be stated positively.

## Claim boundary

One framework, one pinned version, constructed cells with a deterministic model, one
realization per cell: no prevalence, significance or framework-general claim, and no
novelty claim. The `live`-versus-`same_process` contrast still changes entrypoint and
object aliasing together; it is a two-contrast ablation, not a single-factor causal
isolation. Raw cell records and the frozen protocol are in the study directory;
`driver` scripts are the same frozen runner and scorer as the 504-cell study.
