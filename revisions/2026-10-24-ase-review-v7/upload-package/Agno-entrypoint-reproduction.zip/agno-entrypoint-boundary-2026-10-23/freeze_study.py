"""Freeze the Agno entrypoint addendum: cases, environment, SDK sources, controls."""
import subprocess
import json
from pathlib import Path
from study_common import HERE, read, write, sha, now
from collect import PYTHONS


def main():
    assert not (HERE / 'freeze.json').exists(), 'NO_OVERWRITE'
    checks = read(HERE / 'runtime-checks-latest.json')
    assert checks['passed'] == checks['total'] == 23
    assert sha(checks['path']) == checks['sha256']
    from generate_cases import generate, validate
    cases = read(HERE / 'cases.json')
    assert cases == generate() and len(cases) == 54
    assert all(validate(c) for c in cases)
    environment = {}
    command = ("import importlib.metadata as m,json,platform,sys; "
               "print(json.dumps({'python':sys.version,'platform':platform.platform(),"
               "'packages':dict(sorted((d.metadata['Name'],d.version) for d in m.distributions()))}))")
    for framework, python in PYTHONS.items():
        result = subprocess.run([str(python), '-P', '-B', '-c', command],
                                check=True, capture_output=True, text=True, encoding='utf-8')
        environment[framework] = {'executable': str(python), **json.loads(result.stdout)}
    write(HERE / 'environment.json', environment)
    sources = {}
    for item in read(HERE / 'adapter-notes/agno-source/manifest.json')['sdk_sources']:
        assert sha(item['path']) == item['sha256'], item['path']
        sources[item['path']] = {'path': item['path'], 'sha256': item['sha256']}
    files = [p for p in HERE.glob('*.py')] + [HERE / n for n in
              ['PROTOCOL.md', 'cases.json', 'environment.json', 'runtime-checks-latest.json']]
    files += list((HERE / 'adapters').glob('*.py'))
    files += [p for p in (HERE / 'adapter-notes').rglob('*')
              if p.is_file() and '__pycache__' not in p.parts]
    files += list(Path(checks['path']).parent.rglob('*'))
    files = sorted(set(p for p in files if p.is_file()))
    record = {'utc': now(), 'claim': 'controlled entrypoint/process decomposition, no novelty claim',
              'case_count': len(cases), 'paid_call_cap': 0,
              'files': {p.relative_to(HERE).as_posix(): sha(p) for p in files},
              'sdk_sources': list(sources.values())}
    write(HERE / 'freeze.json', record)
    print({'files': len(files), 'sdk_sources': len(sources), 'cases': len(cases),
           'freeze_sha256': sha(HERE / 'freeze.json')})


if __name__ == '__main__':
    main()
