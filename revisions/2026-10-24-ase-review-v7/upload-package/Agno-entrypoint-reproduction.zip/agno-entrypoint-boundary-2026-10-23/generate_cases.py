"""Deterministic matrix for the Agno entrypoint-versus-process-boundary addendum.

3 routes x 3 call scenarios x 3 review edits x 2 payload families = 54 cells.
"""
from copy import deepcopy
from itertools import product
from study_common import HERE, sha, write
import hashlib

ROUTES = ['live', 'same_process', 'fresh_process']
SCENARIOS = ['single', 'equal_second', 'distinct_both']
EDITS = ['text', 'zero', 'false']
FAMILIES = ['ascii', 'unicode']


def make_case(route, scenario, edit, family, prefix='main'):
    unicode = family == 'unicode'
    original = {'destination': '本地收件箱' if unicode else 'sink-A',
                'ticket': '票据-甲' if unicode else 'T-A',
                'note': '原建议\n"甲"' if unicode else 'proposed-A',
                'quantity': 7, 'enabled': True}
    count = 1 if scenario == 'single' else 2
    calls = []
    for i in range(count):
        args = deepcopy(original)
        if i and scenario == 'distinct_both':
            args.update(ticket='票据-乙' if unicode else 'T-B', quantity=11,
                        note='原建议乙' if unicode else 'proposed-B')
        target = scenario == 'single' or scenario.endswith('both') or (
            i == (1 if scenario.endswith('second') else 0))
        human = ('人工修改-' if unicode else 'reviewed-') + str(i)
        options = {'text': {'note': human}, 'zero': {'quantity': 0},
                   'false': {'enabled': False}}
        calls.append({'id': 'call-' + ('A' if i == 0 else 'B'),
                      'original': args, 'patch': options[edit] if target else {}})
    return {'id': '-'.join([prefix, 'agno', route, scenario, edit, family]),
            'framework': 'agno', 'lifecycle': route, 'scenario': scenario,
            'edit': edit, 'payload_family': family, 'calls': calls}


def generate():
    cases = [make_case(*x) for x in product(ROUTES, SCENARIOS, EDITS, FAMILIES)]
    return sorted(cases, key=lambda c: hashlib.sha256(
        ('agno-entrypoint-v1|' + c['id']).encode()).hexdigest())


def validate(case):
    schema = {'destination': str, 'ticket': str, 'note': str, 'quantity': int, 'enabled': bool}
    ids = [c['id'] for c in case['calls']]
    assert len(ids) == len(set(ids)) and 1 <= len(ids) <= 2
    for call in case['calls']:
        assert set(call['original']) == set(schema)
        assert set(call['patch']) <= set(schema)
        for key, value in {**call['original'], **call['patch']}.items():
            assert type(value) is schema[key], (case['id'], key)
    return True


if __name__ == '__main__':
    cases = generate()
    assert len(cases) == 54 and all(validate(c) for c in cases)
    assert not (HERE / 'freeze.json').exists(), 'Do not regenerate frozen cases'
    write(HERE / 'cases.json', cases)
    print({'main': len(cases), 'hash': sha(HERE / 'cases.json')})
