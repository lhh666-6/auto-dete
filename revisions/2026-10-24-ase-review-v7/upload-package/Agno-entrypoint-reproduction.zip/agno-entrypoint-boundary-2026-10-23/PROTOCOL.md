# Frozen protocol: Agno continuation entrypoint versus process boundary

Prepared 2026-10-23 Asia/Shanghai, before any collection of this addendum. Version 1.

## Question and claim boundary

The 504-cell study isolated a mechanism: in Agno 3.1.10 the in-process continuation
from the original run object delivered one pending call's reviewed arguments to
another pending call, while the documented fresh-process route did not. That
comparison bundled three differences: the recovery entrypoint, in-memory object
aliasing versus deserialized state, and the process boundary.

RQ: holding the native pause, review and argument objects fixed, does the difference
follow the **continuation entrypoint** or the **process/persistence boundary**?

Three routes, same reviewed inputs, same oracle:

| Route | Pause state used for continuation | Process |
|---|---|---|
| `live` | original in-memory `RunOutput` via `continue_run(run_response=...)` | same |
| `same_process` | run reloaded by `run_id` via `continue_run(run_id, session_id, requirements)` | same |
| `fresh_process` | run persisted, process exits, new interpreter reloads by `run_id` | new |

This is a controlled ablation of one premise of the earlier study. It makes no
novelty, prevalence or detection claim. The known public issue #8546 is calibration,
not a discovery target: if the mechanism follows the entrypoint, `same_process`
should reproduce it; if it follows object aliasing or persistence, it should not.

## Sampling and matrix

54 constructed cells = 3 routes x 3 call scenarios x 3 review edits x 2 payload
families. Scenarios: one call; two equal original argument objects with only the
second edited; two distinct original argument objects with both edited. Edits: text
replacement, integer zero, boolean false. Families: ASCII and Unicode/quoted/newline
text. Call IDs are always distinct and all calls use one declared local tool. All 54
candidates are retained; no result-based selection and no rerun-to-success.

## Native semantics and observer

Every route uses documented public Agno semantics: `run(session_id=...)`,
`get_run_output(run_id, session_id)` for reload, per-requirement
`provide_user_input` with the complete reviewed object, and `continue_run` with either
`run_response` or `run_id` + `requirements`. No SDK internals are mutated. The
deterministic scripted model emits the declared calls and terminates from persisted
message content. The actual tool body writes its runtime call ID and actual arguments
to case-local SQLite; a separate SDK-free scorer reads those rows read-only.

Primary outcome: exact multiset of (call ID, tool name, complete typed payload)
against the reviewed expectations. Pre-review effects (any effect before the native
continue call) are never conformant. Native pending identity must match the declared
proposal; differences are reported in their own category.

## Reporting

Report route x scenario x edit strata with all denominators, plus setup, unsupported,
error and collection categories. Three routes x one framework is not a sample of
frameworks; no significance test or confidence interval. The `same_process` route
still differs from `live` in object aliasing (reloaded objects versus the original
run object), so a `live`-versus-`same_process` difference identifies the entrypoint
plus aliasing, and `same_process`-versus-`fresh_process` identifies persistence and
process. Report that decomposition explicitly; do not collapse either contrast into a
single cause.

## Execution limits

Paid model calls 0; network disabled in the worker before adapter import; one
directory per cell; per-stage wall cap 60 s; process-tree RSS cap 768 MiB; artifact
cap 32 MiB; global STOP, exclusive phase claims and no automatic replay of started
cells; frozen hashes verified before and after collection. Developer preflight cells
stay outside the main denominator.
