"""Agno 3.1.10 three-route adapter: entrypoint versus process boundary.

Routes for the same native pause/review/continue flow:
  live          run(), keep the original RunOutput, continue_run(run_response=...)
  same_process  run(), reload the paused run by run_id in the SAME process,
                continue_run(run_id=..., session_id=..., requirements=...)
  prepare       run(), persist only, return (no tool execution)
  resume        NEW process: reload persisted run, continue with run_id + requirements

Only the continuation route differs between live and same_process; only the process
and persistence differ between same_process and resume. No expected value is written
to the effect store, and no model or network call is made.
"""
from contextvars import ContextVar
import hashlib
import json
from pathlib import Path

from study_common import append_effect, effect_rows

PHASES = ("live", "same_process", "prepare", "resume")


def _write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
                          encoding="utf-8")


def execute(case: dict, out: Path, phase: str) -> dict:
    from agno.agent import Agent
    from agno.db.json import JsonDb
    from agno.models.base import Model
    from agno.models.response import ModelResponse
    from agno.tools import FunctionCall, tool

    if phase not in PHASES:
        raise ValueError("Unsupported phase: " + phase)
    out = Path(out)
    expected_ids = [call["id"] for call in case["calls"]]
    if len(set(expected_ids)) != len(expected_ids):
        raise ValueError("The application must provide unique native call IDs")
    case_digest = hashlib.sha256(json.dumps(case, sort_keys=True, ensure_ascii=False)
                                 .encode()).hexdigest()
    runtime_call_id = ContextVar("agno_observed_call_id", default=None)

    class ScriptModel(Model):
        def __init__(self):
            super().__init__(id="offline-history-script", provider="local")

        def invoke(self, messages=None, *args, **kwargs):
            if any(getattr(message, "role", None) == "tool" for message in messages or []):
                return ModelResponse(role="assistant", content="done")
            return ModelResponse(role="assistant", tool_calls=[
                {"id": call["id"], "type": "function", "function": {
                    "name": "record_delivery",
                    "arguments": json.dumps(call["original"], ensure_ascii=False),
                }} for call in case["calls"]
            ])

        async def ainvoke(self, *args, **kwargs):
            return self.invoke(*args, **kwargs)

        def invoke_stream(self, *args, **kwargs):
            yield self.invoke(*args, **kwargs)

        async def ainvoke_stream(self, *args, **kwargs):
            yield self.invoke(*args, **kwargs)

        def _parse_provider_response(self, response, **kwargs):
            return response

        def _parse_provider_response_delta(self, response):
            return response

    def capture_id(fc: FunctionCall):
        runtime_call_id.set(fc.call_id)

    @tool(requires_user_input=True, pre_hook=capture_id)
    def record_delivery(destination: str, ticket: str, note: str, quantity: int,
                        enabled: bool) -> str:
        """Append only a local simulated delivery after human review."""
        call_id = runtime_call_id.get()
        if call_id is None:
            raise RuntimeError("Native FunctionCall identity was not observed")
        append_effect(out, call_id, {
            "destination": destination, "ticket": ticket, "note": note,
            "quantity": quantity, "enabled": enabled,
        })
        return "recorded"

    agent = Agent(id="agno-entrypoint-boundary", model=ScriptModel(),
                  tools=[record_delivery], db=JsonDb(db_path=str(out / "agno-db")),
                  telemetry=False)
    metadata_path = out / "agno-state.json"

    if phase == "resume":
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata["case_sha256"] != case_digest:
            raise ValueError("Prepared state belongs to a different input")
        if metadata["prepare_pid"] == __import__("os").getpid():
            raise ValueError("fresh resume must run in a different process")
        paused = agent.get_run_output(run_id=metadata["run_id"], session_id=metadata["session_id"])
        if paused is None or not paused.is_paused:
            raise RuntimeError("Expected a native paused RunOutput after reload")
    else:
        paused = agent.run("Review each proposed delivery before executing it.",
                           session_id=case["id"])
        metadata = {"run_id": paused.run_id, "session_id": case["id"],
                    "case_sha256": case_digest, "prepare_pid": __import__("os").getpid()}
        _write(metadata_path, metadata)
        if phase == "prepare":
            return {"phase": phase, "pending": _pending(paused), "decisions": [],
                    "native_status": str(paused.status), "framework_errors": [],
                    "metadata": metadata, "effects_before_continue": len(effect_rows(out))}
        if phase == "same_process":
            # Same process, documented run_id + requirements entrypoint.
            paused = agent.get_run_output(run_id=metadata["run_id"],
                                          session_id=metadata["session_id"])
            if paused is None or not paused.is_paused:
                raise RuntimeError("Expected a native paused RunOutput by run_id")

    result = {"phase": phase, "pending": _pending(paused), "decisions": [],
              "native_status": str(paused.status), "framework_errors": [],
              "metadata": metadata, "route": phase}
    actual_ids = [item["call_id"] for item in result["pending"]]
    identity_reason = None
    if len(actual_ids) != len(set(actual_ids)) or set(actual_ids) != set(expected_ids):
        identity_reason = "pending_ids_differ_from_proposal"
    elif any(item["name"] != "record_delivery" for item in result["pending"]):
        identity_reason = "pending_tool_name_differs"
    if identity_reason:
        result["native_status"] = "unexpected_pending"
        result["framework_errors"] = [{"type": "PendingIdentityMismatch",
                                       "reason": identity_reason,
                                       "expected_call_ids": expected_ids,
                                       "actual_call_ids": actual_ids}]
        return result

    by_id = {call["id"]: call for call in case["calls"]}
    for requirement in paused.active_requirements:
        call_id = requirement.tool_execution.tool_call_id
        call = by_id[call_id]
        full_args = dict(call["original"])
        full_args.update(call["patch"])
        field_names = [field.name for field in requirement.user_input_schema or []]
        if any(name not in full_args for name in field_names):
            raise ValueError("Complete reviewed object lacks a requested native field")
        requirement.provide_user_input({name: full_args[name] for name in field_names})
        result["decisions"].append({"call_id": call_id, "patch": dict(call["patch"]),
                                    "full_args": full_args})
    if not all(requirement.is_resolved() for requirement in paused.active_requirements):
        raise RuntimeError("Native requirements remain unresolved after complete valid input")

    result["effects_before_continue"] = len(effect_rows(out))
    if phase == "live":
        final = agent.continue_run(run_response=paused)
    else:
        final = agent.continue_run(run_id=metadata["run_id"], session_id=metadata["session_id"],
                                   requirements=paused.requirements)
    result["native_status"] = str(final.status)
    result["framework_errors"] = [
        {"call_id": execution.tool_call_id, "message": str(execution.result)}
        for execution in final.tools or [] if execution.tool_call_error
    ]
    result["remaining_pending"] = [
        {"call_id": requirement.tool_execution.tool_call_id,
         "name": requirement.tool_execution.tool_name}
        for requirement in final.active_requirements
        if requirement.tool_execution is not None
    ]
    return result


def _pending(paused):
    rows = []
    for requirement in paused.active_requirements:
        execution = requirement.tool_execution
        if execution is None:
            raise RuntimeError("Active requirement has no native tool execution")
        rows.append({"call_id": execution.tool_call_id, "name": execution.tool_name,
                     "args": dict(execution.tool_args or {})})
    return rows
