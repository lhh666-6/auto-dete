# v4 portable offline verification

This distribution repairs the earlier archive's omission of main per-cell raw outputs.
The original frozen experiment sources, cases, freeze.json and score-v1.json are unchanged.
There are 54 constructed cells and 42 exact matches. Experimental mismatches are
retained outcomes, not failures of artifact verification. This is one collection;
do not pool its cells with other studies as independent observations.

## Verify the distributed evidence

Extract the archive and run `python verify_offline.py` inside this directory with
Python 3.11 or later. Only the standard library is required. The verifier reads
SQLite in read-only mode, derives reviewed expectations from case originals plus
patches, compares typed per-call effect multisets, checks all completion/source/package
hashes, verifies recorded process and pending-call traces, and compares the results
with the archived scores. No SDK import, network access, model call or collector is used.
For a full optional NEW report: `python verify_offline.py --report readback.json`.
Missing/altered artifacts or score disagreements give a nonzero exit code.
The original SDK source hashes identify the environment used at collection time;
this portable route does not revalidate absolute SDK paths on another machine.
The package manifest is an integrity inventory, not a cryptographic signature.

## Recollect separately

The archived `score.py` and `collect.py` retain their original local environment
assumptions. Use the command above for portable offline verification, not those
scripts. Full recollection requires the pinned SDK versions in `environment.json`,
the recorded Windows worker controls and configured interpreter paths in a NEW
study directory. Do not run `freeze_study.py` over this sealed study: its
NO_OVERWRITE check is intentional. A new environment/runner requires its own freeze
and outputs and must not replace the original evidence. The original collector's
concurrency ladder and no-replay guards remain in its code; this packaging repair
does not claim to provide cross-platform recollection. No paid model calls were
used for these deterministic studies.

## Interpretation corrections

The 54-cell Agno ablation's original-object arm has 18 total cells: six single-call
matches and twelve multi-call mismatches. Entrypoint and object aliasing change
together; this is not single-factor isolation of aliasing.
In the 16-cell Pydantic check, loaded message history is changed in memory before
being supplied to continuation. The original on-disk history is not rewritten
after review. The replacement changes three fields: destination, note and quantity.
Eight override cells comprise six substitutions and two unchanged controls.
Client-supplied history is an application trust boundary, not a new SDK vulnerability.
These notes correct ambiguous prose in the preserved historical reports; original
records and freezes remain intact.
