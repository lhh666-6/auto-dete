from pathlib import Path
from collections import Counter, defaultdict
import argparse
import json
from study_common import HERE, read, write, effect_rows, sha, verify_freeze

def canonical(value):
    # JSON encodes bool and int differently, avoiding Python True == 1.
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))

def expected_effects(case):
    return [{'call_id': c['id'], 'name': 'record_delivery',
             'args': {**c['original'], **c['patch']}} for c in case['calls']]

def multiset(rows):
    return Counter(canonical(row) for row in rows)

def judge(case, actual):
    expected = expected_effects(case)
    baseline = multiset(actual) == multiset(expected)
    # Diagnostic partition; intentionally no claim of stronger detection.
    diagnostics = []
    for call in case['calls']:
        matches = [row for row in actual if row['call_id'] == call['id']]
        if len(matches) != 1:
            diagnostics.append({'call_id': call['id'], 'issue': 'effect_count', 'actual': len(matches)})
            continue
        row, desired = matches[0], {**call['original'], **call['patch']}
        if row.get('name') != 'record_delivery':
            diagnostics.append({'call_id': call['id'], 'issue': 'tool_name'})
        if set(row['args']) != set(desired):
            diagnostics.append({'call_id': call['id'], 'issue': 'field_set'})
        for key, value in desired.items():
            if key not in row['args'] or canonical(row['args'][key]) != canonical(value):
                diagnostics.append({'call_id': call['id'], 'issue': 'reviewed' if key in call['patch'] else 'preserved',
                                    'field': key, 'expected': value, 'actual': row['args'].get(key)})
    known = {c['id'] for c in case['calls']}
    if any(row['call_id'] not in known for row in actual):
        diagnostics.append({'issue': 'unexpected_call_id'})
    return {'effect_match': baseline, 'role_match': not diagnostics, 'diagnostics': diagnostics}

def score_case(case, root):
    out = root / case['id']
    result = {k: case[k] for k in ['id', 'framework', 'lifecycle', 'scenario', 'edit', 'payload_family']}
    if not (out / 'complete.json').exists():
        return {**result, 'classification': 'incomplete' if out.exists() else 'not_run'}
    terminal = read(out / 'complete.json')
    actual_hashes = {p.relative_to(out).as_posix(): sha(p) for p in sorted(out.rglob('*'))
                     if p.is_file() and p.name != 'complete.json'}
    if actual_hashes != terminal['artifacts']:
        return {**result, 'classification': 'artifact_drift'}
    phases = {'live': ['live'], 'same_process': ['same_process'],
              'fresh_process': ['prepare', 'resume']}[case['lifecycle']]
    records = {phase: read(out / (phase + '.json')) for phase in phases if (out / (phase + '.json')).exists()}
    errors = [r['error'] for r in records.values() if r.get('error')]
    native_errors = [e for r in records.values() for e in r.get('trace', {}).get('framework_errors', [])]
    # v1.1 pre-freeze amendment: two diagnostic categories are separated from setup errors.
    # Native pending identity differences are the phenomenon under study, not plumbing.
    native_statuses = {phase: r.get('trace', {}).get('native_status') for phase, r in records.items()}
    pre_review = {phase: r.get('trace', {}).get('effects_before_continue') for phase, r in records.items()}
    first = records.get(phases[0], {})
    pending = first.get('trace', {}).get('pending', [])
    planned = [{'call_id': c['id'], 'name': 'record_delivery', 'args': c['original']} for c in case['calls']]
    pending_matches = {phase: multiset(record.get('trace', {}).get('pending', [])) == multiset(planned)
                       for phase, record in records.items()}
    pending_match = len(records) == len(phases) and all(pending_matches.values())
    actual = effect_rows(out)
    verdict = judge(case, actual)
    result.update(verdict, expected=expected_effects(case), actual=actual, pending_match=pending_match,
                  pending_matches_by_phase=pending_matches,
                  errors=errors, framework_errors=native_errors, terminal_status=terminal['status'],
                  native_statuses=native_statuses, pre_review_effects_by_phase=pre_review,
                  network_attempts=sum(r.get('network_attempts', 0) for r in records.values()),
                  phase_pids={k: v['pid'] for k, v in records.items()})
    if case['lifecycle'] == 'fresh_process':
        result['separate_processes'] = (len(records) == 2 and records['prepare']['pid'] != records['resume']['pid'])
        result['prepare_zero_effects'] = first.get('effects_after_phase') == 0
    else:
        result['separate_processes'] = None
        result['prepare_zero_effects'] = None
    if result['network_attempts']:
        category = 'network_guard_violation'
    elif terminal['status'] != 'collected':
        category = 'collection_' + terminal['status']
    elif any(r.get('trace', {}).get('native_status') == 'unsupported' for r in records.values()):
        category = 'unsupported'
    elif any(status == 'unexpected_pending' for status in native_statuses.values()):
        # Separated from setup errors: a native pending-identity difference is a
        # phenomenon under study, retained with its own denominator.
        category = 'native_pending_identity_anomaly'
    elif not pending_match:
        category = 'setup_mismatch_or_error'
    elif any((value or 0) > 0 for value in pre_review.values()):
        # A tool effect already present before the native continue step means the
        # review step did not gate execution; never counted as conformant.
        category = 'pre_review_effect'
    elif len(records) != len(phases) or errors:
        category = 'execution_error'
    elif case['lifecycle'] == 'fresh_process' and not (result['separate_processes'] and result['prepare_zero_effects']):
        category = 'lifecycle_violation'
    elif verdict['effect_match']:
        category = 'conformant_with_native_error' if native_errors else 'conformant'
    else:
        category = 'effect_mismatch' if actual else 'no_effect'
    result['classification'] = category
    return result

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', default='outputs-v1')
    p.add_argument('--report', default='score-v1.json')
    a = p.parse_args()
    freeze = verify_freeze()
    rows = [score_case(c, HERE / a.output) for c in read(HERE / 'cases.json')]
    groups = defaultdict(Counter)
    for row in rows:
        groups[row['framework'] + '/' + row['lifecycle']][row['classification']] += 1
    report = {'freeze_sha256': freeze, 'cases': len(rows),
              'classifications': dict(Counter(r['classification'] for r in rows)),
              'groups': {k: dict(v) for k, v in groups.items()},
              'oracle_disagreements': sum(r.get('effect_match') != r.get('role_match') for r in rows),
              'network_attempts': sum(r.get('network_attempts', 0) for r in rows), 'paid_calls': 0,
              'rows': rows}
    write(HERE / a.report, report)
    print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, ensure_ascii=False))

if __name__ == '__main__':
    main()
