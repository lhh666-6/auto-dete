"""Retained Agno adapter preflight; four root-specified cells only."""
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
import hashlib

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT/'adapter-notes/agno-preflight-v1'
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    TARGET.mkdir(parents=True,exist_ok=False)
    cases=[c for c in json.loads((ROOT/'preflight-cases.json').read_text(encoding='utf-8')) if c['framework']=='agno']
    assert len(cases)==4
    write(TARGET/'input-manifest.json',{'utc':datetime.now(timezone.utc).isoformat(),
        'cases':cases,'files':{n:sha(ROOT/n) for n in ['adapters/agno.py','worker.py','study_common.py','preflight-cases.json']}})
    rows=[]
    for case in cases:
        out=TARGET/case['id']
        out.mkdir()
        case_file=out/'case.json'
        write(case_file,case)
        processes=[]
        for phase in (['live'] if case['lifecycle']=='live' else ['prepare','resume']):
            p=subprocess.run([sys.executable,'-P','-B',str(ROOT/'worker.py'),'--case-file',str(case_file),
                '--out',str(out),'--phase',phase],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60)
            proc={'phase':phase,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
            write(out/(phase+'-process.json'),proc)
            processes.append(proc)
            if p.returncode!=0: break
        with sqlite3.connect((out/'effects.sqlite').as_uri()+'?mode=ro',uri=True) as db:
            effects=[{'call_id':r[0],'name':r[1],'args':json.loads(r[2])}
                     for r in db.execute('SELECT call_id,tool_name,payload FROM effects ORDER BY seq')]
        expected=[{'call_id':c['id'],'name':'record_delivery','args':dict(c['original'],**c['patch'])} for c in case['calls']]
        normalize=lambda x: sorted((json.dumps(v,sort_keys=True,ensure_ascii=False) for v in x))
        traces=[json.loads((out/(p['phase']+'.json')).read_text()) for p in processes]
        row={'id':case['id'],'effects':effects,'expected':expected,'matches':normalize(effects)==normalize(expected),
             'phase_pids':{t['phase']:t['pid'] for t in traces},
             'phase_errors':{t['phase']:t.get('error') for t in traces},
             'phase_network_attempts':{t['phase']:t['network_attempts'] for t in traces},
             'prepare_effect_count':next((t.get('effects_after_phase') for t in traces if t['phase']=='prepare'),None)}
        rows.append(row)
        print(json.dumps(row,ensure_ascii=True),flush=True)
    write(TARGET/'readback.json',{'rows':rows,'total':len(rows),'matches':sum(r['matches'] for r in rows),
                                'consumer_main_cases_run':0})
if __name__=='__main__': main()

