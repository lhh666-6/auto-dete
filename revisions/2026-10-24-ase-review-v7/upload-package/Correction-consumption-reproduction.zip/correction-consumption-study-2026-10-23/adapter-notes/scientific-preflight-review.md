# 主实验科学语义预审（冻结前，只读）

日期：2026-10-23。检查对象为根线程编写的 `PROTOCOL.md`、`generate_cases.py`、`cases.json`、`score.py`，以及另一作者的 Agno 适配器与四格预检。审查者没有修改这些文件，没有运行任何新的 SDK 格、主实验、模型或网络。所做执行仅为标准库读取、现有 SQLite 的只读查询、确定性用例生成与纯内存判分检查。审查者曾实现本研究的 Pydantic 适配器，因此本报告不充当对该适配器的完全独立认证。

**当前结论：所发现的两个主判分门问题已由根线程在冻结前修复；本次范围内无剩余科学语义阻断。** 可按已授权的协议冻结并采集描述性结果。通过预审不意味着新颖性成立、方法优于基线，或主矩阵已运行。

## 1. 用例矩阵和观察单位

把生成器作为纯函数重新生成，与保存的 `cases.json` 逐项比较完全相同。共 504 个唯一 ID，所有参数与完整编辑后对象满足声明的严格 primitive 类型。三个框架分别有 live/fresh-process 各 84 格，确为 3×2×7×6×2 的构造矩阵。

未发现依赖预期 pass/fail 的 case-ID 分支。ID 只用于路径、框架路由、追踪和确定性排序。生成器根据明确的 call scenario、edit 和 payload family 构造输入；适配器的模型脚本从这些输入产生原生调用。这是人工规定空间内的自动用例生成，不是自动发现真实业务工作流或运行模型智能评估。

某些格有相同完整期望效果，例如同值确认中的 first/second/both 选择不会必然改变消费结果；两个调用都被改成同一最终值时，也可能看不出内部共享状态。这些格是显式控制和不同交互配置，不是独立缺陷或独立统计样本。协议已正确禁止把 504 格当作生态故障率或 iid 样本。ASCII/Unicode 的可观察差异也不应被计为不同根因。

## 2. 强基线与字段诊断使用相同信息

`expected_effects` 与 `judge` 都使用同一份 case 原始值、显式 patch、预期 call ID、同一工具名及同一实际 SQLite 记录。直接基线比较完整 `(call_id, name, args)` 多重集合，包含重复/多余/遗漏调用，并不省略身份或未改字段。角色/字段诊断只是把同一差异定位到字段，不能主张它有额外检测能力。

`canonical` 使用排序键的 JSON 序列化；本实验受限 primitive 域中，`true` 与 `1`、`false` 与 `0`、整数与浮点表示不会被 Python 的宽松等号混淆。多重集合允许合法执行顺序变化，同时仍要求一条效果对应一个声明调用。

纯内存核验覆盖每格的 11 类记录形态：正确、顺序重排、缺失、重复、额外未知调用 ID、错误 note、错误布尔类型、错误整数类型、错误工具名、缺字段、多字段。全部得到预期判断，两条 oracle 零分歧。这是 5,544 次纯判分一致性检查，**不是 5,544 个新研究样本或 SDK 执行**。

字段诊断中 `reviewed` 标签实际由 `key in patch` 判定。由于研究对每个调用提交的是完整被审阅对象，未在 patch 中出现的字段也并非“未经批准”。应在报告中把这个标签解释为“显式 patch 字段”，把 `preserved` 解释为“patch 之外应保留的字段”；尤其 `unchanged` 包含同值确认，不能把 patch membership 直接叫作数值发生改变。根线程决定保留内部标签并在说明中解释，不影响判分结果。

## 3. 已发现并在冻结前关闭的判分问题

### A. Collector 的中止状态原先未进入分类

首次读取的 `score_case` 保存了 `terminal_status`，但不据此分类。如果 worker 已经写完 phase 与正确效果、随后 collector 因资源限制或全局 stop 中止，原逻辑仍有可能归为 `conformant`，隐藏了有效采集门的失败。

根线程已加入 `terminal['status'] != 'collected'` 分支，分类为 `collection_<status>`。它位于正常效果分类之前；效果相等与字段诊断仍保留作为观察，不再自动使中止格成为有效通过。已只读确认这段更新。

### B. 明确 unsupported 原先会归入 setup mismatch

LangChain 适配器有显式 `native_status='unsupported'` 返回。旧 scorer 在这种情况下只看到空 pending，归入 `setup_mismatch_or_error`，不符合协议的 unsupported 单列约定。

根线程已加入独立 `unsupported` 分类，位于 pending/setup 判断之前。另已将原先只核验首阶段 pending 的逻辑扩展为逐阶段核验，保留 `pending_matches_by_phase`。因此 fresh-process 恢复出的待审批对象若与声明提议不同，不会仅因 prepare 阶段正确而被计为有效 correction-consumption 反例。上述修改在主冻结前完成，没有改写任何主结果。

本报告不重复另一审查者负责的超时、进程树、内存、磁盘、日志与停止机制审计，也没有重跑其 runtime fault checks。

## 4. Agno 四格预检：实际映射和效果复核

对 `agno-preflight-v1/input-manifest.json` 中列出的 adapter、worker、common、preflight-cases 哈希复核全部匹配。逐格以 SQLite `mode=ro&immutable=1` 直接读取实际效果；没有只转述 readback 汇总。四格的实际 native pending 全部与声明的调用 ID、工具名和原始参数匹配。

| Agno 预检 | 原生 pending 匹配 | 实际完整效果匹配 | 观察 |
|---|---|---|---|
| live，单调用 | 是 | 是 | call-A 收到自己的完整审阅值 |
| live，两个同参调用，只改 B | 是 | **否** | A、B 都收到 B 的 note/quantity/enabled |
| fresh process，单调用 | 是 | 是 | prepare 零效果；不同进程恢复 |
| fresh process，两个同参调用，只改 B | 是 | 是 | A 保留原值，B 收到修改值；prepare 零效果 |

失败格不是人为把 B 的输入交给 A。已读 decisions：A 的 `patch={}`，`full_args` 和 `supplied_user_input` 均为原值；B 才收到 `preflight-only`、quantity=3、enabled=False。适配器按每个实际 `requirement.tool_execution.tool_call_id` 查找应用输入，不按参数相等或列表位置猜测。真实工具体通过公开 FunctionCall pre-hook 观察 `call_id`，并通过 ContextVar 传给只记录实际参数的共享 writer；没有从期望对象反推 ID。SQLite 确有独立 A、B 两条行，因此不能归因为 scorer 丢失调用身份。

四格均没有 worker 异常、native tool error 或网络尝试。失败 live 格仍返回 native completed，这正是必须使用实际效果 oracle 的原因。两个 fresh 格分别记录不同 prepare/resume PID，并且 prepare 效果数为零；根线程驱动是真实进程创建，不是同进程重建对象的替代。

本设置使用 `requires_user_input=True` 且不指定 `user_input_fields`，使全部五个字段保留在模型 schema，并通过用户输入要求提供完整审阅值。该配置与之前隐藏部分模型字段的小试不同；当前 protocol 和 adapter notes 已披露，不能混成相同 API 处理。

## 5. 必须保持的先验与因果边界

已读取 `agno-source/official-issue-evidence.json` 中 [Agno #8546](https://github.com/agno-agi/agno/issues/8546) 的原始 issue 正文。该报告已经描述同一函数的多个 HITL 调用共享 `user_input_schema`，后一个调用写入的字段覆盖前者，单调用正常，并给出对应源码链和复现。当前 live 双调用结果与这一已知机制一致。

因此主矩阵若出现更多受影响字段、payload 或调用组合，应聚合为同一已知机制的当前版本复现/行为边界，不能按格增加“新 bug”数量。没有足够证据宣称首发现、维护者确认本次结果，或因搜索未找到修复就断言不存在修复。

Agno live 使用原始 `RunOutput` 的 `continue_run(run_response=paused)`；fresh 使用持久化加载后推荐的 `continue_run(run_id, session_id, requirements)`。两者同时改变了进程、序列化、对象别名结构和恢复入口。故当前 live 失败/fresh 正确只能称为**所测试两条 native 路径的描述性差异**，不能推出“进程重启修好了问题”“持久化必然更安全”或独立的 restart 因果效应。最新协议已明确这一混合处理限制。旧 getter-response 异常没有被重新放入 fresh 主基线。

预检已暴露这些形状；主矩阵是预先声明的扩展采集，不是完全未见、盲测发现集。原始 preflight 失败保留，未被修复成正常对照或从样本空间移除，这一做法符合协议。

## 6. 本次读取版本

| 文件 | SHA256 |
|---|---|
| `PROTOCOL.md` | `2154d737b19f2be07dfdc31b467999b3eb21e117e880fc7eb4f6e5c641d1fbf6` |
| `generate_cases.py` | `654f950de6c6315bf874de2485a3431f1bac244441e44a3b73bb5c7880b223e4` |
| 修复后的 `score.py` | `3c93a223f84e51c9cb3e4e2ebf8ad4ad58c78b004cfef5ef44f5b1d26faea764` |
| `cases.json` | `81c66d0e8c7a04966cdab6d0c33b7adc69921974c93c46c914d39a2f8911ce8a` |
| `agno-preflight-v1/readback.json` | `a1c81f7f8c3c1cc29081c7b607db06ef7e5074b2907ee40bc6c352d1e093dc47` |
| `agno-source/official-issue-evidence.json` | `b87d3361d510a21397c152ab058601c2e5f7aa29c689f06ea2920fc25628e625` |

采集后的报告应保留全部分层分母、collection/unsupported/setup/error 分类与正常控制；展示调用级效果反例，按机制去重，并明确完整效果相等基线与字段诊断的检测边界相同。实验规模本身不能替代方法贡献或论文新颖性的论证。
