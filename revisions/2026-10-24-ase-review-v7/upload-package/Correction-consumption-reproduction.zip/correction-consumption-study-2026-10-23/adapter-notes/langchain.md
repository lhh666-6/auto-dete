# LangChain adapter implementation and preflight

Date: 2026-10-23. Owned implementation: `adapters/langchain.py`, exporting
`execute(case, out, phase)` under `ADAPTER-CONTRACT.md`. This is manual adapter
engineering, not automatic source/contract extraction.

## Environment and source evidence

The existing read-only consumer environment was used without installs or SDK
edits: Python 3.11.9, LangChain 1.4.7, langchain-core 1.7.0, LangGraph 1.2.16,
langgraph-prebuilt 1.1.1, langgraph-checkpoint 4.3.0,
langgraph-checkpoint-sqlite 3.1.2. Interpreter:
`D:/Claude_Design/auto-decte-paper/research/innovation-round2-2026-10-23/consumer-probes/.venv/Scripts/python.exe`.

`source-evidence/langchain/manifest.json` contains the absolute installed paths,
SHA256 values, copied-source paths, complete Python/platform details, and public
documentation URLs. Nine relevant unchanged SDK source files were archived in
`source-evidence/langchain/snapshot/`. `official-docs.md` records primary API
evidence, source anchors, and the distinction between batched and per-call modes.

## Native mapping and actual observation

The deterministic model proposes every call in case order in a single AIMessage.
Each proposal carries its declared distinct call ID, even when two calls have
identical tool names and argument values. The real HumanInTheLoopMiddleware runs
with `interrupt_mode='per_call'`, and gates every `record_delivery` call.

The adapter reads `tool_call_id`, name and args from each actual native interrupt.
It records native enumeration order but does not assume that order corresponds to
proposal order. It matches the application review by tool_call_id and submits
`Command(resume={interrupt.id: Decision})`. Each Decision is an edit with a
complete original+patch argument object. An unmodified call also receives its
complete unchanged reviewed object. This follows the shared contract rather than
substituting an approve branch. It does not shuffle a positional API, use argument
equality to identify a call, or deduplicate equal calls. See the
[official per-call API](https://docs.langchain.com/oss/python/langchain/human-in-the-loop).

Every `record_delivery` parameter is required. The actual tool body sends its
received destination, ticket, note, quantity and enabled to shared
`append_effect`, together with the real `ToolRuntime.tool_call_id`. It never reads
expected values or invokes the scorer. Tool execution order may vary; effect
identity and payload must be scored by call ID/multiset, not insertion order.

## Lifecycle implementation

- `live`: builds a native graph and SqliteSaver, obtains native interrupts, and
  resumes the same graph inside the same connection context.
- `prepare`: obtains the pause and stores native SQLite state plus a small
  `langchain-session.json` record containing thread ID, case fingerprint,
  prepare PID, native pending objects and interrupt IDs. It returns from the
  SqliteSaver context so the connection closes. It supplies no decisions.
- `resume`: a separately launched worker reads that metadata, requires matching
  case input and a different process PID, opens the existing SQLite file, builds
  a new model and graph, and calls native `get_state` with the saved thread ID.
  It reads pending interrupts from checkpoint tasks, then submits decisions through
  the same public per-call resume API. It does not deserialize a Python graph,
  mutate checkpoint internals, or replay a user input to reconstruct the pause.

Model termination depends on persisted ToolMessage IDs. Once all proposed IDs
have tool messages it emits a final response. If invoked with a prior proposal
whose tool messages are still incomplete, it raises an explicit scripted-plan
diagnostic instead of issuing the proposal again. There is no instance counter,
provider client, or model API call. This controlled model excludes ordinary LLM
replanning from the experimental mechanism.

Returned traces contain actual pending objects, decisions, checkpoint references,
phase/PID, remaining interrupts, native tool errors, final messages and status.
Missing/duplicate/wrong native pending IDs are recorded as an unexpected-pending
framework diagnostic, not accepted as a valid test or silently mapped by position.

## Supported scope and limitations

The declared support is one or two same-turn calls to the single fixed tool, with
unique nonempty native IDs, primitive payload values and complete reviewed
str/str/str/int/bool fields. Only note, quantity and enabled can be patched. Both
equal and different original arguments are mapped by ID. Falsy values use normal
dictionary presence/update semantics, with strict input types before native use.

Other phases/lifecycles, call counts, duplicate IDs, undeclared fields, or invalid
complete payloads return `native_status='unsupported'` with a reason. The study
worker controls fresh-process launch, network denial and the effects database.
This adapter does not support or claim arbitrary pickled restoration, old
checkpoints, caller-supplied serialized graphs, multiple review rounds, dynamic
tool registries, cross-tool edits, concurrent resumers, crash-in-the-middle
exactly-once effects, or unrelated middleware configurations. The existence of
native parallel tool execution does not imply batch atomicity.

## Preserved preflight, before main freeze

Only the four root-provided LangChain preflight cases were executed. The main
504-case matrix was not run by this agent. Evidence is retained under
`adapter-notes/langchain-preflight-v1/`, including each complete case.json,
prepare/live/resume worker records, separate subprocess stdout/stderr/returncode,
native checkpoints, raw SQLite effects, adapter snapshot, and manifest/hash.

| Preflight | Worker phases | Prepare effects | Final effects | Actual call-ID/payload equality |
|---|---|---:|---:|---|
| live, one call | live | n/a | 1 | pass |
| live, two initially equal calls, edit second | live | n/a | 2 | pass |
| fresh process, one call | prepare then resume | 0 | 1 | pass |
| fresh process, two initially equal calls, edit second | prepare then resume | 0 | 2 | pass |

Fresh-process PID pairs were 61376→40284 and 53056→49872. All six worker
invocations returned code 0; both prepare phases were paused with zero effects;
all four completed phases reported completed without tool errors. Network
attempts recorded by the root guard were zero throughout. The shared actual
effects were independently read with standard-library SQLite in read-only mode
and compared by call ID and typed JSON to the application-provided input. The
first of each equal pair retained its original arguments while only the second
received its patch.

These four checks validate the adapter lifecycle and equal-argument identity
handling before freezing. They do not establish main-matrix outcomes, new bugs,
method superiority, or production safety. No failed preflight was overwritten,
and no adapter repair was required after these four checks.
