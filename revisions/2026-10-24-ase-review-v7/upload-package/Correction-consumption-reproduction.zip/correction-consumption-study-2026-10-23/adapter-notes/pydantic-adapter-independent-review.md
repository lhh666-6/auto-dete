# Independent semantic review: Pydantic AI adapter (pre-freeze)

**Independence statement.** I did not write this adapter and did not execute any SDK. I am independent of the author thread that produced `adapters/pydantic_ai.py` and `adapter-notes/pydantic_ai.md`; this review is read-only text inspection (PowerShell Get-Content/Select-String/Get-FileHash). I did not import `pydantic_ai`, run Python on the venv, run pytest, install anything, or use the network. The SDK is `pydantic-ai-slim` 2.60.0 (`pydantic_ai_slim-2.60.0.dist-info/METADATA` lines 2-3); installed source text was read, never executed.

**Reviewed artifact and time.** `adapters/pydantic_ai.py` SHA-256 `889743e7dd5a8738432552ddf4a6940a766d91db47cff765a67680165919c81f` (v1.1, 201 lines, 9998 bytes), hashes captured 2026-10-23T23:30:19+08:00. The study was being edited concurrently while I read it; this review certifies only the hashes listed at the end. Any later edit to any listed file voids it.

## Verdict

No adapter misuse was found: the adapter uses the installed SDK's public deferred-approval semantics for pausing (`requires_approval=True` plus `output_type=[str, DeferredToolRequests]`), reviewing (`ToolApproved(override_args=<complete object>)`, whose documented meaning is replacement, not partial merge), result construction (`DeferredToolRequests.build_results(approvals=...)`, which also validates that every key is a pending approval ID), persistence/reload (native `ModelMessagesTypeAdapter` for history; a public-dataclass `TypeAdapter(DeferredToolRequests)` for request kind), and continuation (`run_sync(message_history=..., deferred_tool_results=...)`), with approval keys drawn from the actual native pending `tool_call_id`s and no positional or content-based reassignment. The app-side `original + patch` merge is executed by the adapter as the study requires, and the tool body records only its validated received arguments and runtime call ID; no expected effect is written into `effects.sqlite`. **Verdict: native semantics, non-blocking.** The single caveat is that request-kind persistence uses a bare Pydantic `TypeAdapter` rather than the SDK-documented `ConversationTypeAdapter`, which is version-fragile but verified for the pinned version by the preflight round-trip. The retained preflight artifacts were produced by the previous file revision and worker, so the notes' quoted adapter hash must be annotated or the four cells re-run before the preflight is cited as certification of the current file.

## A. Native-path correctness — documented semantics

| # | Adapter use (current file) | SDK / documentation evidence | Assessment |
|---|---|---|---|
| A-i | Pause: `@agent.tool(requires_approval=True)` (101); `Agent(FunctionModel(script), output_type=[str, DeferredToolRequests])` (99); `paused.output` typed as `DeferredToolRequests` (160-165) | `agent/__init__.py:2949` (`requires_approval` parameter); deferred-tools doc lines 25, 97, 110; pause output built at `_tool_execution.py:1056-1083, 1105-1109, 1173-1180` (raises `UserError` if `DeferredToolRequests` is absent) | Documented public path; correct |
| A-ii | Approve: `ToolApproved(override_args=full_args)` with complete object, lines 127-128 | `_deferred.py:105-113` (`override_args` = "arguments to use instead of the original"); enforcement `_tool_execution.py:704-718` (and `tool_manager.py:1543-1554`): `replace(call, args=override_args)` then revalidate; deferred-tools doc line 112 | Replacement semantics understood and used correctly; no partial-merge reliance |
| A-iii | Build results: `requests.build_results(approvals=approvals)` keyed by native pending IDs, lines 119-131 | `_deferred.py:47-89` (`approvals` Mapping keyed by `tool_call_id`; raises on IDs outside `self.approvals`); deferred-tools doc lines 33, 538 | Documented; ID validation adds a native-set cross-check |
| A-iv | Persist/reload: `ModelMessagesTypeAdapter.dump_json/validate_json` (79-82, 150-151, 171) and `TypeAdapter(DeferredToolRequests)` (30, 152-153, 172) | `messages.py:4398-4401` (public documented adapter); `_deferred.py:29-45` (public dataclass); SDK-documented persistence container is `Conversation`/`ConversationTypeAdapter` (`conversation.py:93, 108`; deferred-tools doc lines 489-533) | History: documented. Request-kind: public but **undocumented route** (bare TypeAdapter instead of `ConversationTypeAdapter`); version-fragile, not private. Non-blocking (pinned version round-trip verified in preflight) |
| A-v | Continue: `agent.run_sync(message_history=history, deferred_tool_results=results)` (190) | `agent/abstract.py:749-775` (keyword `deferred_tool_results`); deferred-tools doc lines 112, 415 (resume with history + results, no new prompt); `_agent_graph.py:805-857`; per-call ID lookup `_tool_execution.py:686-702, 911-915`; `ctx.tool_call_id` built at `tool_manager.py:568-593` | Documented; results are matched to calls by `tool_call_id`, not order |

## B. Adapter-misuse risks (could manufacture false mismatch / false conformance)

| # | Risk | Evidence and finding |
|---|---|---|
| B1 | `override_args` treated as a patch | No misuse: app merges `{**original, **patch}` at 127 and passes a complete five-field object; SDK replaces all args (`_deferred.py:109-110`; `_tool_execution.py:715-718`). Correct per contract. |
| B2 | Type coercion / argument round-trip | Override args are re-validated by Pydantic (`_tool_execution.py:704-718`; `tool_manager.py:595-624`), so the body receives post-validation values. The generated matrix asserts exact primitive types for every field (`generate_cases.py:46-55`), and the scorer canonicalises JSON so `True` ≠ `1` (`score.py:7-9,33-36`). No false mismatch is possible for the 504 cells; a wrong-typed non-matrix patch would be coerced and reported as mismatch (limit, not a matrix risk). |
| B3 | Call-id mapping positional/ordered | Native IDs only: pending rows from `requests.approvals` (`tool_call_id`, lines 58-66); approvals keyed by those IDs (113-131); tool body records `ctx.tool_call_id` (105), populated from the call part (`tool_manager.py:587`). SDK matching is by ID (`_tool_execution.py:678-687, 911-915, 1096-1103`). Unique-ID / set-equality guards fail closed (adapter 64-65, 115-118; SDK 682-685, 1098-1103). No positional or content-based inference. |
| B4 | Tool body receiving not-exactly the reviewed object | Body signature has exactly the five reviewed fields (101-103) and records only its five received parameters plus runtime ID (105-107). `full_args` has exactly five keys; validation can coerce (B2) but cannot add fields. The observed object is therefore the reviewed object modulo validation. |
| B5 | Expected value/effect leakage | `append_effect` receives only actual received values and the runtime ID (105-107; `study_common.py:29-33`); it never reads the case. Patch/expected values exist only in the trace/decision files (129-130), and the scorer reads only `effects.sqlite` plus `pending` (`score.py:60-68`). The scripted model does propose `case['original']` (94-97), but that is the study's model proposal, not the expected post-review effect; the expected effect (`original+patch`) is computed independently in `score.py:11-13`. No leak into the measured effect. |
| B6 | FunctionModel re-proposes or skips calls | Script has no call counter and terminates on persisted history content ("any prior `ToolCallPart`" → text, 86-97). Resume evidence: only one `finish` event carrying the persisted IDs (`pydantic_ai-resume-model-events.json`; readback lines 154-161). If the persisted history lacked the calls, the SDK raises on supplied deferred results (`_agent_graph.py:805-857`) or on unprocessed calls (`:772-779`) rather than silently executing; duplicate IDs are rejected (`_tool_execution.py:682-685`). The "any prior call" heuristic is coarse but safe for these single-turn, one-batch cases. |
| B7 | `prepare` executing a tool body | `prepare` returns at 170-180 after pausing, before `_decisions`/continuation; `requires_approval` means the pause cannot execute. Preflight `prepare.json` records `effects_before_phase`/`effects_after_phase` = 0, and the scorer requires `prepare_zero_effects` (`score.py:74-76,98`). Cannot execute. |
| B8 | Live vs resume differing beyond process/serialization | Same `_make_agent` (99-101), same `_decisions` (113-131), same `run_sync` call (160, 190); only the source of history/requests (in-memory 160-162 vs TypeAdapter 150-153), the PID/digest guards (144-149), and trace fields differ. Contract-compliant (`ADAPTER-CONTRACT.md:7-10`). |
| B9 | Same-value "unchanged" cells masking override loss | For a patch equal to the original the recorded effect is identical whether or not the SDK applied `override_args` (`generate_cases.py:27-30`); those cells are inert for override application by construction. The other edit strata (text/zero/false/empty/multiple) detect override loss. Not a false-conformance mechanism for the matrix, but the report must not claim "unchanged" cells test override application. |
| B10 | Effects existing before the native continue step | v1.1 records `effects_before_continue` immediately before `run_sync` (187-189, 197) and the scorer never classifies such a cell conformant (`score.py:92-95`). This is anti-false-conformance plumbing and does not depend on the tool body. |

## C. The three claims the study will rely on

| Claim | Does the adapter actually test it? | Bearing / limit |
|---|---|---|
| C1. Reviewed complete objects reach the intended pending call ID | Yes. Native pending IDs are enumerated (58-66), approvals are keyed by those IDs (113-131), the tool body records the runtime `ctx.tool_call_id` and validated args (105-107), and the independent scorer requires one effect per call ID with exact payload (`score.py:18-40,60-68`). Preflight `fresh_process/equal_second` shows A unmodified and B patched under IDs `call-A`/`call-B`. | The adapter supplies the observable; correctness is judged by the external scorer (by design). Preflight evidence is from file revision 095a4408 (see D6). |
| C2. Unchanged fields are preserved | Partly. Because `override_args` fully replaces and the app supplies all five fields, the SDK has nothing to preserve: the test observes intact transmission of a complete object (including fields equal to the original), which the scorer labels `preserved` for non-patch keys (`score.py:35`). It cannot and does not test SDK preservation of *unspecified* fields. | This matches PROTOCOL 59-61 ("app-side merge is credited to the application"); the final report must phrase Pydantic AI's contribution as transmission fidelity of the complete reviewed object, not SDK partial-merge preservation. |
| C3. Fresh-process resume via documented native serialization yields the same per-call association | Yes for association: `resume` is a separate PID (144-149), reloads history via `ModelMessagesTypeAdapter.validate_json` (150-151), reloads request kind via `TypeAdapter(DeferredToolRequests)` (152-153), re-keys approvals by reconstructed native IDs (113-131), and continues natively (190); preflight v1.0 equal-content cells record two effects with A original and B patched and only a `finish` model event. | "Documented native serialization" is fully true only for message history. Request-kind persistence is a public-dataclass/Pydantic-adapter composition, not the SDK-documented `ConversationTypeAdapter` route (deferred-tools docs 489-533); disclosed as version-fragile. |

## D. Residual risks / limits the final report must disclose

1. **C2 is app merge, not SDK preservation.** PROTOCOL 59-61 and adapter lines 125-127 already attribute the merge to the application; the report must not present Pydantic AI as preserving unchanged fields.
2. **Pinned version only.** 2.60.0 is enforced at 137-138 (dist-info metadata confirms 2.60.0). The bare `TypeAdapter(DeferredToolRequests)` persistence (30, 152-153, 172) is not a documented persistence API; the documented route is `ConversationTypeAdapter` (`conversation.py:108`). No cross-version compatibility is claimed.
3. **Scripted model, no real LLM/provider path.** `FunctionModel` is a documented local test model (`testing.md:207-271`; `models/function.py:323-337`), proposals are copied from the case, and termination is the coarse "any prior `ToolCallPart`" rule (86-97). Retries, re-proposals, streaming, provider argument normalisation and real model variability are untested. `models.ALLOW_MODEL_REQUESTS = False` (28; `models/__init__.py:2113,2149-2150`) plus the worker socket guard (`worker.py:48-59`) means no provider HTTP path is exercised; `paid_calls = 0`.
4. **Approval is not authorization.** The SDK documents client-submitted approval as data, not an authorization boundary (deferred-tools doc lines 107-108); resume trusts persisted history/requests and a case-digest guard (144-149), not authenticated state. No cross-principal, tamper, hostile-history or tool-name-rebinding claim is supported.
5. **Clean process boundary only.** Prepare exits normally and a fresh worker resumes; no crash during a partially committed effect, no exactly-once or transactional guarantee. The same-PID equality check (148-149) is a sanity guard, not an isolation proof (adapter notes line 40).
6. **Preflight provenance mismatch.** `pydantic-preflight-v1/preflight-freeze.json` records adapter `095a4408…` and worker `2c4e9b6e…`; the current files are adapter `889743e7…` (v1.1) and worker `44c4097e…`. PROTOCOL 128-148 discloses the v1.1 diagnostic-only amendment covering all three adapters, and my comparison of the file I saw before the amendment with the current one shows the native calls (`_make_agent`, `_decisions`, pause, TypeAdapters, `run_sync`) are unchanged and all added code is `NativeIdentityError`/`effects_before_continue` plumbing. Still, `adapter-notes/pydantic_ai.md` line 54 asserts the preflight-time hash `095a44…` as "the adapter SHA256" and should be annotated with the v1.1 hash, or the four preflight cells re-run with current hashes, before the preflight is cited as certification of the current file.
7. **Identity anomalies are their own class.** Under v1.1, a pending-ID/multiplicity/tool-name difference is `native_pending_identity_anomaly`, explicitly not a correction-consumption counterexample (PROTOCOL 137-142; `score.py:86-89`); the report must not merge that class with `effect_mismatch`.
8. **Dry-run report artifact.** The study root contains `REPORT.md` built from `fake-score.json` with a placeholder freeze hash (its line 3) and 2 fabricated scored rows; it must never be cited as an empirical result. Main outcomes remain uncollected.

## SHA-256 of every file reviewed (Get-FileHash, 2026-10-23T23:30+08:00; study-root-relative unless `SDK:`)

| File | SHA-256 |
|---|---|
| `adapters/pydantic_ai.py` (review target, v1.1) | `889743e7dd5a8738432552ddf4a6940a766d91db47cff765a67680165919c81f` |
| `study_common.py` | `8b4a21ab8996b0ea81aadb32dbd5d7cd52f32382420b631335cd3834f52790f9` |
| `score.py` (v1.1) | `e61575768ceb95879b46011dfd49a48c1f1c26dfb8e9e28e3f3b8d3d25c46701` |
| `ADAPTER-CONTRACT.md` | `59a302042042a9ee8c1e786abf47cfbd5e32af65339495b5cdba3a04c49ab682` |
| `PROTOCOL.md` (incl. v1.1 amendment) | `cb15a1e4d8c95af4ba7b6cfe7fe542df7cf9dda2a83ca32a713be129ccb96dc2` |
| `worker.py` | `44c4097ed2a746e95a65ecdbd83d6e6b6a33b1e23f7fc44bc7bd920215d4a475` |
| `generate_cases.py` | `654f950de6c6315bf874de2485a3431f1bac244441e44a3b73bb5c7880b223e4` |
| `freeze_study.py` (context) | `72664ecce864aa9a320af996fb40504c9b905f04d16d2e5a4f4d751b2f704522` |
| `REPORT.md` (dry run; context) | `423d9341f25ebd831d048d93e5ee50e7c06eb6244fbfb0a9b996fc4b4b380fb4` |
| `progress.md` (context) | `b810b291fc806578123da9c22e56dcbd7d9eb5a244781d0456f8186d56d02281` |
| `findings.md` (context) | `342549bf7aebf6b6896a8c5b12d0e2d0f64ee8e4e99b0b95b988f804ed3adb88` |
| `task_plan.md` (context) | `017882e615c6b5340e5d9fc19fa619d425158b0b64de5f9758646ddd9c1d632a` |
| `runtime-checks-latest.json` (context) | `5dd11e823823d231aaede7dc7be3b9e5a7e57cf7d8444b0b63efbccfd110ecf4` |
| `adapters/agno.py` (context, grep-checked) | `dc5af6866778f459f32d3c2bc384213aac97a9ce77c57c556a9ca51135371416` |
| `adapters/langchain.py` (context, grep-checked) | `84ba35b9444068dd83f9a5fdc89613fd885a005589e051c1c4f0ce57c58d5f54` |
| `adapter-notes/pydantic_ai.md` | `1f5551904dbb84e020e0759ec9a3bd3d553e45544d80da4c92087b5c8ec93ca3` |
| `adapter-notes/pydantic_ai-sources/manifest.json` | `f6fb5300ff23955dd070b381c9dd8d8fe98217e6b1b28b333348ecb17d8c13f2` |
| `adapter-notes/pydantic_ai-sources/deferred-tools.md` | `dcff013c51ef86eaf3db6676e24c73d4035d10f37535c3f4b2a478a1cd3f4346` |
| `adapter-notes/pydantic_ai-sources/testing.md` | `dd89261817e1a5b9da79f89446a3bd8a1e72d2f690574d6d7a28428e72ea7971` |
| `adapter-notes/pydantic_ai-sources/sdk/messages.py` (= `SDK:pydantic_ai/messages.py`) | `c9d7c2b650d952e8af6c79c37d447b656e6bf4296d77b607c700a24cd886cca5` |
| `adapter-notes/pydantic_ai-sources/sdk/tool_manager.py` (= SDK) | `4ef5522d925f1a50397e18b3c18c43f7e833cc5f143fe78e4ef0e3d7f7a602c1` |
| `adapter-notes/pydantic_ai-sources/sdk/_agent_graph.py` (= SDK) | `ecb9ed87edb61087b28e0b8880d593a3e84fcc157944c70dfc983078b882424b` |
| `adapter-notes/pydantic_ai-sources/sdk/_deferred.py` (= SDK) | `a29fcc7769b2b19b4ed175b275deaeaf1ec113a3faaae1eaec1cc199eefabbbb` |
| `adapter-notes/pydantic_ai-sources/sdk/_run_context.py` (= SDK) | `91afbba089b52873b88ae63e60f7c5d4d90f8de590e2d0e13d593d94baeea3c3` |
| `adapter-notes/pydantic_ai-sources/sdk/models/function.py` (= SDK) | `658465a94e067da2f8125487c7a3980da69b364465eb9839092d557f2fd47ed0` |
| `adapter-notes/pydantic-preflight-v1/preflight-freeze.json` | `147727ba9cfc89206a82a816c21fbaba96f1558f48693dac7c6ddde660ec6dc8` |
| `adapter-notes/pydantic-preflight-v1/preflight-readback.json` | `b650394ee26490b527025d55555eb885717842b897c387bdfaa1aca0067d0317` |
| `adapter-notes/pydantic-preflight-v1/driver-results.json` | `8431e79ba112c9dad8ced0bd4971bb61615943978597aa4fa21a460cb256e7f4` |
| `…/fresh_process-equal_second-multiple-ascii/prepare.json` | `f7460e0a6e3d3d027c6ed2c6ef572562ff7d277dbc34939519a9a318ba98cdf1` |
| `…/fresh_process-equal_second-multiple-ascii/resume.json` | `a55ec644eba690830cd28bb0e6f1a401a65db217337dfe2d59539a5905d9ce3b` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-prepare-requests.json` | `a5d79914a02e9123b5b054d70b7211cd5c5c59e31fa075f6a64008ae8f268fa0` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-resume-loaded-pending.json` | `a1acc0e1177881f3147656ae94ff78e7ada24a757b722ca01110181ba6d46428` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-resume-decisions.json` | `724efe66e665c785461fa93f89212b3d9d5a2d4a9d15a2319516481987f69ecd` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-prepare-model-events.json` | `7fc36444b1b3122a525545de43327f39d3596ae72bb5a4c4af65585594dd07d8` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-resume-model-events.json` | `eb6261b7b194e480ee14928a11213c5036739cf46387dd8c41a844b5713c7957` |
| `…/fresh_process-equal_second-multiple-ascii/pydantic_ai-prepare-metadata.json` | `30eadc00a1fc0e32fee8664e7102ed1206e37b7534757d2d21b138505c5781a4` |
| `SDK:pydantic_ai/__init__.py` | `f1aa68b34f3f35a9eda49074dd5b3fd3f69ff6d7a430f89af95778dc00cf7c1d` |
| `SDK:pydantic_ai/agent/__init__.py` | `4ef92174a476bfececbfdb8be84dfce15370bee785dfd05f5c85907c330abf68` |
| `SDK:pydantic_ai/agent/abstract.py` | `9385e9877ac6c365cd6fc3faea05cd54ecdf0525f6a1d41750a4f0f8192a7a5e` |
| `SDK:pydantic_ai/_tool_execution.py` | `69aad18b4ad92f652fd1cdce49b1e737a521bee9926d03f1724272544c5d289e` |
| `SDK:pydantic_ai/conversation.py` | `4184e00efb1f36698c6c9890cad2d1e38b719b5e97119c351ab09c5452a8fd99` |
| `SDK:pydantic_ai/models/__init__.py` | `db92d8ce8cdfcdf9029202ace12f189682a63745fd27f32623e46d15bd9b0fa9` |
| `SDK:pydantic_ai_slim-2.60.0.dist-info/METADATA` | `f2cfeaf12df2ebb9ebbcf36fe329980d270c7b178636aded89f73863dc3bfab5` |
| `SDK:pydantic_ai_slim-2.60.0.dist-info/RECORD` | `4450c27f05a0aff5e8190d7fe6f9a2877296481111b530fb62d16e1b3b84c81c` |

`…/` abbreviates `adapter-notes/pydantic-preflight-v1/preflight-pydantic_ai-`; snapshots in `adapter-notes/pydantic_ai-sources/sdk/` are byte-identical to the installed files paired with them (same SHA-256). The six source snapshots were not re-authenticated against a Git tag; provenance is the manifest plus matching installed hashes.
