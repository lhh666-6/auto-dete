# Pydantic AI adapter: native deferred approvals

Date: 2026-10-23. Implementation: `adapters/pydantic_ai.py`. It exports the shared `execute(case, out, phase)` interface and does not run or score the main matrix. The SDK installation is read-only and unchanged.

## Environment and source basis

Use the existing interpreter:

`D:/Claude_Design/auto-decte-paper/research/innovation-round2-2026-10-23/pydantic-control/.venv/Scripts/python.exe`

It is Python 3.11.9 with `pydantic-ai-slim==2.60.0`. Run the root worker with `-P -B`; the worker prepares the Windows event loop and installs the network guard before importing this adapter. The adapter also selects only the official local `FunctionModel`, sets `models.ALLOW_MODEL_REQUESTS=False`, and disables optional telemetry. No dependency was installed, upgraded, or modified for this adapter.

`adapter-notes/pydantic_ai-sources/manifest.json` records absolute installed paths, SHA256 values, copied evidence paths and the prior official-doc source locators. Six SDK sources and two documentation snapshots were copied byte-for-byte from the pinned positive-control installation. These are local copies of previously obtained source evidence; this step did not perform a new remote retrieval or independently authenticate a Git tag.

| Installed source | SHA256 |
|---|---|
| `pydantic_ai/_deferred.py` | `a29fcc7769b2b19b4ed175b275deaeaf1ec113a3faaae1eaec1cc199eefabbbb` |
| `pydantic_ai/_agent_graph.py` | `ecb9ed87edb61087b28e0b8880d593a3e84fcc157944c70dfc983078b882424b` |
| `pydantic_ai/messages.py` | `c9d7c2b650d952e8af6c79c37d447b656e6bf4296d77b607c700a24cd886cca5` |
| `pydantic_ai/tool_manager.py` | `4ef5522d925f1a50397e18b3c18c43f7e833cc5f143fe78e4ef0e3d7f7a602c1` |
| `pydantic_ai/models/function.py` | `658465a94e067da2f8125487c7a3980da69b364465eb9839092d557f2fd47ed0` |
| `pydantic_ai/_run_context.py` | `91afbba089b52873b88ae63e60f7c5d4d90f8de590e2d0e13d593d94baeea3c3` |

The source manifest is directly usable by the root freeze collector through its `sdk_sources` list. Its SHA256 is `f6fb5300ff23955dd070b381c9dd8d8fe98217e6b1b28b333348ecb17d8c13f2`.

## Native contract followed

The pinned official deferred-tools documentation describes ending an agent run with `DeferredToolRequests`, then starting a follow-up run with the prior message history and `DeferredToolResults`; approval entries are keyed by native `tool_call_id`. The same documentation includes more than one pending call. `_deferred.py` documents and implements `DeferredToolRequests.build_results`, including validation that approval IDs belong to the actual pending request set. `ModelMessagesTypeAdapter` in `messages.py` is the native serialization adapter for message histories.

`ToolApproved.override_args` is a complete replacement, not a partial patch. In the installed `tool_manager.py` at lines 1543–1549, the implementation replaces the call's arguments with that object and validates the replacement. The study application explicitly constructs `full_args = original + patch` for **every** actual pending call. An untouched call is also reviewed and approved using its complete original argument object. The adapter never relies on the SDK to merge partial edits.

Call assignment is based on IDs from actual native pending `ToolCallPart` objects. The deterministic model explicitly emits the input call IDs; the adapter validates that the resulting native pending IDs are unique and match the proposal before applying edits. It does not sort by argument content, match equal dictionaries, mutate SDK internals, or infer that equal arguments identify the same call. Identical-content original arguments on calls A and B remain separate native requests.

The declared effect body has required `destination: str`, `ticket: str`, `note: str`, `quantity: int`, and `enabled: bool`. It passes only its actual received arguments and `RunContext.tool_call_id` to the shared `study_common.append_effect`. Expected values and patches are not supplied to that writer. The parent scorer independently reads SQLite.

## Lifecycle implementation

- **live:** Construct a native Agent and pause after the single scripted proposal containing all calls. Keep the original native message objects and `DeferredToolRequests`; approve each actual pending call with full replacement arguments; continue on that Agent. Initial/final native histories, decisions and model diagnostics are saved separately.
- **prepare:** Construct and pause the Agent, then serialize its history using `ModelMessagesTypeAdapter.dump_json` and its actual `DeferredToolRequests` using `TypeAdapter(DeferredToolRequests).dump_json`. Save case digest, case ID, source pending records and preparation PID. Return with no decisions applied. The root worker exits.
- **resume:** A separate worker process creates a new Agent. Load history and requests through their native TypeAdapters, validate the prepared case digest, obtain the pending native IDs from the reconstructed request object, and build the complete approvals by those IDs. Pass the restored history and native deferred results to `agent.run_sync`. The adapter records prepare/resume PIDs and rejects accidental same-PID invocation as a sanity guard; the root's actual process spawning is the source of the fresh-process lifecycle, not a cryptographic interpretation of PIDs.

The model always emits all declared calls in one proposal. Subsequent behaviour depends only on whether the supplied message history already contains a `ToolCallPart`; if it does, the model returns final text. There is no counter controlling execution, no module-level memory of an earlier process, and no reset-to-first-call behaviour when the Agent is rebuilt. Diagnostics list the native IDs seen by each model invocation. These diagnostics do not decide whether an effect is correct.

The adapter returns `pending`, `decisions`, `native_status`, and `framework_errors`. Error extraction records native retry/failed/denied/interrupted message parts. Unhandled exceptions remain visible to the root worker. A final text response alone cannot establish correctness; SQLite effects remain the authoritative measurement. Native snapshot writes are create-only, so a repeated phase cannot silently overwrite the first trace.

## Preserved preflight

The root supplied four preflight cells: one call or two equal-content calls with only the second modified, crossed with live and fresh-process lifecycles. A separate manifest was written before executing them:

`adapter-notes/pydantic-preflight-v1/preflight-freeze.json`

SHA256: `147727ba9cfc89206a82a816c21fbaba96f1558f48693dac7c6ddde660ec6dc8`.

The adapter SHA256 before and after this preflight is `095a440835a0358d56a6375b58fd600a1823da5415795364b01b8a5ab02fabcc`. No repair or failed attempt was removed. All four cells ran successfully through six separately launched worker processes; no main-matrix cell was launched by this adapter task.

| Preflight | Actual SQLite rows | Field and call-ID readback | Additional checks |
|---|---:|---|---|
| live, one call | 1 | Correct | Model proposes once then finishes from history |
| live, two equal-content calls | 2 | Correct | A retains original values; only B receives its patch |
| fresh process, one call | 1 | Correct | Prepare has zero effects; resume uses a different PID |
| fresh process, two equal-content calls | 2 | Correct | Prepare has zero effects; A unchanged; B modified by ID |

Standard-library readback checks exact payload equality and exact bool/int/value types, one row per intended call ID, and the recorded tool name. Both resumes began with zero effects and their model diagnostics contain only a `finish` event with the persisted IDs; no proposal was emitted again. All six worker phases reported zero blocked network attempts, zero worker errors, and no native framework errors. All preflight input/source hashes and the six SDK source hashes remained unchanged.

Raw per-phase outputs, native serialized states and SQLite files remain under `adapter-notes/pydantic-preflight-v1/`. `driver-results.json` preserves stdout/stderr, including the SDK's local informational banner. The readback file is `preflight-readback.json`, SHA256 `b650394ee26490b527025d55555eb885717842b897c387bdfaa1aca0067d0317`.

## Support and interpretation limits

This adapter handles the study's valid, complete typed inputs, one proposal batch, all pending calls reviewed, and native approval-based tool execution. The implementation is generic over the call list and does not branch on case IDs or edit names. Different argument contents are supported by the same ID mapping, but the four preflight cells above only exercise the specifically assigned one/equal-content cases; other main-matrix outcomes remain to be measured by the root.

It does not infer human scope, minimize a binding footprint, handle externally executed deferred tools, intentionally omit approvals, test arbitrary model retries, or implement a new recovery algorithm. It does not authenticate untrusted client history or model principal revocation. The pinned official documentation explicitly treats client-submitted approval separately from service-side authorization; no stronger security guarantee is added here. Clean exit followed by a fresh worker process tests persisted-state continuation, not an unclean crash during a partially committed external effect or exactly-once delivery across failures. Two tool bodies may execute in native scheduling order; measurement should key effects by actual call ID rather than require their SQLite row order to match the input list.

The root owns shared worker/common code, final freeze, scorer, main batch and concurrency controls. This adapter's passing preflight is implementation readiness, not evidence of a new defect, algorithmic superiority, or broad framework reliability.
