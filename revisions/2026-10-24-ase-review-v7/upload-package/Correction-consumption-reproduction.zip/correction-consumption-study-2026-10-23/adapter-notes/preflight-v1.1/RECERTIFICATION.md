# v1.1 preflight recertification (development cells only)

2026-10-23, before the main freeze and before any main-matrix cell was collected.

The pre-freeze amendment v1.1 (see `PROTOCOL.md` and `progress.md`) changed only
diagnostic plumbing in the scorer and the three adapters: native pending-identity
differences are returned as observed state instead of raising, and the count of
effects that already exist before the native continue step is recorded. Case matrix,
values, edits, native SDK semantics, effect oracle and claim boundary are unchanged.

The retained v1 preflight artifacts under `adapter-notes/*-preflight-v1/` were
produced before that amendment and before three runtime fixes to `worker.py` and
`collect.py`. They remain unmodified history. They are **not** certification of the
revision that is frozen now, so the same twelve development cells were re-executed
against the current files with `adapter-notes/preflight-v1.1/driver.py`.

## Result of the v1.1 re-run

Twelve development cells, 18 separately launched worker processes, zero worker
errors, zero blocked network attempts.

| Framework | Lifecycle | Cell | Pending identity | Effect equality |
|---|---|---|---|---|
| Agno 3.1.10 | live | single | match | match |
| Agno 3.1.10 | live | two equal originals, second edited | match | **mismatch (known #8546)** |
| Agno 3.1.10 | fresh process | single | match | match |
| Agno 3.1.10 | fresh process | two equal originals, second edited | match | match |
| LangChain 1.4.7 / LangGraph 1.2.16 | live | single | match | match |
| LangChain 1.4.7 / LangGraph 1.2.16 | live | two equal originals, second edited | match | match |
| LangChain 1.4.7 / LangGraph 1.2.16 | fresh process | single | match | match |
| LangChain 1.4.7 / LangGraph 1.2.16 | fresh process | two equal originals, second edited | match | match |
| Pydantic AI 2.60.0 | live | single | match | match |
| Pydantic AI 2.60.0 | live | two equal originals, second edited | match | match |
| Pydantic AI 2.60.0 | fresh process | single | match | match |
| Pydantic AI 2.60.0 | fresh process | two equal originals, second edited | match | match |

Totals: pending identity matched in 12/12 cells, effect equality in 11/12, every
fresh-process cell had zero prepare-stage effects and two distinct PIDs. The single
mismatch reproduces the same mechanism as the retained v1 Agno live cell: both
pending calls consume the later call's reviewed user input, while each effect row
keeps its own native call ID. This is the publicly documented
[Agno #8546](https://github.com/agno-agi/agno/issues/8546) calibration, not a new
detection. It is recorded as development evidence and stays outside the main
denominator.

These twelve cells are development inputs that the main matrix later expands. They
are not blind, unseen or independent main samples.

## Current-revision identities

Recorded in `driver-results.json` (same directory) at the time of the re-run:

| File | SHA-256 |
|---|---|
| `adapters/agno.py` | see `driver-results.json` |
| `adapters/langchain.py` | see `driver-results.json` |
| `adapters/pydantic_ai.py` | see `driver-results.json` |
| `worker.py` | see `driver-results.json` |
| `score.py`, `study_common.py`, `preflight-cases.json` | see `driver-results.json` |

The independent Pydantic AI audit (`adapter-notes/pydantic-adapter-independent-review.md`)
reviewed `adapters/pydantic_ai.py` at `889743e7...`; `adapter-notes/pydantic_ai.md`
line 54 still quotes the pre-amendment hash `095a4408...`. That line documents the
v1 preflight's adapter and is correct as history; it must not be cited as
certification of the frozen revision. The frozen revision's hashes are in
`freeze.json`.

Reproduce with `python -B adapter-notes/preflight-v1.1/driver.py` from the study root
in a copy without an existing `cells/` directory.
