"""Re-run the 12 development preflight cells against the v1.1 diagnostic revision.

Development cells only. They stay outside the main denominator and are not main
outcomes. The v1 (pre-amendment) preflight artifacts are retained unchanged in
`adapter-notes/*-preflight-v1/`; this directory adds a current-revision re-run so the
preflight can be cited as certification of exactly the code that is frozen next.

Run from the study root:  python -B adapter-notes/preflight-v1.1/driver.py
"""
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent.parent
sys.path.insert(0, str(STUDY))
from collect import PYTHONS  # noqa: E402
from score import expected_effects, judge, multiset  # noqa: E402
from study_common import effect_rows, read, sha, write  # noqa: E402

OUT = HERE / 'cells'


def planned_pending(case):
    return multiset([{'call_id': call['id'], 'name': 'record_delivery', 'args': call['original']}
                     for call in case['calls']])


def run_cell(case):
    out = OUT / case['id']
    if out.exists():
        raise RuntimeError('refusing to reuse a preflight cell directory: ' + str(out))
    out.mkdir(parents=True)
    write(out / 'case.json', case)
    phases = ['live'] if case['lifecycle'] == 'live' else ['prepare', 'resume']
    runs = []
    for phase in phases:
        command = [str(PYTHONS[case['framework']]), '-P', '-B', str(STUDY / 'worker.py'),
                   '--case-file', str(out / 'case.json'), '--out', str(out), '--phase', phase]
        done = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
        record = read(out / (phase + '.json')) if (out / (phase + '.json')).exists() else None
        runs.append({'phase': phase, 'returncode': done.returncode,
                     'stdout': done.stdout[-3000:], 'stderr': done.stderr[-3000:], 'record': record})
    actual = effect_rows(out)
    verdict = judge(case, actual)
    pending = {run['phase']: multiset(run['record']['trace']['pending']) == planned_pending(case)
               for run in runs if run['record'] and 'trace' in run['record']}
    readback = {
        'case_id': case['id'], 'framework': case['framework'], 'lifecycle': case['lifecycle'],
        'scenario': case['scenario'], 'edit': case['edit'],
        'effect_match': verdict['effect_match'], 'role_match': verdict['role_match'],
        'pending_match_by_phase': pending, 'pending_match': len(pending) == len(phases) and all(pending.values()),
        'expected': expected_effects(case), 'actual': actual, 'diagnostics': verdict['diagnostics'],
        'phases': [{'phase': run['phase'], 'returncode': run['returncode'],
                    'pid': (run['record'] or {}).get('pid'),
                    'error': (run['record'] or {}).get('error'),
                    'network_attempts': (run['record'] or {}).get('network_attempts'),
                    'native_status': (((run['record'] or {}).get('trace') or {}).get('native_status')),
                    'effects_before_phase': (run['record'] or {}).get('effects_before_phase'),
                    'effects_after_phase': (run['record'] or {}).get('effects_after_phase'),
                    'effects_before_continue': (((run['record'] or {}).get('trace') or {})
                                                .get('effects_before_continue')),
                    'stdout_tail': run['stdout'][-600:], 'stderr_tail': run['stderr'][-600:]}
                   for run in runs],
        'separate_processes': (None if case['lifecycle'] == 'live' else
                               len(runs) == 2 and runs[0]['record'] and runs[1]['record']
                               and runs[0]['record']['pid'] != runs[1]['record']['pid']),
        'prepare_zero_effects': (None if case['lifecycle'] == 'live' else
                                 bool(runs and runs[0]['record']) and
                                 runs[0]['record'].get('effects_after_phase') == 0),
        'native_framework_errors': [error for run in runs
                                    for error in ((run['record'] or {}).get('trace') or {})
                                    .get('framework_errors', [])],
    }
    write(out / 'readback.json', readback)
    return readback


def main():
    cases = read(STUDY / 'preflight-cases.json')
    rows = [run_cell(case) for case in cases]
    summary = {
        'purpose': 'current-revision (v1.1 diagnostic amendment) re-run of the 12 development cells',
        'main_denominator': False,
        'cases': len(rows),
        'effect_match': sum(row['effect_match'] for row in rows),
        'pending_match': sum(row['pending_match'] for row in rows),
        'prepare_zero_effects_all': all(row['prepare_zero_effects'] in (None, True) for row in rows),
        'separate_processes_all': all(row['separate_processes'] in (None, True) for row in rows),
        'network_attempts': sum(phase['network_attempts'] or 0 for row in rows for phase in row['phases']),
        'worker_errors': sum(1 for row in rows for phase in row['phases'] if phase['error']),
        'hashes': {'adapters/' + name: sha(STUDY / 'adapters' / name)
                   for name in ['agno.py', 'langchain.py', 'pydantic_ai.py']}
                  | {'worker.py': sha(STUDY / 'worker.py'), 'score.py': sha(STUDY / 'score.py'),
                     'study_common.py': sha(STUDY / 'study_common.py'),
                     'preflight-cases.json': sha(STUDY / 'preflight-cases.json')},
        'rows': rows,
    }
    write(HERE / 'driver-results.json', summary)
    table = [{'case': row['case_id'], 'effect_match': row['effect_match'],
              'pending_match': row['pending_match'],
              'separate_processes': row['separate_processes'],
              'prepare_zero_effects': row['prepare_zero_effects'],
              'effects': len(row['actual'])}
             for row in rows]
    print(json.dumps({'cases': summary['cases'], 'effect_match': summary['effect_match'],
                      'pending_match': summary['pending_match'],
                      'worker_errors': summary['worker_errors'],
                      'network_attempts': summary['network_attempts'],
                      'prepare_zero_effects_all': summary['prepare_zero_effects_all'],
                      'separate_processes_all': summary['separate_processes_all']}, indent=2))
    for row in table:
        print(row)


if __name__ == '__main__':
    main()
