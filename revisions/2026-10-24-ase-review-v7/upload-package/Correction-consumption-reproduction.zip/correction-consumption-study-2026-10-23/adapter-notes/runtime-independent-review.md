# Independent runtime review before main collection

Reviewed on 2026-10-23 by the separate adapter/review agent. Scope: read-only
inspection of `collect.py`, `worker.py`, `runtime_checks.py`, `study_common.py`, the
execution-limit section of `PROTOCOL.md`, and the existing fault-check evidence.
This reviewer did not execute a main cell, rerun fault checks, modify the runtime,
or alter the framework environments. Only this review file was written.

**Decision: no remaining blocking defect identified for the declared, trusted,
offline adapter workload, after three pre-freeze fixes by the runtime author.**
This is a source/evidence review, not an OS sandbox certification or an independent
reproduction of all fault injections. Freeze the reviewed source before collection.

## Findings and closure

| Initial finding | Consequence before the fix | Reviewed fix | Evidence and status |
| --- | --- | --- | --- |
| Phase overwrite was rejected only after adapter execution. | Directly repeating a worker command could execute a tool body again before refusing to overwrite its phase record. | `worker.py:26` checks the phase record before execution and exclusively creates a persistent phase claim before SDK import or effect-DB access. Completed and claimed phases return code 3. Claims survive interrupted execution. | `worker_claim_refuses_before_effects` passes with a deliberately nonexistent adapter name, no effect DB, and no new phase result. The completed-record branch was inspected. **Closed.** |
| Completed-case validation did not bind the output to the active freeze. | Artifact-consistent output from a different frozen implementation could be skipped as if it belonged to the current study. | `collect.py:121` requires the terminal `freeze_sha256` to equal the current freeze (or the explicit synthetic test value), then checks case identity/content and the complete artifact hash map. | `validated_resume`, `resume_wrong_freeze_refused`, and `resume_tamper_refused` all pass. **Closed.** |
| Persistent resource limits were checked only while the child was still running. | A worker could write an oversized log/artifact and exit between polling ticks, yielding an ordinary exit status. | `collect.py:102` checks STOP, both log sizes, total artifact bytes, and free disk again after exit. | Both `fast_exit_log` and `fast_exit_artifact` return the appropriate limit status despite worker return code 0. **Closed.** |

The fixes were inspected in the final source listed below. The initial 15-check
run is retained by the author; the expanded 21-check run is the reviewed evidence.
No successful effect is treated as proof that collection itself completed normally.

## Runtime properties checked

- **Process separation and retained state.** `run_case` launches a separate Python
  process for each phase. Fresh-process cases use sequential prepare/resume commands
  with the same case-local persistence directory, rather than carrying Python
  objects between them. The command uses `-P -B`; adapter import is from a fixed
  framework filename after the guard. The collector admits at most the configured
  number of pending tasks and creates separate directories for cases.
- **STOP and resource enforcement.** STOP is tested before dispatch, before launch,
  during monitoring, and after exit. A resource or network-attempt result writes
  global STOP. Monitoring samples process-tree RSS and persistent resource usage;
  termination targets the PID launched by this runner using `/T /F`, not a global
  executable-name match. Timeout, memory, log, artifact, free-disk, and STOP fault
  records show the expected reason and report all observed PIDs dead. The parent
  collector retains phase/process records rather than silently retrying a failure.
- **Credential and network handling.** `clean_environment` forwards an explicit
  operating-system-variable allowlist and sets local scratch paths and telemetry
  disable flags. It does not forward API-key/token variables. The worker creates
  the Windows asyncio self-pipe first, then denies Python connect/connect_ex/sendto,
  create_connection and getaddrinfo before importing the adapter. Attempts are
  counted even if an SDK catches the resulting exception; the collector treats a
  nonzero count as a global stop. No credential values were inspected or logged by
  this review.
- **No automatic replay.** The collector validates completed cases and skips
  them; a pre-existing incomplete case directory is classified
  `incomplete_no_retry`. The worker's persistent exclusive claim independently
  prevents repeating an already-started phase. Resume validation includes exact
  case content, freeze identity, and all retained case artifacts. Source and listed
  SDK hashes are verified before collection and at worker boundaries.
- **Effect evidence and collection status.** The shared effect writer records
  actual tool call IDs and actual payloads in case-local SQLite; it does not read
  expected values. Readback uses SQLite read-only mode. The supplied oracle controls
  reject wrong call ID, Boolean/integer substitution, missing field, duplicate
  effect and cross-call modification. The supplied scoring controls retain timeout
  classification even when effects match, and distinguish unsupported cases.

## Evidence read, not independently rerun

The pointer `runtime-checks-latest.json` identifies:

`runtime-checks-1792768101042876500/RESULT.json`

Its SHA-256 is
`bad5fd5aef53d921e377c6dd89192ac2995851af5af172246886d75ca31b618b`.
The file's actual hash matches the pointer. It reports **21/21 checks passed**, at
`2026-10-23T15:08:30.602894+00:00`. I inspected every check result and its generating
test, including the new replay/freeze/fast-exit cases. This count is heterogeneous
runtime and oracle controls, not 21 SDK study cases or independent repetitions.

The timeout-tree fixture deliberately keeps the parent alive while a child sleeps;
its observed process tree is killed. The fast-exit fixtures directly cover the
previously missing post-exit persistent-limit path. The duplicate-phase fixture
covers a pre-existing claim, not a stress test of every possible concurrent race.

## Limits of this approval

The protocol already states that the Python guard is not OS-level isolation.
Specifically, this runner is suitable for reviewed offline adapters, not hostile
arbitrary programs. It does not prevent reading credential files available to the
same Windows user, native-code networking, deliberate guard replacement, or an
intentionally detached descendant. `terminate_tree` returns when its direct parent
has already exited; the supplied child-cleanup test therefore does not certify
cleanup of arbitrary orphaned background processes. The reviewed adapters are not
designed to create such background workloads.

The 100 ms sampling interval and termination overhead make memory/time thresholds
operational stop thresholds rather than hard kernel quotas. Short-lived memory
peaks may be missed; writes may overshoot before termination. The post-exit checks
detect retained log/artifact overshoot but cannot undo it. The 32 MiB artifact
threshold is per case, and the free-space check concerns the output volume; these
are not a global filesystem quota. `paid_calls: 0` is a declared workload property,
supported here by scripted models, the stripped environment and the Python guard,
not billing-service metering.

Hash verification is a reproducibility check against the local trusted manifest,
not cryptographic authentication against an adversary able to rewrite both data
and manifest. Atomic JSON replacement preserves an individual record; it is not a
transaction spanning the SQLite effect, native persistence and terminal marker.
Interrupted evidence is intentionally retained and not automatically replayed.
These boundaries do not block this study and must remain visible in its claims.

## Reviewed source identities

| File | SHA-256 |
| --- | --- |
| `collect.py` | `307bdf6101a7a6bd083871762d15679af4cadfd297564c9a4378888121662c1d` |
| `worker.py` | `44c4097ed2a746e95a65ecdbd83d6e6b6a33b1e23f7fc44bc7bd920215d4a475` |
| `runtime_checks.py` | `28a0b9ae8161fde7b2a8d9b5f92fcd0902859fbc49ec0262908f45553ee70cf9` |
| `study_common.py` | `8b4a21ab8996b0ea81aadb32dbd5d7cd52f32382420b631335cd3834f52790f9` |

Any later change to these reviewed files needs an explicit review delta. This
report does not authorize altering frozen adapters in response to main outcomes,
dropping native failures, or expanding paid/model/production execution.
