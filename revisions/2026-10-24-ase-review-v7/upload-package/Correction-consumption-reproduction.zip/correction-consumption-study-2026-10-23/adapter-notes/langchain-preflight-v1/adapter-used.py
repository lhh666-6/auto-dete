"""Native LangChain per-call edits, with live or fresh-process SQLite resume.

The model supplies a proposal only. Actual tool arguments and ToolRuntime call IDs
are observed by study_common.append_effect. No expected effects are written here.
"""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path

from study_common import append_effect


TOOL_NAME = 'record_delivery'
FIELDS = {'destination': str, 'ticket': str, 'note': str, 'quantity': int, 'enabled': bool}
REVIEW_FIELDS = {'note', 'quantity', 'enabled'}
METADATA = 'langchain-session.json'
CHECKPOINT = 'langchain-checkpoint.sqlite'


def _fingerprint(case):
    return hashlib.sha256(json.dumps(case, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def _unsupported(reason):
    return {'pending': [], 'decisions': [], 'native_status': 'unsupported',
            'framework_errors': [], 'unsupported_reason': reason}


def _save_metadata(path, data):
    # Refuse a second prepare/live run in an already-used case directory.
    with path.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def execute(case: dict, out: Path, phase: str) -> dict:
    out = Path(out)
    if case.get('framework') != 'langchain':
        return _unsupported('This adapter only supports LangChain.')
    if phase not in {'live', 'prepare', 'resume'}:
        return _unsupported('Supported phases are live, prepare, and resume.')
    if case.get('lifecycle') != ('live' if phase == 'live' else 'fresh_process'):
        return _unsupported('The phase does not implement the declared lifecycle.')
    calls = case.get('calls', [])
    if len(calls) not in {1, 2}:
        return _unsupported('Only one or two same-turn record_delivery calls are declared.')
    call_ids = [call.get('id') for call in calls]
    if any(type(value) is not str or not value for value in call_ids) or len(set(call_ids)) != len(call_ids):
        return _unsupported('Native per-call mapping requires distinct nonempty string call IDs.')
    for call in calls:
        if not isinstance(call.get('original'), dict) or not isinstance(call.get('patch'), dict):
            return _unsupported('Original arguments and human patches must be dictionaries.')
        if not set(call['original']) <= set(FIELDS) or not set(call['patch']) <= REVIEW_FIELDS:
            return _unsupported('Arguments or review fields are outside the declared schema.')
        reviewed = {**call['original'], **call['patch']}
        if set(reviewed) != set(FIELDS) or any(type(reviewed[key]) is not typ for key, typ in FIELDS.items()):
            return _unsupported('The complete reviewed object must satisfy the required primitive schema.')

    # Network denial is installed by the root worker before this adapter is loaded.
    os.environ['LANGSMITH_TRACING'] = 'false'
    os.environ['LANGCHAIN_TRACING_V2'] = 'false'
    from langchain.agents import create_agent
    from langchain.agents.middleware import HumanInTheLoopMiddleware
    from langchain.tools import ToolRuntime, tool
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage, ToolMessage
    from langchain_core.outputs import ChatGeneration, ChatResult
    from langgraph.checkpoint.sqlite import SqliteSaver
    from langgraph.types import Command

    planned_calls = [{'id': call['id'], 'name': TOOL_NAME,
                      'args': deepcopy(call['original']), 'type': 'tool_call'} for call in calls]
    planned_ids = set(call_ids)

    class ScriptModel(BaseChatModel):
        @property
        def _llm_type(self):
            return 'offline-persisted-history-script'

        def bind_tools(self, tools, **kwargs):
            return self

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            completed_ids = {message.tool_call_id for message in messages if isinstance(message, ToolMessage)}
            prior_proposal = any(isinstance(message, AIMessage) and message.tool_calls for message in messages)
            if planned_ids <= completed_ids:
                answer = AIMessage(content='Scripted proposal finished.')
            elif prior_proposal:
                # Never re-propose because a model was reconstructed. Retain this
                # unexpected lifecycle condition as a diagnostic, not a retry.
                raise RuntimeError('Scripted model reached before all proposed tool messages were persisted.')
            else:
                answer = AIMessage(content='', tool_calls=deepcopy(planned_calls))
            return ChatResult(generations=[ChatGeneration(message=answer)])

    @tool
    def record_delivery(destination: str, ticket: str, note: str, quantity: int,
                        enabled: bool, runtime: ToolRuntime) -> str:
        """Append a local synthetic delivery using the arguments actually received."""
        append_effect(out, runtime.tool_call_id,
                      {'destination': destination, 'ticket': ticket, 'note': note,
                       'quantity': quantity, 'enabled': enabled})
        return 'Recorded in the local observation database.'

    def build(saver):
        return create_agent(model=ScriptModel(), tools=[record_delivery], checkpointer=saver,
                            middleware=[HumanInTheLoopMiddleware(
                                interrupt_on={TOOL_NAME: {'allowed_decisions': ['edit']}},
                                interrupt_mode='per_call')])

    checkpoint = out / CHECKPOINT
    metadata_path = out / METADATA
    if phase == 'resume':
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        if metadata['case_sha256'] != _fingerprint(case):
            raise ValueError('Resume case differs from the prepared case.')
        if metadata['prepare_pid'] == os.getpid():
            raise ValueError('fresh_process resume must run in a different process from prepare.')
        if not checkpoint.is_file():
            raise FileNotFoundError('The prepared native SQLite checkpoint is missing.')
        thread_id = metadata['thread_id']
    else:
        if checkpoint.exists() or metadata_path.exists():
            raise FileExistsError('Refusing to replace an existing LangChain checkpoint or prepare record.')
        thread_id = case['id']
        metadata = None

    config = {'configurable': {'thread_id': thread_id}, 'recursion_limit': 16}
    trace = {'pending': [], 'decisions': [], 'native_status': 'initializing', 'framework_errors': [],
             'phase': phase, 'process_pid': os.getpid(), 'thread_id': thread_id,
             'checkpoint_file': CHECKPOINT, 'mapping': 'native tool_call_id to interrupt.id',
             'interrupt_mode': 'per_call'}
    if metadata is not None:
        trace['prepare_pid'] = metadata['prepare_pid']
        trace['prepared_pending'] = metadata['pending']

    with SqliteSaver.from_conn_string(str(checkpoint)) as saver:
        graph = build(saver)
        if phase == 'resume':
            snapshot = graph.get_state(config)
            interruptions = [interruption for task in snapshot.tasks for interruption in task.interrupts]
            trace['restored_checkpoint'] = deepcopy(snapshot.config)
        else:
            paused = graph.invoke({'messages': [{'role': 'user', 'content': 'Review the proposed local deliveries.'}]},
                                  config=config)
            interruptions = list(paused.get('__interrupt__', []))
            trace['paused_checkpoint'] = deepcopy(graph.get_state(config).config)

        for interruption in interruptions:
            value = interruption.value
            if not isinstance(value, dict) or value.get('type') != 'tool_approval':
                raise RuntimeError('Unexpected native interrupt shape for declared per-call review.')
            trace['pending'].append({'call_id': value['tool_call_id'], 'name': value['name'],
                                     'args': deepcopy(value['args'])})
        trace['native_interrupts'] = [{'interrupt_id': item.id, 'value': deepcopy(item.value)}
                                      for item in interruptions]
        observed_ids = [item['call_id'] for item in trace['pending']]
        if (len(interruptions) != len(calls) or len(set(observed_ids)) != len(observed_ids)
                or set(observed_ids) != planned_ids
                or any(item['name'] != TOOL_NAME for item in trace['pending'])):
            trace['native_status'] = 'unexpected_pending'
            trace['framework_errors'].append({'type': 'PendingIdentityMismatch',
                                              'expected_call_ids': call_ids, 'actual_call_ids': observed_ids})
            return trace

        if phase != 'resume':
            _save_metadata(metadata_path, {'version': 1, 'thread_id': thread_id,
                                           'case_sha256': _fingerprint(case), 'prepare_pid': os.getpid(),
                                           'pending': trace['pending'],
                                           'interrupt_ids': [item.id for item in interruptions]})
        if phase == 'prepare':
            trace['native_status'] = 'paused'
            return trace  # Leaving the with block closes the native SQLite connection.

        by_id = {call['id']: call for call in calls}
        answers = {}
        # Per-call interrupts have no promised ordering. Preserve observed order in
        # diagnostics, but bind each answer through its native IDs, never args/order.
        for interruption in interruptions:
            call_id = interruption.value['tool_call_id']
            call = by_id[call_id]
            full_args = deepcopy(call['original'])
            full_args.update(deepcopy(call['patch']))
            answers[interruption.id] = {'type': 'edit', 'edited_action':
                                       {'name': interruption.value['name'], 'args': full_args}}
            trace['decisions'].append({'call_id': call_id, 'patch': deepcopy(call['patch']),
                                       'full_args': deepcopy(full_args), 'interrupt_id': interruption.id})
        result = graph.invoke(Command(resume=answers), config=config)
        final_state = graph.get_state(config)
        trace['remaining_interrupts'] = [{'id': item.id, 'value': deepcopy(item.value)}
                                         for item in result.get('__interrupt__', [])]
        trace['final_next'] = list(final_state.next)
        trace['final_messages'] = [message.model_dump(mode='json') for message in result.get('messages', [])]
        for message in result.get('messages', []):
            if isinstance(message, ToolMessage) and message.status == 'error':
                trace['framework_errors'].append({'type': 'ToolMessageError', 'call_id': message.tool_call_id,
                                                  'content': deepcopy(message.content)})
        trace['native_status'] = ('paused' if trace['remaining_interrupts'] or trace['final_next'] else
                                  'completed_with_tool_errors' if trace['framework_errors'] else 'completed')
        return trace
