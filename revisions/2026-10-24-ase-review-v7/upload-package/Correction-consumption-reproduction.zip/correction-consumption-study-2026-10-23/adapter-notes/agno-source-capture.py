"""Copy only Agno source evidence; never import or modify the SDK."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
import sysconfig
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
TARGET=ROOT/'adapter-notes/agno-source'
SITE=Path(sysconfig.get_paths()['purelib'])
FILES=['agno/run/agent.py','agno/run/requirement.py','agno/models/base.py','agno/models/response.py',
       'agno/tools/function.py','agno/agent/_run.py','agno/agent/_tools.py','agno/agent/_storage.py',
       'agno/utils/agent.py','agno/utils/functions.py','agno/utils/tools.py',
       'agno/session/agent.py','agno/db/json/json_db.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
TARGET.mkdir(parents=True,exist_ok=True)
rows=[]
for name in FILES:
    source=SITE/name
    target=TARGET/name
    if target.exists():raise RuntimeError('NO_OVERWRITE: '+str(target))
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    rows.append({'path':str(source),'relative':name,'sha256':sha(source)})
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'python':sys.executable,
          'agno_version':importlib.metadata.version('agno'),
          'release':'v3.1.10','release_commit':'04330571dc84b15d03dd3c2b598f8f01d4a239e0',
          'adapter_sha256':sha(ROOT/'adapters/agno.py'),'sdk_sources':rows}
(TARGET/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))

