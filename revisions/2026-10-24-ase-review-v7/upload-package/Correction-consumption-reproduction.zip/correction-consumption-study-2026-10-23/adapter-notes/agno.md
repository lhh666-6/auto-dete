# Agno adapter — native user-input correction and process restoration

Status: implementation and four root-specified preflight cells complete.
No main-study cells were run by this adapter author. No package was installed,
upgraded or edited. No paid/model API or outbound socket attempt occurred.

## Interface and environment

Exports `execute(case, out, phase)` with `live`, `prepare`, `resume`.
Adapter SHA256:
`d191acc05d9908a17b9bb536e9e41cc18e7d2f06731b8b467b8803d1d33e5d2c`.

Python:
`D:/Claude_Design/auto-decte-paper/research/innovation-round2-2026-10-23/consumer-probes/.venv/Scripts/python.exe`.
Installed Agno is 3.1.10; tagged source commit
`04330571dc84b15d03dd3c2b598f8f01d4a239e0`.
The environment is read-only for this task. The parent worker supplies the
network guard before adapter import, creates each independent effect SQLite,
and records phase PID, exceptions, socket attempts and stdout/stderr.

The model is a native Model subclass with deterministic responses and no
provider client. It emits all supplied call IDs in one proposal, in case order.
Any persisted tool-role message ends the script. There is no process-local
call counter to reset when constructing the resume agent. The body receives no
case or expected-value object; it records its actual five arguments with the
runtime FunctionCall.call_id observed by a public pre_hook. The pre_hook only
sets a ContextVar and does not change parameters, authorization or control flow.

## Supported public semantics and configuration

This adapter deliberately uses `@tool(requires_user_input=True)` **without**
`user_input_fields`. Thus all five parameters remain in the model-facing
schema and can be prefilled in the proposal, then replaced by human input.
The official [User Input documentation](https://docs.agno.com/hitl/user-input)
explains that omitting the list / passing [] leaves parameters in the model
schema; its description of prefilled fields permits using or overriding the
existing value. The same page explicitly describes keeping run ID, session ID
and the same database across a new process.

This differs from the earlier small consumer/method pilots, which explicitly
listed note/quantity (and later enabled) as human fields and thereby hid those
fields from the model schema. The formal study does not repeat that setting
merely to reproduce an old result. Actual observed model schemas are recorded in
`model_schema_observations`, and all five required string/string/string/integer/
boolean properties are present in the preflight. `requested_schema_fields`
also contains all five for every pending call.

Every native pending requirement is mapped to the application's call by actual
tool_call_id, with uniqueness/completeness checks. A missing, duplicate or
unexpected ID raises an explicit unsupported/mapping exception; no positional
guess or argument-equality matching is used. This matters when two calls have
identical original arguments. The application forms full original+patch and
supplies all requested native fields, including unmodified values, through
RunRequirement.provide_user_input. All requirements must be resolved before
continuation. No SDK object is rewritten to manufacture isolation or a failure.

- **live:** use the original paused RunOutput and original requirement objects,
  then `continue_run(run_response=paused)`.
- **prepare:** native Agent.run pauses; native JsonDb persists; return without
  continuation or body effect. `agno-state.json` contains only run/session IDs
  plus an input digest, not an alternative persisted execution architecture.
- **resume:** a new process constructs a new Agent/model with the same JsonDb,
  loads the native RunOutput by get_run_output, provides complete input, then
  uses the recommended `continue_run(run_id, session_id, requirements)`.
  The earlier getter-response route is absent from this fresh-process path.

The [HITL overview](https://docs.agno.com/hitl/overview) describes resolving all
active requirements and both native continuation forms.
[Agent reference](https://docs.agno.com/reference/agents/agent) documents getter
and continuation parameters; [tool hooks](https://docs.agno.com/tools/hooks)
documents observational FunctionCall pre-hooks.

The return value includes actual pending calls, decisions with patch/full_args,
native status, native errors, before/after requirement snapshots, final tools,
remaining pending requirements and native persisted readback. Native completed
is not independently equated with business correctness.

## Four retained preflight cells

The four inputs came from root's preflight-cases.json, selected by framework.
There were no locally selected extra native cases and no discarded failures.

| Preflight | Body result | Prepare effect count | PID condition |
|---|---|---:|---|
| live, single call | Matches reviewed values | n/a | one process |
| live, two identical original calls, only second corrected | **Mismatch:** both call IDs consume second call's corrected values | n/a | one process |
| fresh process, single call | Matches | 0 | prepare 32172, resume 51648 |
| fresh process, two identical original calls, only second corrected | Both calls match their respective values | 0 | prepare 80508, resume 52988 |

All six worker phase executions returned zero with no worker exceptions and
zero network attempts. Effects were independently queried through a read-only
SQLite connection by the preflight driver. Three of four business outcomes
match. The failure is retained, not repaired or excluded. Traces have actual
call-A / call-B IDs; the observational hook does not infer IDs from expected
data. No framework source or adapter was changed after these observations.

Evidence: `agno-preflight-v1/readback.json`, `input-manifest.json`, and
per-cell case.json, live/prepare/resume.json, corresponding process stdout/stderr,
effects.sqlite, and native agno-db files. The root worker/common/adapter/input
hashes at preflight are in input-manifest. This preflight is calibration, not
a main-study estimate.

## Exact known prior — not a new discovery

Official [Agno issue #8546](https://github.com/agno-agi/agno/issues/8546),
created 2026-06-24 and still open when checked, describes same-function parallel
HITL calls sharing user_input_schema and last-write clobbering. It traces the
2.6.13 source paths, provides a manually constructed reproduction, and describes
a real route-mode team trigger. This matches the mechanism suggested by the
current 3.1.10 live preflight. The current evidence adds actual Agent/body and
fresh-process controls, but must be classified as known-issue calibration or
current-release reproduction, not a newly discovered bug.

Queries checked and full returned issue material are retained in
`agno-source/official-issue-evidence.json`:
- `repo:agno-agi/agno "user_input_schema" "multiple"`
- `repo:agno-agi/agno "user input" "same tool"`
- a linked-PR search containing 8546.

No matching repair was established by these searches; search absence cannot
prove no fix exists. The suggested workaround in the issue was not applied.

## Source evidence for the parent freeze

`agno-source/manifest.json` includes absolute installed paths and SHA256 values
for 13 files; matching byte snapshots are under `agno-source/agno/`:

- run/agent.py and run/requirement.py: native restoration and requirement update;
- models/base.py and models/response.py: function-call pause and ToolExecution;
- tools/function.py: schema derivation, per-run copies, actual call execution;
- agent/_run.py, _tools.py, _storage.py: continuation, parameter consumption, getter;
- utils/agent.py, functions.py, tools.py: stored run and call mapping;
- session/agent.py and db/json/json_db.py: native persisted objects.

Relevant source chain: models/base.py assigns the function's user_input_schema
to paused ToolExecution; RunRequirement references that schema; provide_user_input
writes its fields; agent/_tools.py handle_user_input_update copies schema fields
to actual tool_args. Existing per-run Function copying isolates different runs,
which is distinct from per-call isolation within one proposal.

## Limits

Only synchronous native Agent user-input flows were preflighted. Same/different
argument main cells are owned by the parent; the local preflight covered single
and two-identical-original cases only. No streaming, async, teams, malicious
serialized state, actor authentication, concurrent resume or crash injection is
claimed. JsonDb and metadata live inside each case directory. Runtime IDs are
required to be unique; unsupported mappings fail explicitly. The process boundary
is real, but orderly prepare exit is not a crash-durability theorem. Results
cannot establish method innovation, model intelligence or general defect rates.

