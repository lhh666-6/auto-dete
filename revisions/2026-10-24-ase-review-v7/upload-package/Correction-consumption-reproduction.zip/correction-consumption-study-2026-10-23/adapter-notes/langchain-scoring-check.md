# LangChain scoring check

Checked 2026-10-23, before the main collection. Scope: read-only review of the shared scorer and the four retained LangChain development preflights. This reviewer implemented the LangChain adapter; the scoring observations below were reconstructed from saved case inputs, phase records and read-only SQLite queries. They are not an independent implementation of that adapter or additional native experimental cells.

## Verdict

The effect oracle correctly preserves exact primitive types, call identity, complete payloads and multiplicity on the four observed preflights. Both oracles accept all four. One pre-freeze scoring gap was reported directly to the coordinating agent: fresh-process `pending_match` originally checked only the prepare record, omitting the native pending payload reconstructed during resume. The coordinator repaired this before freeze; the final read-only check confirms all required phases are now compared. The two existing fresh-process preflights pass the added check when independently evaluated; no observed preflight outcome changes. No blocking finding remains in this narrow audit.

Reviewed `score.py` SHA256: `e8e8c657563a55d221acc29b7714c81c949fe8ec7896bb88dcf87817f01d382f`.

Final repaired `score.py` SHA256: `3c93a223f84e51c9cb3e4e2ebf8ad4ad58c78b004cfef5ef44f5b1d26faea764`.

## Source and artifact checks

- Adapter SHA256: `c215dded9a1005c769c84afa32934c1d1b91dfa70b25d0434e9814ff11fd0b66`. It exactly matches `langchain-preflight-v1/adapter-used.py`; no post-preflight implementation change was found.
- Source manifest: study-root `source-evidence/langchain/manifest.json`, SHA256 `49180c0e1dad8036c245111fab1e6a09928ff4b85658d1f35ea2b2fbf9df8fb1`. It exports `sdk_sources` entries containing absolute installed-source `path` and `sha256`, plus snapshot paths. All nine installed files and nine retained snapshots match their recorded digests.
- Python: the existing `consumer-probes/.venv/Scripts/python.exe`, Python 3.11.9. Installed LangChain 1.4.7, langchain-core 1.7.0, LangGraph 1.2.16, langgraph-prebuilt 1.1.1, checkpoint 4.3.0, checkpoint-sqlite 3.1.2. No dependency installation or SDK modification.
- Every phase's recorded input hash matches its retained `case.json`. Six worker records show zero network attempts. Read-only SQLite inspection found six actual effect rows across four cases.
- These development folders have worker-level phase records, not the main collector's `complete.json` artifact seals. The audit therefore invokes the actual `judge`/`multiset` functions on their data and reviews the collector/classifier code; it does not represent the four folders as fully sealed `score_case` main outputs.

## Observed preflights

All folders are under `adapter-notes/langchain-preflight-v1/`; the following shortened names omit the common `preflight-langchain-` prefix and `-multiple-ascii` suffix.

| Cell | Native pending matches original | Actual effects | Effect / role verdict | Process evidence |
|---|---|---:|---|---|
| live-single | live: yes | 1 | true / true | PID 83872, completed |
| live-equal_second | live: yes | 2 | true / true | PID 2176, completed |
| fresh_process-single | prepare: yes; resume: yes | 1 | true / true | prepare 61376; resume 40284 |
| fresh_process-equal_second | prepare: yes; resume: yes | 2 | true / true | prepare 53056; resume 49872 |

Both prepare records are paused with zero effects; both resume records are completed in distinct interpreters. The equal-original cases preserve call-A's original values and apply the explicit patch only to call-B. The observed pending arguments genuinely match before and after the SQLite checkpoint boundary.

## Scoring findings

### Resolved before freeze: compare pending in every native phase

In the reviewed `score_case`, `first = records.get(phases[0], {})` selects prepare for a fresh-process case and `pending_match` compares only that record against the planned original calls. The resume trace also carries native pending arguments from `graph.get_state(config)`, but they are not compared. Therefore an argument altered by persistence/reconstruction could escape the stated setup-consistency gate if the application's complete edited arguments later overwrite it and the actual effect is correct. This is a classifier coverage gap, not evidence that LangChain performed that alteration.

The coordinator's final repair computes `pending_matches_by_phase`, requires the expected number of phase records and `all(pending_matches.values())`, and exposes per-phase results. Interruption enumeration order remains irrelevant. A missing phase cannot pass this gate. I inspected the final code and independently compared every retained native phase against the original calls; all six phase checks pass. I did not edit the scorer. The root-owned runtime-check pointer separately reports 21/21 checks passed, report SHA256 `7ff0e7215cf10f1bd70e2a78cc1c7c3d55e007096964e545370461f44af320e7`; those fault tests were not rerun by this reviewer.

### Exact primitive and call-ID behavior: passes

`canonical` uses JSON representation rather than Python scalar equality. Thus `false` and `0`, or `true` and `1`, differ. The primary oracle compares complete `(call_id, name, args)` multisets, detecting duplicates and extra calls without imposing SQLite insertion order. Expected arguments come from original input plus explicit patch; they are not copied from observed effects or native/model status.

The field-role oracle has the same information and checks one effect per intended ID, tool name, field set, exact scalar value, and unexpected IDs. Its agreement with complete-effect equality is expected in this fixed five-field domain and is not detection improvement.

Four in-memory checks used the retained fresh/equal-second SQLite rows without changing files or rerunning native SDKs:

| Software check | Primary equality | Field-role equality |
|---|---|---|
| Exchange the two effect call IDs | false | false |
| Duplicate one effect row | false | false |
| Replace call-B `enabled: false` with integer `0` | false | false |
| Reverse row enumeration only | true | true |

The preflight patches exercise false booleans and multiple fields. They do not empirically exercise the main matrix's zero-integer or empty-string edit cells; support for those values is inferred from the generic merge and typed canonical comparison until the frozen main collection runs. These software checks are not new experimental observations.

### Outcome interpretation and execution classification

The reviewed scorer already prevents a successful effect from masking a non-`collected` terminal status, and explicitly classifies `native_status == unsupported` before a setup mismatch. Native framework errors remain separate from exact effect equality. Preserve that separation: an effect match alone does not certify general checkpoint correctness, full application completion, or an SDK without defects. Native phase statuses remain available in the underlying retained records.

## Claim boundary

The current evidence establishes usable LangChain instrumentation and observed correctness in four development cells, including call identity with equal original arguments and a true fresh-process SQLite resume. It establishes neither a new method nor a broad absence of framework defects. The same oracle information is available to the direct baseline. The pending-phase check is repaired; proceeding to the declared main matrix is appropriate once the final scientific code is frozen. These preflights must stay outside the main denominator.

No main cases, provider requests, or additional native preflights were executed for this audit. Only this report was written during the scoring review; producer code and outputs were read-only.
