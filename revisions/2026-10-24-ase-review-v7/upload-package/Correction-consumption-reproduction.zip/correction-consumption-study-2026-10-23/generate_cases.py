from copy import deepcopy
from itertools import product
from study_common import HERE, sha, write
import hashlib

FRAMEWORKS = ['agno', 'langchain', 'pydantic_ai']
SCENARIOS = ['single', 'distinct_first', 'distinct_second', 'equal_first',
             'equal_second', 'distinct_both', 'equal_both']
EDITS = ['text', 'zero', 'false', 'empty', 'multiple', 'unchanged']

def make_case(framework, lifecycle, scenario, edit, family, prefix='main'):
    unicode = family == 'unicode'
    original = {'destination': '本地收件箱' if unicode else 'sink-A',
                'ticket': '票据-甲' if unicode else 'T-A',
                'note': '原建议\n"甲"' if unicode else 'proposed-A',
                'quantity': 7, 'enabled': True}
    count = 1 if scenario == 'single' else 2
    calls = []
    for i in range(count):
        args = deepcopy(original)
        if i and scenario.startswith('distinct'):
            args.update(ticket='票据-乙' if unicode else 'T-B', quantity=11,
                        note='原建议乙' if unicode else 'proposed-B')
        target = scenario == 'single' or scenario.endswith('both') or (
            i == (1 if scenario.endswith('second') else 0))
        human = ('人工修改-' if unicode else 'reviewed-') + str(i)
        options = {'text': {'note': human}, 'zero': {'quantity': 0},
                   'false': {'enabled': False}, 'empty': {'note': ''},
                   'multiple': {'note': human, 'quantity': 2 + i, 'enabled': False},
                   'unchanged': {'note': args['note']}}
        calls.append({'id': 'call-' + ('A' if i == 0 else 'B'),
                      'original': args, 'patch': options[edit] if target else {}})
    return {'id': '-'.join([prefix, framework, lifecycle, scenario, edit, family]),
            'framework': framework, 'lifecycle': lifecycle, 'scenario': scenario,
            'edit': edit, 'payload_family': family, 'calls': calls}

def generate():
    groups = {}
    for framework in FRAMEWORKS:
        cases = [make_case(framework, *x) for x in product(
            ['live', 'fresh_process'], SCENARIOS, EDITS, ['ascii', 'unicode'])]
        groups[framework] = sorted(cases, key=lambda c: hashlib.sha256(
            ('correction-consumption-v1|' + c['id']).encode()).hexdigest())
    return [groups[f][i] for i in range(168) for f in FRAMEWORKS]

def validate(case):
    schema = {'destination': str, 'ticket': str, 'note': str, 'quantity': int, 'enabled': bool}
    ids = [c['id'] for c in case['calls']]
    assert len(ids) == len(set(ids)) and 1 <= len(ids) <= 2
    for call in case['calls']:
        assert set(call['original']) == set(schema)
        assert set(call['patch']) <= set(schema)
        for key, value in {**call['original'], **call['patch']}.items():
            assert type(value) is schema[key], (case['id'], key)
    return True

if __name__ == '__main__':
    cases = generate()
    assert len(cases) == 504 and all(validate(c) for c in cases)
    assert not (HERE / 'freeze.json').exists(), 'Do not regenerate frozen cases'
    write(HERE / 'cases.json', cases)
    preflight = [make_case(f, route, scenario, 'multiple', 'ascii', 'preflight')
                 for f, route, scenario in product(FRAMEWORKS, ['live', 'fresh_process'],
                                                   ['single', 'equal_second'])]
    for c in preflight:
        for call in c['calls']:
            call['original']['ticket'] = 'PREFLIGHT-ONLY'
            if 'note' in call['patch']:
                call['patch']['note'] = 'preflight-only'
    write(HERE / 'preflight-cases.json', preflight)
    print({'main': len(cases), 'preflight': len(preflight), 'hash': sha(HERE / 'cases.json')})
