"""Agno 3.1.10 public HITL adapter for the frozen offline study.

The worker owns network guards and effect DB creation. This adapter uses only
native Agent/JsonDb pause-resume; metadata stores identifiers, not custom state.
"""
from contextvars import ContextVar
import hashlib
import json
from pathlib import Path

from study_common import append_effect, effect_rows


def _write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def execute(case: dict, out: Path, phase: str) -> dict:
    from agno.agent import Agent
    from agno.db.json import JsonDb
    from agno.models.base import Model
    from agno.models.response import ModelResponse
    from agno.tools import FunctionCall, tool

    if phase not in {"live", "prepare", "resume"}:
        raise ValueError("Unsupported phase: " + phase)
    out = Path(out)
    expected_ids = [call["id"] for call in case["calls"]]
    if len(set(expected_ids)) != len(expected_ids):
        raise ValueError("The application must provide unique native call IDs")
    case_digest = hashlib.sha256(json.dumps(case, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    runtime_call_id = ContextVar("agno_observed_call_id", default=None)
    model_schema_observations = []

    class ScriptModel(Model):
        def __init__(self):
            super().__init__(id="offline-history-script", provider="local")

        def invoke(self, messages=None, *args, **kwargs):
            if kwargs.get("tools") is not None:
                model_schema_observations.append(json.loads(json.dumps(kwargs["tools"], default=str)))
            # Newly constructed models resume from native persisted history.
            if any(getattr(message, "role", None) == "tool" for message in messages or []):
                return ModelResponse(role="assistant", content="done")
            return ModelResponse(role="assistant", tool_calls=[
                {"id": call["id"], "type": "function", "function": {
                    "name": "record_delivery",
                    "arguments": json.dumps(call["original"], ensure_ascii=False),
                }} for call in case["calls"]
            ])

        async def ainvoke(self, *args, **kwargs): return self.invoke(*args, **kwargs)
        def invoke_stream(self, *args, **kwargs): yield self.invoke(*args, **kwargs)
        async def ainvoke_stream(self, *args, **kwargs): yield self.invoke(*args, **kwargs)
        def _parse_provider_response(self, response, **kwargs): return response
        def _parse_provider_response_delta(self, response): return response

    def capture_id(fc: FunctionCall):
        # Public observation hook, with no argument or control-flow mutation.
        runtime_call_id.set(fc.call_id)

    @tool(requires_user_input=True, pre_hook=capture_id)
    def record_delivery(destination: str, ticket: str, note: str, quantity: int, enabled: bool) -> str:
        """Append only a local simulated delivery after human review."""
        call_id = runtime_call_id.get()
        if call_id is None:
            raise RuntimeError("Native FunctionCall identity was not observed")
        append_effect(out, call_id, {
            "destination": destination, "ticket": ticket, "note": note,
            "quantity": quantity, "enabled": enabled,
        })
        return "recorded"

    agent = Agent(
        id="correction-consumption-study", model=ScriptModel(), tools=[record_delivery],
        db=JsonDb(db_path=str(out / "agno-db")), telemetry=False,
    )
    metadata_path = out / "agno-state.json"
    if phase == "resume":
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata["case_sha256"] != case_digest:
            raise ValueError("Prepared state belongs to a different input")
        paused = agent.get_run_output(run_id=metadata["run_id"], session_id=metadata["session_id"])
    else:
        paused = agent.run("Review each proposed delivery before executing it.", session_id=case["id"])
        metadata = {"run_id": paused.run_id, "session_id": case["id"], "case_sha256": case_digest}
        _write(metadata_path, metadata)
    if paused is None or not paused.is_paused:
        raise RuntimeError("Expected a native paused RunOutput")

    requirements = list(paused.active_requirements)
    pending = []
    for requirement in requirements:
        execution = requirement.tool_execution
        if execution is None:
            raise RuntimeError("Active requirement has no native tool execution")
        pending.append({"call_id": execution.tool_call_id, "name": execution.tool_name,
                        "args": dict(execution.tool_args or {})})
    actual_ids = [item["call_id"] for item in pending]
    result = {
        "phase": phase, "pending": pending, "decisions": [],
        "native_status": str(paused.status), "framework_errors": [],
        "metadata": metadata, "before_requirements": [r.to_dict() for r in requirements],
        "native_model_schema": record_delivery.parameters,
        "model_schema_observations": model_schema_observations,
        "requested_schema_fields": [
            {"call_id": r.tool_execution.tool_call_id, "fields": [f.name for f in r.user_input_schema or []]}
            for r in requirements
        ],
    }
    identity_reason = None
    if len(actual_ids) != len(set(actual_ids)) or set(actual_ids) != set(expected_ids):
        identity_reason = "pending_ids_differ_from_proposal"
    elif any(item["name"] != "record_delivery" for item in pending):
        identity_reason = "pending_tool_name_differs"
    if identity_reason:
        # v1.1 pre-freeze amendment: return the observed native state instead of
        # raising, so a pending-identity difference is retained and scored in its
        # own category rather than filed as a setup error.
        result["native_status"] = "unexpected_pending"
        result["framework_errors"] = [{"type": "PendingIdentityMismatch", "reason": identity_reason,
                                       "expected_call_ids": expected_ids, "actual_call_ids": actual_ids}]
        return result
    if phase == "prepare":
        return result

    by_id = {call["id"]: call for call in case["calls"]}
    for requirement in requirements:
        call_id = requirement.tool_execution.tool_call_id
        call = by_id[call_id]
        full_args = dict(call["original"])
        full_args.update(call["patch"])
        field_names = [field.name for field in requirement.user_input_schema or []]
        if any(name not in full_args for name in field_names):
            raise ValueError("Complete reviewed object lacks a requested native field")
        supplied = {name: full_args[name] for name in field_names}
        requirement.provide_user_input(supplied)
        result["decisions"].append({"call_id": call_id, "patch": dict(call["patch"]),
                                    "full_args": full_args, "supplied_user_input": supplied})
    result["after_requirements"] = [r.to_dict() for r in requirements]
    if not all(r.is_resolved() for r in requirements):
        raise RuntimeError("Native requirements remain unresolved after complete valid input")

    # v1.1 pre-freeze amendment: effects present before the native continue step
    # mean the review did not gate execution; the scorer reports that separately.
    result["effects_before_continue"] = len(effect_rows(out))
    if phase == "live":
        # Original RunOutput and its native requirement objects remain in memory.
        final = agent.continue_run(run_response=paused)
    else:
        # Recommended fresh-process route; never use getter+response here.
        final = agent.continue_run(
            run_id=metadata["run_id"], session_id=metadata["session_id"],
            requirements=paused.requirements,
        )
    result["native_status"] = str(final.status)
    result["final_tools"] = [execution.to_dict() for execution in final.tools or []]
    result["remaining_pending"] = [
        {"call_id": r.tool_execution.tool_call_id, "name": r.tool_execution.tool_name}
        for r in final.active_requirements if r.tool_execution is not None
    ]
    result["framework_errors"] = [
        {"call_id": execution.tool_call_id, "message": str(execution.result)}
        for execution in final.tools or [] if execution.tool_call_error
    ]
    persisted = agent.get_run_output(run_id=metadata["run_id"], session_id=metadata["session_id"])
    result["persisted_run"] = persisted.to_dict() if persisted is not None else None
    return result

