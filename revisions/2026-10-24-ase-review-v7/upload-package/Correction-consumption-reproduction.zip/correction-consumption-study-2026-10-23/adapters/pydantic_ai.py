"""Native Pydantic AI deferred-approval adapter for the offline study.

The worker owns process isolation, the socket guard and effects.sqlite creation.
This module supplies a complete reviewed argument object to each native call ID.
It never scores effects or writes expected values into the effect store.
"""
from __future__ import annotations

import hashlib
import json
import os
from copy import deepcopy
from importlib.metadata import version
from pathlib import Path

os.environ['OTEL_SDK_DISABLED'] = 'true'
os.environ['LOGFIRE_SEND_TO_LOGFIRE'] = 'false'

from pydantic import TypeAdapter
from pydantic_ai import (
    Agent, DeferredToolRequests, ModelMessagesTypeAdapter, RunContext,
    ToolApproved, models,
)
from pydantic_ai.messages import ModelResponse, TextPart, ToolCallPart
from pydantic_ai.models.function import FunctionModel
from study_common import append_effect, effect_rows

models.ALLOW_MODEL_REQUESTS = False
EXPECTED_VERSION = '2.60.0'
REQUESTS_ADAPTER = TypeAdapter(DeferredToolRequests)


class NativeIdentityError(ValueError):
    """Native pending call identity differs from the declared proposal."""


def _identity_trace(reason, model_events, pending=()):
    # v1.1 pre-freeze amendment: retain the observed native state instead of
    # raising, so a pending-identity difference is scored in its own category.
    return {'pending': list(pending), 'decisions': [], 'native_status': 'unexpected_pending',
            'framework_errors': [{'type': 'PendingIdentityMismatch', 'reason': reason}],
            'framework_version': EXPECTED_VERSION, 'model_events': model_events}


def _write_bytes(path: Path, value: bytes) -> None:
    with path.open('xb') as handle:
        handle.write(value)


def _write_json(path: Path, value: object) -> None:
    _write_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def _case_digest(case: dict) -> str:
    return hashlib.sha256(json.dumps(case, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()


def _pending(requests: DeferredToolRequests) -> list[dict]:
    if requests.calls:
        raise NativeIdentityError('This adapter supports approval requests, not externally executed calls')
    rows = [{'call_id': call.tool_call_id, 'name': call.tool_name,
             'args': deepcopy(call.args_as_dict(raise_if_invalid=True))}
            for call in requests.approvals]
    if len({row['call_id'] for row in rows}) != len(rows):
        raise NativeIdentityError('Native pending call IDs are not unique')
    return rows


def _framework_errors(history_json: list[dict]) -> list[dict]:
    errors = []
    for message in history_json:
        for part in message.get('parts', []):
            if (part.get('part_kind') in {'retry-prompt', 'retry-feedback'}
                    or part.get('outcome') in {'failed', 'retried', 'denied', 'interrupted'}):
                errors.append(deepcopy(part))
    return errors


def _history_snapshot(out: Path, label: str, messages: list) -> list[dict]:
    data = ModelMessagesTypeAdapter.dump_json(messages)
    _write_bytes(out / ('pydantic_ai-' + label + '-history.json'), data)
    return json.loads(data)


def _make_agent(case: dict, out: Path, model_events: list[dict]) -> Agent:
    def script(messages, info):
        previous_calls = [part for message in messages for part in message.parts
                          if isinstance(part, ToolCallPart)]
        # Only persisted message content controls continuation; no call counter.
        model_events.append({'prior_tool_call_ids': [part.tool_call_id for part in previous_calls],
                             'action': 'finish' if previous_calls else 'propose'})
        if previous_calls:
            return ModelResponse(parts=[TextPart('Finished local delivery recording.')])
        return ModelResponse(parts=[
            ToolCallPart('record_delivery', deepcopy(call['original']), tool_call_id=call['id'])
            for call in case['calls']
        ])

    agent = Agent(FunctionModel(script), output_type=[str, DeferredToolRequests])

    @agent.tool(requires_approval=True)
    def record_delivery(ctx: RunContext, destination: str, ticket: str, note: str,
                        quantity: int, enabled: bool) -> str:
        """Append the actual arguments to a local audit store; contact no service."""
        append_effect(out, ctx.tool_call_id,
                      {'destination': destination, 'ticket': ticket, 'note': note,
                       'quantity': quantity, 'enabled': enabled})
        return 'recorded'

    return agent


def _decisions(case: dict, requests: DeferredToolRequests, pending: list[dict]):
    intended = {call['id']: call for call in case['calls']}
    if len(intended) != len(case['calls']):
        raise ValueError('Study input call IDs must be unique')
    if set(intended) != {row['call_id'] for row in pending}:
        raise NativeIdentityError('Native pending call IDs do not match the declared model proposal')
    approvals = {}
    decision_rows = []
    for row in pending:
        if row['name'] != 'record_delivery':
            raise NativeIdentityError('Unexpected pending tool: ' + row['name'])
        source = intended[row['call_id']]
        # override_args REPLACES all arguments. The application, not the SDK,
        # explicitly merges the human patch into the complete reviewed object.
        full_args = {**deepcopy(source['original']), **deepcopy(source['patch'])}
        approvals[row['call_id']] = ToolApproved(override_args=full_args)
        decision_rows.append({'call_id': row['call_id'], 'patch': deepcopy(source['patch']),
                              'full_args': deepcopy(full_args)})
    return requests.build_results(approvals=approvals), decision_rows


def execute(case: dict, out: Path, phase: str) -> dict:
    if phase not in {'live', 'prepare', 'resume'}:
        raise ValueError('Unsupported phase: ' + phase)
    if version('pydantic-ai-slim') != EXPECTED_VERSION:
        raise RuntimeError('Pydantic AI version differs from the pinned adapter')
    out = Path(out)
    model_events = []
    agent = _make_agent(case, out, model_events)
    metadata_path = out / 'pydantic_ai-prepare-metadata.json'

    if phase == 'resume':
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        if metadata['case_digest'] != _case_digest(case):
            raise ValueError('Resume case differs from the prepared case')
        if metadata['prepare_pid'] == os.getpid():
            raise ValueError('Resume requires a genuinely new worker process')
        history = ModelMessagesTypeAdapter.validate_json(
            (out / 'pydantic_ai-prepare-history.json').read_bytes())
        requests = REQUESTS_ADAPTER.validate_json(
            (out / 'pydantic_ai-prepare-requests.json').read_bytes())
        try:
            pending = _pending(requests)
        except NativeIdentityError as error:
            return _identity_trace(str(error), model_events)
        _write_json(out / 'pydantic_ai-resume-loaded-pending.json', pending)
    else:
        paused = agent.run_sync('Propose the declared local deliveries and wait for human review.')
        history = paused.all_messages()
        initial_json = _history_snapshot(out, phase + '-initial', history)
        if not isinstance(paused.output, DeferredToolRequests):
            raise RuntimeError('Expected native deferred approvals; got ' + type(paused.output).__name__)
        requests = paused.output
        try:
            pending = _pending(requests)
        except NativeIdentityError as error:
            return _identity_trace(str(error), model_events)
        if phase == 'prepare':
            _write_bytes(out / 'pydantic_ai-prepare-history.json', ModelMessagesTypeAdapter.dump_json(history))
            _write_bytes(out / 'pydantic_ai-prepare-requests.json', REQUESTS_ADAPTER.dump_json(requests))
            _write_json(metadata_path, {'format_version': 1, 'case_id': case['id'],
                                       'case_digest': _case_digest(case), 'prepare_pid': os.getpid(),
                                       'framework_version': EXPECTED_VERSION, 'pending': pending})
            _write_json(out / 'pydantic_ai-prepare-model-events.json', model_events)
            return {'pending': pending, 'decisions': [], 'native_status': 'deferred',
                    'framework_errors': _framework_errors(initial_json),
                    'framework_version': EXPECTED_VERSION, 'model_events': model_events,
                    'prepare_pid': os.getpid(), 'serialization': 'native message and deferred-request TypeAdapters'}

    try:
        results, decision_rows = _decisions(case, requests, pending)
    except NativeIdentityError as error:
        return _identity_trace(str(error), model_events, pending)
    _write_json(out / ('pydantic_ai-' + phase + '-decisions.json'), decision_rows)
    # v1.1 pre-freeze amendment: effects before the native continue step mean the
    # review did not gate execution.
    effects_before_continue = len(effect_rows(out))
    final = agent.run_sync(message_history=history, deferred_tool_results=results)
    final_json = _history_snapshot(out, phase + '-final', final.all_messages())
    _write_json(out / ('pydantic_ai-' + phase + '-model-events.json'), model_events)
    trace = {'pending': pending, 'decisions': decision_rows,
             'native_status': 'deferred' if isinstance(final.output, DeferredToolRequests) else 'completed',
             'framework_errors': _framework_errors(final_json), 'framework_version': EXPECTED_VERSION,
             'final_output_type': type(final.output).__name__, 'model_events': model_events,
             'effects_before_continue': effects_before_continue,
             'call_mapping': 'native tool_call_id; no positional or content-based reassignment'}
    if phase == 'resume':
        trace.update(prepare_pid=metadata['prepare_pid'], resume_pid=os.getpid())
    return trace
