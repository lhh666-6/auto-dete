from pathlib import Path
import csv
import shutil
from study_common import HERE, read, write, sha, verify_freeze

def main():
    freeze_hash = verify_freeze()
    dest = HERE / 'github-design'
    dest.mkdir(exist_ok=False)
    for name in ['PROTOCOL.md', 'ADAPTER-CONTRACT.md', 'generate_cases.py', 'study_common.py']:
        shutil.copyfile(HERE / name, dest / name)
    cases = read(HERE / 'cases.json')
    with (dest / 'matrix.csv').open('w', encoding='utf-8', newline='') as f:
        columns = ['id', 'framework', 'lifecycle', 'scenario', 'edit', 'payload_family', 'call_count']
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for case in cases:
            writer.writerow({**{k: case[k] for k in columns[:-1]}, 'call_count': len(case['calls'])})
    readme = '''# 人工更正的跨调用、跨进程消费一致性实验设计

设计日期：2026-10-23（Asia/Shanghai）。本目录保存正式采集前冻结的设计，
不包含主实验结果，也不声称提出优于现有方法的新算法。

研究问题是：人工明确审核的工具参数，经过暂停、保存和新进程恢复后，是否仍由
正确的调用采用？当两个调用的原始参数完全相同时，只修改其中一个，会不会影响另一个？

## 固定矩阵

| 维度 | 设置 |
|---|---|
| 框架 | Agno 3.1.10；LangChain 1.4.7 / LangGraph 1.2.16；Pydantic AI 2.60.0 |
| 生命周期 | 原进程继续；保存后退出，再由新解释器恢复 |
| 调用场景 | 单调用；不同/相同原参数的双调用，各修改第一个、第二个或两个 |
| 人工编辑 | 文本替换、整数 0、False、空字符串、三字段修改、同值确认 |
| 输入族 | ASCII；含 Unicode、引号及换行的文本 |
| 总量 | 3 × 2 × 7 × 6 × 2 = 504 个构造组合 |

504 个组合不是 504 个独立缺陷，也不是生态总体抽样。
三个框架均使用其原生公开接口、确定性脚本模型和真实本地工具执行。
付费调用预算为 0。每格独立目录/数据库；先并发 2，验收后最多并发 4。

## 检查与比较

工具体把实际调用 ID、工具名和实际参数写入独立 SQLite。评分在 SDK 外只读执行，
检查已改字段、未改字段和调用身份；不以模型回答或 completed/resolved 状态判成功。
最强简单基线取得完全相同的信息，比较完整、严格类型的效果集合。
此前小实验中两种判据完全一致，因此本设计不预设检测优势。

新进程恢复是干净退出后的恢复，不是崩溃或竞争测试。Agno 两条生命周期使用的
原生入口也不同，不能单凭结果差异归因于进程重启。预飞已观察的多调用共享输入
问题对应公开 [Agno #8546](https://github.com/agno-agi/agno/issues/8546)，属于已知校准，
不计作新发现。自动建模、人工工时节省、生产安全和普遍正确性均不在本设计的已证实主张中。

## 文件

- [正式协议](PROTOCOL.md)：研究问题、样本、评分、失败分类和停止条件。
- [适配接口约定](ADAPTER-CONTRACT.md)：三框架 adapter 与真实效果记录的边界。
- [完整组合索引](matrix.csv)：504 格预定清单。
- [输入生成器](generate_cases.py)及[公共辅助代码](study_common.py)：生成精确参数输入。
- [执行准备验收](READINESS.md)：预飞与运行保障证据摘要。
- [设计哈希清单](DESIGN-MANIFEST.json)：此目录文件与本地正式冻结的关联。

在空白副本目录运行 `python generate_cases.py` 可生成 `cases.json` 和独立预飞输入。
需要 Python 3.11 或兼容版本，无第三方依赖、无网络调用。
这里上传的是设计及输入定义，不是完整 SDK 复现包；主执行适配器和采集输出另行保存。
'''
    (dest / 'README.md').write_text(readme, encoding='utf-8')
    readiness = '''# 正式采集前的准备验收

三框架各 4 格开发预飞，共 12 格，全部保留。
LangChain 和 Pydantic AI 各 4/4 效果符合人工输入；Agno 3/4，剩余一格为已知
共享输入问题 #8546。原生调用正常完成与业务参数正确是两个不同判断。
预飞不进入主 504 格的结果统计，也不是盲测集。

运行保障及评分软件控制 21/21 通过，覆盖：超时及派生子进程回收，内存/日志/
产物大小/磁盘余量限制，全局停止，快速退出后的限额核验，冻结绑定的断点恢复，
篡改拒绝，执行前独占阶段标记，凭据变量过滤，以及正确/错误效果判据。
资源是采样限制，网络隔离是 Python 层约束，不声称 OS 级全面沙箱。

独立审查修复了执行后才拒绝重复阶段、恢复未绑定当前冻结、快速退出绕过持久
限额核验、评分隐藏采集中止/unsupported、遗漏恢复后提案核验等问题。
所有修正均在正式主采集冻结之前，原预飞失败及前版故障测试仍保留。

评分将采集故障、unsupported、提案失配、工具错误和实际效果不一致分别报告。
两种判据使用同信息，不以削弱简单基线制造优势。研究不提交 issue 或联系维护者。

主结果未包含在本设计快照中；不得把准备验收当作 504 格已完成或已经提升创新性的证据。
'''
    (dest / 'READINESS.md').write_text(readiness, encoding='utf-8')
    files = {p.name: sha(p) for p in sorted(dest.iterdir()) if p.is_file()}
    write(dest / 'DESIGN-MANIFEST.json', {'design_date': '2026-10-23', 'timezone': 'Asia/Shanghai',
          'scope': 'precollection design and exact deterministic input generator; no main outcomes',
          'planned_cases': len(cases), 'local_study_freeze_sha256': freeze_hash,
          'generated_cases_sha256': sha(HERE / 'cases.json'), 'files': files})
    print({'files': len(files) + 1, 'directory': str(dest)})

if __name__ == '__main__':
    main()
