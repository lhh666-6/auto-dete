# Shared adapter contract (pre-freeze development)

Each adapter exports `execute(case: dict, out: pathlib.Path, phase: str) -> dict`.
`phase` is `live`, `prepare`, or `resume`.
The root worker initializes effects.sqlite and installs the network guard before
importing an adapter. `out` is a unique case directory; all state lives inside it.
For `live`, pause and continue in the same process using original native objects.
For `prepare`, pause and persist only; no tool body should execute. Return so the
process exits. For `resume`, a NEW process/Agent/graph reads persisted native state
and applies human input, then continues using a documented native path.

Case shape:
```
{
  "id": "unique-cell", "framework": "agno|langchain|pydantic_ai",
  "lifecycle": "live|fresh_process", "scenario": "...", "edit": "...",
  "payload_family": "ascii|unicode",
  "calls": [
    {"id": "call-A", "original": {"destination":"sink-A", "ticket":"T",
      "note":"proposed", "quantity":7, "enabled":true},
     "patch": {"note":"human"}},
    {"id": "call-B", "original": {"destination":"sink-A", "ticket":"T",
      "note":"proposed", "quantity":7, "enabled":true}, "patch": {}}
  ]
}
```
All native calls use the same tool `record_delivery` with required str destination,
str ticket, str note, int quantity, bool enabled. Scripted model emits all calls
in case order in one proposal. Termination must depend on persisted message/history
content, not a process-local counter. Fresh-process semantics must not re-propose
or execute a call merely because the deterministic model was recreated.

The application supplies a complete valid reviewed object `original + patch` for
each pending call, including unmodified calls. Agno passes all requested human
input fields; LangChain follows official ordered decision mapping; Pydantic uses
native ToolApproved with full override_args. Do NOT shuffle a positional API or
infer unsupported equivalence. Do NOT mutate SDK internal objects to create a bug.
Use native call IDs where available and explicitly document positional mapping.

Tool body calls shared `study_common.append_effect(out, call_id, payload)` with
its ACTUAL arguments and runtime call ID. It does not receive expected values.
SQLite schema: `effects(seq INTEGER PRIMARY KEY, call_id TEXT, tool_name TEXT,
payload TEXT)`. Parent/independent scorer reads this in read-only mode.

Returned JSON includes `pending`: list of {call_id,name,args} from actual native
pending objects before input; `decisions`: list of {call_id,patch,full_args};
`native_status`; `framework_errors` list. Persist sufficient metadata in out for
resume; keep prepare and resume traces separate. Extra native diagnostic fields
are welcome. No case-ID-based pass/fail. Exceptions are recorded by worker;
document unsupported semantics rather than fabricating support.

Prepare adapter and official/source evidence, then run ONLY separately retained
preflight cells until root freezes the main matrix/code. Never overwrite frozen
previous study files or start the main batch independently.
