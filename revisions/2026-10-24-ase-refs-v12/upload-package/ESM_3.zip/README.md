# Online Resource 3: Sources and reproduction archives

Article: The Review–Execution Gap in Agentic Software: Approval Scope and Recovery
Journal: Automated Software Engineering
Authors: Liang Hanghao; Xuan Wentao; Chen Qile; Peng Peng
Affiliation (all authors and corresponding author): College of Computer Science and Electronic Engineering, Hunan University, Changsha 410082, China
Corresponding author: Peng Peng (hnu16pp@hnu.edu.cn)

Caption: Online Resource 3 provides editable manuscript and supplementary sources,
figure and analysis sources, and seven reproduction archives.

## Contents

- `Manuscript-sources.zip`: the exact v12 source distribution for the main article,
  Online Resources 1 and 2, figure-generation code, source data and original assets,
  analysis scripts, tables, bibliography, manifests and reproduction instructions.
  Extract it and read `Manuscript-sources/README.txt` and
  `Manuscript-sources/REPRODUCE-RECOVERY.md`.
- `X1-X2-reproduction.zip`: X1/X2 study reproduction package.
- `Native-contract-reproduction.zip`: native-to-store contract composition.
- `Feedback-sensitivity-reproduction.zip`: permission-state feedback comparison.
- `Dynamic-recovery-reproduction.zip`: dynamic recovery study.
- `Correction-consumption-reproduction.zip`: correction-consumption SDK study;
  extract and read `START-HERE.md` before historical notes.
- `Agno-entrypoint-reproduction.zip`: Agno continuation-entrypoint study;
  extract and read `START-HERE.md` before historical notes.
- `Reviewed-instance-substitution-reproduction.zip`: reviewed-instance substitution
  study; extract and read `START-HERE.md` before historical notes.

`MANIFEST.json` records SHA-256 hashes and byte counts of all eight ZIPs. Every
nested archive is an exact byte copy of the verified v8 distribution. Keeping
archives nested intentionally preserves their original paths, inventories,
recorded seals and experimental freezes. Extract each archive into its own
directory and follow its guide. Do not regenerate a freeze or overwrite preserved
scores merely to verify the evidence. The three SDK follow-ups provide
standard-library offline verification of included raw SQLite effects without SDK
imports or recollection. These are separate constructed studies; do not pool
cells as independent observations. Follow each package's interpretation notes.

## External historical data

The external historical datasets are not embedded in this bundle. Pinned
locations, hashes and dependency boundaries remain in
`Manuscript-sources/REPRODUCE-RECOVERY.md` and
`Manuscript-sources/EXTERNAL-INPUTS.json`. Recovery readback requires prior
acquisition of these two exact historical archives:

- [Original collection, pinned commit](https://github.com/lhh666-6/auto-dete/blob/475e66f549613aaaaa62c2ec81ffdee483636c54/cloud-handoff/replication-package.zip).
- [Complete supplementary A, pinned commit](https://github.com/lhh666-6/auto-dete/blob/f5fe7231c5e808ba1629132d222f448bff471204/research/phase2-results-snapshots/2026-10-07-complete/quota-recovery-complete.zip).

Use the recorded SHA-256 checks before readback. Downloading requires network
access; the documented analyses can then run offline. This packaging performed
no new experiment, SDK collection or model call. Not all historical evidence is
self-contained in this bundle.

## Related supplementary documents

`ESM_1.pdf` is Online Resource 1: formal checks, workloads, historical records,
prospective definitions, complete outcomes and artifact map. `ESM_2.pdf` is
Online Resource 2: supplementary experiments, specification, design guidance and
extended audits. Both are separate PDF uploads cited in the article.

Prepared for Automated Software Engineering on 24 October 2026 using its
[official submission guidelines](https://link.springer.com/journal/10515/submission-guidelines)
(accessed 24 October 2026).

Version v10 trims the introduction's citation enumeration, rewrites the related-work prose as a comparison, and removes two arXiv preprints (REVISE, Resume Means Resume); the future-work subsection from v9 is retained. The seven study ZIPs remain byte-identical to v11, v10, v9, v8 and v7; the manuscript-source ZIP contains the updated manuscript and source manifest.
